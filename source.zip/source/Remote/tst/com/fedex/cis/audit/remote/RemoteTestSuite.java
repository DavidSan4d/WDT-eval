package com.fedex.cis.audit.remote;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  O2bRsRemoteTest.class,
  A2bRsRemoteTest.class,
  B2bRsRemoteTest.class,
  C2bRsRemoteTest.class
})

public class RemoteTestSuite {
  // Intentionally left blank!
}
