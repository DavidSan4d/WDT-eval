package com.fedex.cis.audit.remote;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.service.session.Authorization;

import fedex.cis.common.util.*;

public class C2bRsRemoteTest {

  private static java.util.Properties properties = null;
  private static C2bRsRemote remote = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = RemoteTestFixture.getProperties("cis.remote.rs.c2b.");
    remote = new C2bRsRemote(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  private C2bRsRemote getRemote() {
    return remote;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testC2bRsRemote() {
    C2bRsRemote result = new C2bRsRemote(getProperties());
    assertNotNull(result);
  }

  @Test
  public void testGetAuthorization_v1_Xml() throws Exception {
    Authorization result = getRemote().getAuthorization_v1_Xml(RemoteTestFixture.getTestToken());
    assertNotNull(result);
  }

  @Test
  public void testGetAuthorization_v1_Json() throws Exception {
    Authorization result = getRemote().getAuthorization_v1_Json(RemoteTestFixture.getTestToken());
    assertNotNull(result);
  }

  @Test
  @SuppressWarnings("deprecation")
  public void testQuery_v1_Xml() throws Exception {
    java.util.Date date = DateUtility.addMonths(DateUtility.getDate(), -1);
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(1);
    filters.add(new PrincipalFilter("246690"));
    filters.add(new ConductedFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date)));
    java.util.Collection<com.fedex.cis.audit.common.tbd.v1.Audit> result = getRemote().query_v1_Xml(RemoteTestFixture.getTestToken(), new Query(filters));
    assertNotNull(result);
  }

  @Test
  @SuppressWarnings("deprecation")
  public void testQuery_v1_Xml_NotFound() throws Exception {
    java.util.Date date = DateUtility.getDate();
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(1);
    filters.add(new PrincipalFilter("474768"));
    filters.add(new ConductedFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date)));
    java.util.Collection<com.fedex.cis.audit.common.tbd.v1.Audit> result = getRemote().query_v1_Xml(RemoteTestFixture.getTestToken(), new Query(filters));
    assertTrue(ObjectUtility.isValue(result) == false);
  }

  @Test
  @SuppressWarnings("deprecation")
  public void testQuery_v1_Json() throws Exception {
    java.util.Date date = DateUtility.addMonths(DateUtility.getDate(), -1);
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(1);
    filters.add(new PrincipalFilter("246690"));
    filters.add(new ConductedFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date)));
    java.util.Collection<com.fedex.cis.audit.common.tbd.v1.Audit> result = getRemote().query_v1_Json(RemoteTestFixture.getTestToken(), new Query(filters));
    assertNotNull(result);
  }

  @Test
  @SuppressWarnings("deprecation")
  public void testQuery_v1_Json_NotFound() throws Exception {
    java.util.Date date = DateUtility.getDate();
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(1);
    filters.add(new PrincipalFilter("474768"));
    filters.add(new ConductedFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date)));
    java.util.Collection<com.fedex.cis.audit.common.tbd.v1.Audit> result = getRemote().query_v1_Json(RemoteTestFixture.getTestToken(), new Query(filters));
    assertTrue(ObjectUtility.isValue(result) == false);
  }

  @Test
  public void testQuery_v2_Xml() throws Exception {
    java.util.Date date = DateUtility.addMonths(DateUtility.getDate(), -1);
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(1);
    filters.add(new PrincipalFilter("246690"));
    filters.add(new ConductedFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date)));
    QueryResult result = getRemote().query_v2_Xml(RemoteTestFixture.getTestToken(), new Query(filters));
    assertNotNull(result);
    assertTrue(result.isSuccess());
    assertNull(result.getMessages());
    //System.out.println(result.getRecords());
    assertTrue(result.getRecords().size() > 0);
  }

  @Test
  public void testQuery_v2_Xml_NotFound() throws Exception {
    java.util.Date date = DateUtility.getDate();
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(1);
    filters.add(new PrincipalFilter("474768"));
    filters.add(new ConductedFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date)));
    QueryResult result = getRemote().query_v2_Xml(RemoteTestFixture.getTestToken(), new Query(filters));
    assertNotNull(result);
    assertTrue(result.isSuccess());
    assertNull(result.getMessages());
    assertNull(result.getRecords());
  }

  @Test
  public void testQuery_v2_Json() throws Exception {
    java.util.Date date = DateUtility.addMonths(DateUtility.getDate(), -1);
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(1);
    filters.add(new PrincipalFilter("246690"));
    filters.add(new ConductedFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date)));
    QueryResult result = getRemote().query_v2_Json(RemoteTestFixture.getTestToken(), new Query(filters));
    assertNotNull(result);
    assertTrue(result.isSuccess());
    assertTrue(result.getMessages().isEmpty());
    //System.out.println(result.getRecords());
    assertTrue(result.getRecords().size() > 0);
  }

  @Test
  public void testQuery_v2_Json_NotFound() throws Exception {
    java.util.Date date = DateUtility.getDate();
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(1);
    filters.add(new PrincipalFilter("474768"));
    filters.add(new ConductedFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date)));
    QueryResult result = getRemote().query_v2_Json(RemoteTestFixture.getTestToken(), new Query(filters));
    assertNotNull(result);
    assertTrue(result.isSuccess());
    assertTrue(result.getMessages().isEmpty());
    assertTrue(result.getRecords().isEmpty());
  }

}
