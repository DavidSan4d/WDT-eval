package com.fedex.cis.audit.remote;

import static org.junit.Assert.assertNotNull;

import org.junit.*;

import fedex.cis.common.util.PropertiesUtility;

public class A2bRsRemoteTest {

  private static java.util.Properties properties = null;
  private static A2bRsRemote remote = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = RemoteTestFixture.getProperties("cis.remote.rs.a2b.");
    remote = new A2bRsRemote(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  @SuppressWarnings("unused")
  private A2bRsRemote getRemote() {
    return remote;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testA2bRsRemote() {
    A2bRsRemote result = new A2bRsRemote(getProperties());
    assertNotNull(result);
  }

}
