package com.fedex.cis.audit.remote;

import static org.junit.Assert.assertNotNull;

import org.junit.*;

import com.fedex.cis.audit.common.bean.Ping;

import fedex.cis.common.util.PropertiesUtility;

public class O2bRsRemoteTest {

  private static java.util.Properties properties = null;
  private static O2bRsRemote remote = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = RemoteTestFixture.getProperties("cis.remote.rs.o2b.");
    remote = new O2bRsRemote(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  private O2bRsRemote getRemote() {
    return remote;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testO2bRsRemote() {
    O2bRsRemote result = new O2bRsRemote(getProperties());
    assertNotNull(result);
  }

  @Test
  public void testPingXml() throws Exception {
    Ping result = getRemote().pingXml();
    assertNotNull(result);
  }

  @Test
  public void testPingJson() throws Exception {
    Ping result = getRemote().pingJson();
    assertNotNull(result);
  }

}
