package com.fedex.cis.audit.remote;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;
import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.common.bean.Audit;

import fedex.cis.common.util.PropertiesUtility;

public class B2bRsRemoteTest {

  private static java.util.Properties properties = null;
  private static B2bRsRemote remote = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = RemoteTestFixture.getProperties("cis.remote.rs.b2b.");
    remote = new B2bRsRemote(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  private B2bRsRemote getRemote() {
    return remote;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testB2bRsRemote() {
    B2bRsRemote result = new B2bRsRemote(getProperties());
    assertNotNull(result);
  }

  @Test
  @SuppressWarnings("deprecation")
  public void testRecord_v1() throws Exception {
    com.fedex.cis.audit.common.tbd.v1.Audit audit = CommonTestFixture.getTbdAudit();
    boolean result = getRemote().record_v1(RemoteTestFixture.getTestToken(), audit);
    assertFalse(result); // Ignored unless real pilot employee number is used!
  }

  @Test
  @Ignore("Manually remove created reference record")
  public void testRecord_v2_Xml() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    RecordResult result = getRemote().record_v2_Xml(RemoteTestFixture.getTestToken(), audit);
    assertNotNull(result); // Ignored unless real pilot employee number is used!
    assertTrue(result.isSuccess());
    assertNull(result.getMessages());
    System.out.println(result.getReference());
    assertNotNull(result.getReference());
  }

  @Test
  @Ignore("Manually remove created reference record")
  public void testRecord_v2_Json() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    RecordResult result = getRemote().record_v2_Json(RemoteTestFixture.getTestToken(), audit);
    assertNotNull(result); // Ignored unless real pilot employee number is used!
    assertTrue(result.isSuccess());
    assertTrue(result.getMessages().isEmpty());
    System.out.println(result.getReference());
    assertNotNull(result.getReference());
  }

}
