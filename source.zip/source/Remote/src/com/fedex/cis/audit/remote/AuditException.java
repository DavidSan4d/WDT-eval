package com.fedex.cis.audit.remote;

public class AuditException extends Exception {

  private static final long serialVersionUID = 1L;

  public AuditException(String message) { super(message); }

  public AuditException(String message, Throwable cause) { super(message, cause); }

}
