package com.fedex.cis.audit.remote;

/**
 * This helper submits audit records to the CisAudit service.
 * 
 * This helper is considered thread-safe and is intended to be integrated as a
 * singleton class.
 * 
 * -- Dependencies --
 * 
 * JRE 8 or higher
 *  
 * @author Michael Cronk
 */

public class AuditHelper {

  public static void main(String[] args) {
    try {

      // Configure properties
      java.util.Properties properties = new java.util.Properties();
      //properties.put("url", "http://127.0.0.1:2001/audit/rs");
      properties.put("url", "http://cis-services-l1.ute.fedex.com:7001/audit/rs");
      //properties.put("url", "http://cis-services-l2.ute.fedex.com:7001/audit/rs");

      // Get helper
      AuditHelper helper = new AuditHelper(properties);

      // Download test access token from CisAuthn service
      String token = helper.downloadContent("http://cis-services-l1.ute.fedex.com:7001/authn/rs/o2b/token/access/test", "application/jwt");

      // Record audit
      Audit audit = new Audit();
      audit.setPrincipal("PRINCIPAL");
      audit.setBusiness("BUSINESS");
      audit.setTransaction("TRANSACTION");
      audit.setConducted(new java.util.Date());
      audit.setPosted(new java.util.Date(audit.getConducted().getTime() + 10000)); // 10 seconds later
      audit.setClient("CLIENT");
      audit.setComment("COMMENT");
      audit.setMetadata("METADATA");
      boolean result = helper.record(token, audit);
      System.out.println(result);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // Private attributes
  private final String url;
  private final javax.xml.bind.JAXBContext jaxbContext;

  /**
   * Construct helper.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public AuditHelper(java.util.Properties properties) {
    url = properties.getProperty("url");
    try { jaxbContext = javax.xml.bind.JAXBContext.newInstance(Audit.class); } catch (Exception e) { throw new RuntimeException(e); }
  }

  /**
   * Record audit.
   * @param token String
   * @param audit Audit
   * @return boolean
   * @throws AuditException
   * @author Michael Cronk
   */
  public boolean record(String token, Audit audit) throws AuditException {
    boolean result = false;
    try {
      String response = uploadContent(url+"/b2b/record", "application/xml", "text/plain", marshallBytes(audit), token);
      result = Boolean.parseBoolean(response);
    } catch (Exception e) {
      throw new AuditException("Failed to record audit", e);
    }
    return result;
  }

  //
  // Helper methods
  //

  private <T> byte[] marshallBytes(T anObject) throws Exception {
    byte[] result = null;
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      outputStream = new java.io.ByteArrayOutputStream();
      javax.xml.bind.Marshaller marshaller = jaxbContext.createMarshaller();
      marshaller.marshal(anObject, outputStream);
      result = outputStream.toByteArray();
    } catch (Exception e) {
      throw new Exception("Failed to marshall bytes", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  private String downloadContent(String url, String accept) throws Exception {
    String result = null;
    java.net.HttpURLConnection connection = null;
    java.io.InputStreamReader streamReader = null;
    java.io.BufferedReader bufferedReader = null;
    try {
      connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", accept);
      connection.setConnectTimeout(5000); //  5 seconds to connect
      connection.setReadTimeout(10000);   // 10 seconds to wait for response
      int responseCode = connection.getResponseCode();
      if (responseCode == 200) {
        streamReader = new java.io.InputStreamReader(connection.getInputStream());
        bufferedReader = new java.io.BufferedReader(streamReader);
        String line;
        StringBuilder response = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null) {
          response.append(line);
        }
        result = response.toString();
      } else if (responseCode == 204) {
        // Intentionally does nothing!
      } else {
        throw new Exception("Unexpected HTTP response code: " + responseCode + ": " + connection.getResponseMessage());
      }
    } catch (Exception e) {
      throw new Exception("Failed to download content", e);
    } finally {
      if (bufferedReader != null) { try { bufferedReader.close(); } catch (Exception e) {} }
      if (streamReader != null) { try { streamReader.close(); } catch (Exception e) {} }
      if (connection != null) { try { connection.disconnect(); } catch (Exception e) {} }
    }
    return result;
  }

  private String uploadContent(String url, String contentType, String accept, byte[] content, String token) throws Exception {
    String result = null;
    java.net.HttpURLConnection connection = null;
    java.io.InputStreamReader streamReader = null;
    java.io.BufferedReader bufferedReader = null;
    try {
      connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
      connection.setRequestMethod("POST");
      connection.setRequestProperty("Authorization", "Bearer " + token);
      connection.setRequestProperty("Content-Type", contentType);
      connection.setRequestProperty("Content-Length", Integer.toString(content.length));
      connection.setRequestProperty("Accept", accept);
      connection.setConnectTimeout(5000); //  5 seconds to connect
      connection.setReadTimeout(10000);   // 10 seconds to wait for response
      connection.setDoOutput(true);
      connection.getOutputStream().write(content);
      int responseCode = connection.getResponseCode();
      if (responseCode == 200) {
        streamReader = new java.io.InputStreamReader(connection.getInputStream());
        bufferedReader = new java.io.BufferedReader(streamReader);
        String line;
        StringBuilder response = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null) {
          response.append(line);
        }
        result = response.toString();
      } else {
        throw new Exception("Unexpected HTTP response code: " + responseCode + ": " + connection.getResponseMessage());
      }
    } catch (Exception e) {
      throw new Exception("Failed to upload content", e);
    } finally {
      if (bufferedReader != null) { try { bufferedReader.close(); } catch (Exception e) {} }
      if (streamReader != null) { try { streamReader.close(); } catch (Exception e) {} }
      if (connection != null) { try { connection.disconnect(); } catch (Exception e) {} }
    }
    return result;
  }

}
