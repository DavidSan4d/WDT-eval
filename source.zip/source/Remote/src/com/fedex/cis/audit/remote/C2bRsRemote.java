package com.fedex.cis.audit.remote;

/**
 * Consumer-to-Business (c2b) RESTful web service (rs) application remote client.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.service.session.Authorization;

import fedex.cis.common.exception.CisException;
import fedex.cis.common.net.http.*;
import fedex.cis.common.pojo.PojoManager;
import fedex.cis.common.server.exception.ServerCisException;
import fedex.cis.common.util.ObjectUtility;

public class C2bRsRemote {

  // Public constants
  public static final String URL_PROPERTY = "url";

  // Private attributes
  private final String url;
  private final PojoManager jaxbHelper;

  /**
   * Construct remote client.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public C2bRsRemote(java.util.Properties properties) {
    // Set URL
    if (properties != null) {
      url = properties.getProperty(URL_PROPERTY);
    } else {
      url = null;
    }
    if (url == null) { throw new java.lang.NullPointerException("URL not defined"); }
    // Set JAXB helper
    jaxbHelper = new fedex.cis.common.pojo.JaxbPojoManager(null);
  }

  /**
   * Throw exception.
   * @param httpResponse HttpResponse
   * @throws ServerCisException
   * @author Michael Cronk
   */
  private void throwException(
      HttpResponse httpResponse)
          throws ServerCisException {
    throw new ServerCisException("Unexpected HTTP response: " + httpResponse.getCode());
  }

  /**
   * Get authorization (v1) with XML formatted response.
   * @param token String
   * @return Authorization
   * @throws CisException
   * @author Michael Cronk
   */
  public Authorization getAuthorization_v1_Xml(
      String token)
          throws ServerCisException {
    Authorization result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/authorization");
    httpRequest.setMethod(HttpRequest.GET_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Accept", "application/xml");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        result = jaxbHelper.unmarshall(outputStream.toByteArray(), Authorization.class);
      } else if (httpResponse.getCode() == 204) {
        // Intentionally does nothing!
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to get authorization (v1) with XML formatted response via C2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  /**
   * Get authorization (v1) with JSON formatted response.
   * @param token String
   * @return Authorization
   * @throws CisException
   * @author Michael Cronk
   */
  public Authorization getAuthorization_v1_Json(
      String token)
          throws ServerCisException {
    Authorization result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/authorization");
    httpRequest.setMethod(HttpRequest.GET_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Accept", "application/json");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        com.fasterxml.jackson.databind.ObjectMapper jsonHelper = new com.fasterxml.jackson.databind.ObjectMapper();
        result = jsonHelper.readValue(ObjectUtility.toString(outputStream.toByteArray()), Authorization.class);
      } else if (httpResponse.getCode() == 204) {
        // Intentionally does nothing!
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to get authorization (v1) with JSON formatted response via C2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  /**
   * Query audit (v1) with XML formatted response.
   * 
   *  - REQUEST
   *  

POST http://cis-services-l1.ute.fedex.com:7001/audit/rs/c2b/query
Accept: application/xml
Authorization: Bearer <jwt-token>
Content-Type: application/xml

<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<query>
  <relationship>AND</relationship>
  <filter xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="principalFilter">
    <operator>EQUAL</operator>
    <text>246690</text>
  </filter>
  <filter xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="conductedFilter">
    <operator>EQUAL</operator>
    <from>2019-06-05T00:00:00Z</from>
    <to>2019-06-05T23:59:59.999Z</to>
  </filter>
</query>

   *
   *  - RESPONSE
   *  

200
Content-Type: application/xml

<?xml version="1.0" encoding="UTF-8"?>
<audits>
  <audit>
    <principal>246690</principal>
    <business>NXT</business>
    <conducted>2019-06-05T11:49:30Z</conducted>
    <client>WEB</client>
    <comment>TRIP   64 07JUN19 2015 MEM 67 CAP</comment>
  </audit>
  <audit>
    <principal>246690</principal>
    <business>FCF</business>
    <conducted>2019-06-05T11:49:35Z</conducted>
    <client>WEB</client>
    <comment>ADM/GEN FCIF 19-0255 New Pharmacy Benefit Manager</comment>
  </audit>
</audits>

   * 
   * @param token String
   * @param query Query
   * @return java.util.Collection<com.fedex.cis.audit.common.tbd.Audit>
   * @throws CisException
   * @author Michael Cronk
   */
  @Deprecated
  public java.util.Collection<com.fedex.cis.audit.common.tbd.v1.Audit> query_v1_Xml(
      String token,
      Query query)
          throws ServerCisException {
    java.util.Collection<com.fedex.cis.audit.common.tbd.v1.Audit> result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/query");
    httpRequest.setMethod(HttpRequest.POST_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Content-Type", "application/xml");
    headers.put("Accept", "application/xml");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      httpRequest.setBody(jaxbHelper.marshall(query));
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        com.fedex.cis.audit.common.tbd.v1.AuditListDto dto = jaxbHelper.unmarshall(outputStream.toByteArray(), com.fedex.cis.audit.common.tbd.v1.AuditListDto.class);
        result = (dto != null) ? dto.getAudits() : null;
      } else if (httpResponse.getCode() == 204) {
        // Intentionally does nothing!
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to query audit (v1) with XML formatted response via C2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  /**
   * Query audit (v1) with JSON formatted response.
   * 
   *  - REQUEST
   *

POST http://cis-services-l1.ute.fedex.com:7001/audit/rs/c2b/query
Accept: application/json
Authorization: Bearer <jwt-token>
Content-Type: application/json

{
  "relationship":"AND",
  "filters":
    [
      { "type":"PRINCIPAL",
        "operator":"EQUAL",
        "text":"246690"
      },
      { "type":"CONDUCTED",
        "operator":"EQUAL",
        "from":"2019-06-05T00:00:00.000Z",
        "to":"2019-06-05T23:59:59.999Z"
      }
    ]
}

   *  
   *  - RESPONSE
   *

200
Content-Type: application/json

{
  "audits":
    [
      { "principal":"246690",
        "business":"NXT",
        "transaction":null,
        "conducted":"2019-06-05T11:49:30.000Z",
        "posted":null,
        "received":null,
        "service":null,
        "client":"WEB",
        "comment":"TRIP   64 07JUN19 2015 MEM 67 CAP",
        "metadata":null
        },
      { "principal":"246690",
        "business":"FCF",
        "transaction":null,
        "conducted":"2019-06-05T11:49:35.000Z",
        "posted":null,
        "received":null,
        "service":null,
        "client":"WEB",
        "comment":"ADM/GEN FCIF 19-0255 New Pharmacy Benefit Manager",
        "metadata":null
      }
    ]
}

   *   
   * @param token String
   * @param query Query
   * @return java.util.Collection<com.fedex.cis.audit.common.tbd.Audit>
   * @throws CisException
   * @author Michael Cronk
   */
  @Deprecated
  public java.util.Collection<com.fedex.cis.audit.common.tbd.v1.Audit> query_v1_Json(
      String token,
      Query query)
          throws ServerCisException {
    java.util.Collection<com.fedex.cis.audit.common.tbd.v1.Audit> result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/query");
    httpRequest.setMethod(HttpRequest.POST_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Content-Type", "application/json");
    headers.put("Accept", "application/json");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      com.fasterxml.jackson.databind.ObjectMapper jsonOutgoingHelper = new com.fasterxml.jackson.databind.ObjectMapper();
      com.fasterxml.jackson.databind.AnnotationIntrospector jaxbIntrospector = new com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector(com.fasterxml.jackson.databind.type.TypeFactory.defaultInstance());
      com.fasterxml.jackson.databind.AnnotationIntrospector jacksonIntrospector = new com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector();
      jsonOutgoingHelper.setAnnotationIntrospector(com.fasterxml.jackson.databind.AnnotationIntrospector.pair(jacksonIntrospector, jaxbIntrospector));
      httpRequest.setBody(jsonOutgoingHelper.writeValueAsBytes(query));
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        com.fasterxml.jackson.databind.ObjectMapper jsonIngoingHelper = new com.fasterxml.jackson.databind.ObjectMapper();
        com.fedex.cis.audit.common.tbd.v1.AuditListDto dto = jsonIngoingHelper.readValue(ObjectUtility.toString(outputStream.toByteArray()), com.fedex.cis.audit.common.tbd.v1.AuditListDto.class);
        result = (dto != null) ? dto.getAudits() : null;
      } else if (httpResponse.getCode() == 204) {
        // Intentionally does nothing!
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to query audit (v1) with JSON formatted response via C2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  /**
   * Query audit (v2) with XML formatted response.
   * @param token String
   * @param query Query
   * @return QueryResult
   * @throws CisException
   * @author Michael Cronk
   */
  public QueryResult query_v2_Xml(
      String token,
      Query query)
          throws ServerCisException {
    QueryResult result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/v2/query");
    httpRequest.setMethod(HttpRequest.POST_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Content-Type", "application/xml");
    headers.put("Accept", "application/xml");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      httpRequest.setBody(jaxbHelper.marshall(query));
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        result = jaxbHelper.unmarshall(outputStream.toByteArray(), QueryResult.class);
      } else if (httpResponse.getCode() == 204) {
        // Intentionally does nothing!
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to query audit (v2) with XML formatted response via C2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  /**
   * Query audit (v2) with JSON formatted response.
   * @param token String
   * @param query Query
   * @return QueryResult
   * @throws CisException
   * @author Michael Cronk
   */
  public QueryResult query_v2_Json(
      String token,
      Query query)
          throws ServerCisException {
    QueryResult result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/v2/query");
    httpRequest.setMethod(HttpRequest.POST_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Content-Type", "application/json");
    headers.put("Accept", "application/json");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      com.fasterxml.jackson.databind.ObjectMapper jsonOutgoingHelper = new com.fasterxml.jackson.databind.ObjectMapper();
      com.fasterxml.jackson.databind.AnnotationIntrospector jaxbIntrospector = new com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector(com.fasterxml.jackson.databind.type.TypeFactory.defaultInstance());
      com.fasterxml.jackson.databind.AnnotationIntrospector jacksonIntrospector = new com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector();
      jsonOutgoingHelper.setAnnotationIntrospector(com.fasterxml.jackson.databind.AnnotationIntrospector.pair(jacksonIntrospector, jaxbIntrospector));
      httpRequest.setBody(jsonOutgoingHelper.writeValueAsBytes(query));
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        com.fasterxml.jackson.databind.ObjectMapper jsonIngoingHelper = new com.fasterxml.jackson.databind.ObjectMapper();
        result = jsonIngoingHelper.readValue(ObjectUtility.toString(outputStream.toByteArray()), QueryResult.class);
      } else if (httpResponse.getCode() == 204) {
        // Intentionally does nothing!
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to query audit (v2) with JSON formatted response via C2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

}
