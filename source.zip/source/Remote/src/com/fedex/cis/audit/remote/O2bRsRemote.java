package com.fedex.cis.audit.remote;

/**
 * Open-to-Business (o2b) RESTful web service (rs) application remote client.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.common.bean.Ping;

import fedex.cis.common.exception.CisException;
import fedex.cis.common.net.http.*;
import fedex.cis.common.pojo.PojoManager;
import fedex.cis.common.server.exception.ServerCisException;
import fedex.cis.common.util.ObjectUtility;

public class O2bRsRemote {

  // Public constants
  public static final String URL_PROPERTY = "url";

  // Private attributes
  private final String url;
  private final PojoManager jaxbHelper;

  /**
   * Construct remote client.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public O2bRsRemote(java.util.Properties properties) {
    // Set URL
    if (properties != null) {
      url = properties.getProperty(URL_PROPERTY);
    } else {
      url = null;
    }
    if (url == null) { throw new java.lang.NullPointerException("URL not defined"); }
    // Set JAXB helper
    jaxbHelper = new fedex.cis.common.pojo.JaxbPojoManager(null);
  }

  /**
   * Throw exception.
   * @param httpResponse HttpResponse
   * @throws CisException
   * @author Michael Cronk
   */
  private void throwException(
      HttpResponse httpResponse)
          throws CisException {
    throw new CisException("Unexpected HTTP response: " + httpResponse.getCode());
  }

  /**
   * Ping with XML formatted response.
   * @return Ping
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public Ping pingXml()
      throws ServerCisException {
    Ping result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/ping");
    httpRequest.setMethod(HttpRequest.GET_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Accept", "application/xml");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        result = jaxbHelper.unmarshall(outputStream.toByteArray(), Ping.class);
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to ping with XML formatted response via O2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  /**
   * Ping with JSON formatted response.
   * @return Ping
   * @throws CisException
   * @author Michael Cronk
   */
  public Ping pingJson()
      throws CisException {
    Ping result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/ping");
    httpRequest.setMethod(HttpRequest.GET_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Accept", "application/json");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        com.fasterxml.jackson.databind.ObjectMapper jsonHelper = new com.fasterxml.jackson.databind.ObjectMapper();
        result = jsonHelper.readValue(ObjectUtility.toString(outputStream.toByteArray()), Ping.class);
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new CisException("Failed to get ping with JSON formatted response via O2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

}
