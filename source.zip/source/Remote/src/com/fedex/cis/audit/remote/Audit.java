package com.fedex.cis.audit.remote;

@javax.xml.bind.annotation.XmlRootElement
public class Audit {

  private String principal;
  public String getPrincipal() { return principal; }
  public void setPrincipal(String value) { principal = value; }

  private String business;
  public String getBusiness() { return business; }
  public void setBusiness(String value) { business = value; }

  private java.util.Date conducted;
  public java.util.Date getConducted() { return conducted; }
  public void setConducted(java.util.Date value) { conducted = value; }

  private java.util.Date posted;
  public java.util.Date getPosted() { return posted; }
  public void setPosted(java.util.Date value) { posted = value; }

  private String client;
  public String getClient() { return client; }
  public void setClient(String value) { client = value; }

  private String comment;
  public String getComment() { return comment; }
  public void setComment(String value) { comment = value; } 

  private String metadata;
  public String getMetadata() { return metadata; }
  public void setMetadata(String value) { metadata = value; }

  private String transaction;
  public String getTransaction() { return transaction; }
  public void setTransaction(String value) { transaction = value; }

}
