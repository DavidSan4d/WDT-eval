package com.fedex.cis.audit.remote;

/**
 * Business-to-Business (c2b) RESTful web service (rs) application remote client.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.common.bean.Audit;

import fedex.cis.common.exception.CisException;
import fedex.cis.common.net.http.*;
import fedex.cis.common.pojo.PojoManager;
import fedex.cis.common.server.exception.ServerCisException;
import fedex.cis.common.util.ObjectUtility;

public class B2bRsRemote {

  // Public constants
  public static final String URL_PROPERTY = "url";

  // Private attributes
  private final String url;
  private final PojoManager jaxbHelper;

  /**
   * Construct remote client.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public B2bRsRemote(java.util.Properties properties) {
    // Set URL
    if (properties != null) {
      url = properties.getProperty(URL_PROPERTY);
    } else {
      url = null;
    }
    if (url == null) { throw new java.lang.NullPointerException("URL not defined"); }
    // Set JAXB helper
    jaxbHelper = new fedex.cis.common.pojo.JaxbPojoManager(null);
  }

  /**
   * Throw exception.
   * @param httpResponse HttpResponse
   * @throws ServerCisException
   * @author Michael Cronk
   */
  private void throwException(
      HttpResponse httpResponse)
          throws ServerCisException {
    throw new ServerCisException("Unexpected HTTP response: " + httpResponse.getCode());
  }

  /**
   * Record audit (v1).
   * @param token String
   * @param audit com.fedex.cis.audit.common.tbd.Audit
   * @return boolean
   * @throws CisException
   * @author Michael Cronk
   */
  @Deprecated
  public boolean record_v1(
      String token,
      com.fedex.cis.audit.common.tbd.v1.Audit audit)
          throws ServerCisException {
    boolean result = false;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/record");
    httpRequest.setMethod(HttpRequest.POST_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Content-Type", "application/xml");
    headers.put("Accept", "text/plain");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      httpRequest.setBody(jaxbHelper.marshall(audit));
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        result = ObjectUtility.parse(ObjectUtility.toString(outputStream.toByteArray()), false);
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to record audit (v1) via B2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  /**
   * Record audit (v2) with XML formatted response.
   * @param token String
   * @param audit Audit
   * @return RecordResult
   * @throws CisException
   * @author Michael Cronk
   */
  public RecordResult record_v2_Xml(
      String token,
      Audit audit)
          throws ServerCisException {
    RecordResult result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/v2/record");
    httpRequest.setMethod(HttpRequest.POST_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Content-Type", "application/xml");
    headers.put("Accept", "application/xml");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      httpRequest.setBody(jaxbHelper.marshall(audit));
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        result = jaxbHelper.unmarshall(outputStream.toByteArray(), RecordResult.class);
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to record audit (v2) with XML formatted response via B2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

  /**
   * Record audit (v2) with JSON formatted response.
   * @param token String
   * @param audit Audit
   * @return RecordResult
   * @throws CisException
   * @author Michael Cronk
   */
  public RecordResult record_v2_Json(
      String token,
      Audit audit)
          throws ServerCisException {
    RecordResult result = null;
    HttpRequest httpRequest = new HttpRequest();
    httpRequest.setUrl(url + "/v2/record");
    httpRequest.setMethod(HttpRequest.POST_METHOD);
    java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
    headers.put("Authorization", "Bearer " + token);
    headers.put("Content-Type", "application/json");
    headers.put("Accept", "application/json");
    httpRequest.setHeaders(headers);
    java.io.ByteArrayOutputStream outputStream = null;
    try {
      com.fasterxml.jackson.databind.ObjectMapper jsonHelper = new com.fasterxml.jackson.databind.ObjectMapper();
      httpRequest.setBody(jsonHelper.writeValueAsBytes(audit));
      outputStream = new java.io.ByteArrayOutputStream();
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      HttpResponse httpResponse = httpManager.handle(httpRequest);
      if (httpResponse.getCode() == 200) {
        result = jsonHelper.readValue(ObjectUtility.toString(outputStream.toByteArray()), RecordResult.class);
      } else {
        throwException(httpResponse);
      }
    } catch (Exception e) {
      throw new ServerCisException("Failed to record audit (v2) with JSON formatted response via B2B-RS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return result;
  }

}
