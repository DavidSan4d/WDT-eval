package com.fedex.cis.audit.remote;

/**
 * All-to-Business (a2b) RESTful web service (rs) application remote client.
 * @author Michael Cronk
 */

import fedex.cis.common.net.http.HttpResponse;
import fedex.cis.common.pojo.PojoManager;
import fedex.cis.common.server.exception.ServerCisException;

public class A2bRsRemote {

  // Public constants
  public static final String URL_PROPERTY = "url";

  // Private attributes
  private final String url;
  @SuppressWarnings("unused")
  private final PojoManager jaxbHelper;

  /**
   * Construct remote client.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public A2bRsRemote(java.util.Properties properties) {
    // Set URL
    if (properties != null) {
      url = properties.getProperty(URL_PROPERTY);
    } else {
      url = null;
    }
    if (url == null) { throw new java.lang.NullPointerException("URL not defined"); }
    // Set JAXB helper
    jaxbHelper = new fedex.cis.common.pojo.JaxbPojoManager(null);
  }

  /**
   * Throw exception.
   * @param httpResponse HttpResponse
   * @throws ServerCisException
   * @author Michael Cronk
   */
  @SuppressWarnings("unused")
  private void throwException(
      HttpResponse httpResponse)
          throws ServerCisException {
    throw new ServerCisException("Unexpected HTTP response: " + httpResponse.getCode());
  }

}
