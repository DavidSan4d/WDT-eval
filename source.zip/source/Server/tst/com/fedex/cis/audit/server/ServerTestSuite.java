package com.fedex.cis.audit.server;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

import com.fedex.cis.audit.server.business.BusinessTestSuite;
import com.fedex.cis.audit.server.dao.DaoTestSuite;
import com.fedex.cis.audit.server.external.ExternalTestSuite;

@RunWith(Suite.class)
@SuiteClasses({
  ServerHelperTest.class,
  ServerManagerTest.class,
  DaoTestSuite.class,
  BusinessTestSuite.class,
  ExternalTestSuite.class
})

public class ServerTestSuite {
  // Intentionally left blank!
}
