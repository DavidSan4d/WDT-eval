package com.fedex.cis.audit.server.external.vips;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  VipsExternalTest.class
})

public class VipsTestSuite {
  // Intentionally left blank!
}
