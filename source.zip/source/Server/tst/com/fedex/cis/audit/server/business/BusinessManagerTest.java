package com.fedex.cis.audit.server.business;

import static org.junit.Assert.assertNotNull;

import org.junit.*;

import com.fedex.cis.audit.server.ServerTestFixture;

import fedex.cis.common.util.PropertiesUtility;

public class BusinessManagerTest {

  private static java.util.Properties properties = null;
  private static BusinessManager manager = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = ServerTestFixture.getProperties("cis.server.business.");
    manager = new BusinessManager(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    manager = null;
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  @SuppressWarnings("unused")
  private BusinessManager getManager() {
    return manager;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testBusinessManager() {
    BusinessManager result = new BusinessManager(getProperties());
    assertNotNull(result.getGeneralProperties());
    assertNotNull(result.getGeneral());
  }

}
