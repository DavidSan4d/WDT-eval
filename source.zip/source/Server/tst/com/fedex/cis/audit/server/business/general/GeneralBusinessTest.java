package com.fedex.cis.audit.server.business.general;

import static org.junit.Assert.assertNotNull;

import org.junit.*;

import com.fedex.cis.audit.common.bean.Ping;
import com.fedex.cis.audit.server.ServerTestFixture;

import fedex.cis.common.util.PropertiesUtility;

public class GeneralBusinessTest {

  private static java.util.Properties properties = null;
  private static GeneralBusiness business = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = ServerTestFixture.getProperties("cis.server.business.general.");
    business = new GeneralBusiness(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  private GeneralBusiness getBusiness() {
    return business;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testGeneralBusiness() {
    GeneralBusiness result = new GeneralBusiness();
    assertNotNull(result);
  }

  @Test
  public void testGeneralBusiness_Properties() {
    GeneralBusiness result = new GeneralBusiness(getProperties());
    assertNotNull(result);
  }

  @Test
  public void testPing() {
    Ping result = getBusiness().ping();
    assertNotNull(result);
  }

}
