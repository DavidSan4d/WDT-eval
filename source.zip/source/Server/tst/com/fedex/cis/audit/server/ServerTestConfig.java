package com.fedex.cis.audit.server;

import org.springframework.context.annotation.Configuration;

import fedex.cis.common.util.PropertiesUtility;

@Configuration
@org.springframework.context.annotation.ComponentScan(basePackages = {"com.fedex.cis.audit.server.dao","com.fedex.cis.audit.server.business"})
@org.springframework.transaction.annotation.EnableTransactionManagement
public class ServerTestConfig {

  @org.springframework.context.annotation.Bean
  public org.springframework.transaction.PlatformTransactionManager transactionManager() {
    return new org.springframework.transaction.jta.WebLogicJtaTransactionManager();
  }

  @org.springframework.context.annotation.Bean
  public org.springframework.jdbc.core.JdbcTemplate jdbcTemplate(javax.sql.DataSource dataSource) {
    return new org.springframework.jdbc.core.JdbcTemplate(dataSource);
  }

  @org.springframework.context.annotation.Bean
  public javax.sql.DataSource dataSource(java.util.Properties repositoryProperties) throws javax.naming.NamingException {
    java.util.Properties contextProperties = PropertiesUtility.extractProperties(repositoryProperties, "context.weblogic.");
    javax.naming.Context context = new javax.naming.InitialContext(contextProperties);
    String jndiName = repositoryProperties.getProperty("jndi");
    return (javax.sql.DataSource) context.lookup(jndiName);
  }

  @org.springframework.context.annotation.Bean
  public java.util.Properties repositoryProperties(java.util.Properties allProperties) {
    return PropertiesUtility.extractProperties(allProperties, "cis.server.dao.repository.");
  }

  @org.springframework.context.annotation.Bean
  public java.util.Properties allProperties() throws Exception {
    return ServerTestFixture.getProperties();
  }

}
