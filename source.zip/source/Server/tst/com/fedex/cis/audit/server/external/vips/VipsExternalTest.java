package com.fedex.cis.audit.server.external.vips;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;
import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.server.ServerTestFixture;

import fedex.cis.common.util.*;

public class VipsExternalTest {

  private static java.util.Properties properties = null;
  private static VipsExternal external = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = ServerTestFixture.getProperties("cis.server.external.vips.");
    external = new VipsExternal(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  private VipsExternal getExternal() {
    return external;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testVipsExternal() {
    VipsExternal result = new VipsExternal(getProperties());
    assertNotNull(result);
  }

  @Test
  public void testRecord() throws Exception {
    Record record = CommonTestFixture.getRecord();
    record.setPrincipal("246690"); // Requires pilot employee number!
    RecordResult result = new RecordResult(false, new java.util.LinkedList<String>(), null);
    boolean success = getExternal().record(result, record);
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertEquals("UNKNOWN", result.getReference());
  }

  @Test
  public void testRecord_WithReference() throws Exception {
    Record record = CommonTestFixture.getRecord();
    record.setPrincipal("246690"); // Requires pilot employee number!
    RecordResult result = new RecordResult(false, new java.util.LinkedList<String>(), "REFERENCE");
    boolean success = getExternal().record(result, record);
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertEquals("REFERENCE", result.getReference());
  }

  @Test
  public void testRecord_WithNonPilot() throws Exception {
    Record record = CommonTestFixture.getRecord();
    RecordResult result = new RecordResult(false, new java.util.LinkedList<String>(), null);
    boolean success = getExternal().record(result, record);
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test
  public void testQuery() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    //System.out.println(result.getRecords());
  }

  @Test
  @Ignore
  public void testQuery_Raw() throws Exception {
    PrincipalFilter principalFilter = new PrincipalFilter("97000");
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getDate(2019, 10, 22), DateUtility.getDate(2019, 10, 23));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertTrue(success);
    System.out.println(result);
  }

  @Test
  public void testQuery_WithNotPilot() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test 
  public void testQuery_WithVipsError() throws Exception {
    java.util.Date date = DateUtility.addMonths(DateUtility.getDate(), 1); // Date cannot be in the future!
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertFalse(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMerge() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    Record record = CommonTestFixture.getRecord();
    record.setConducted(DateUtility.addMonths(date, 1));
    //record.setPrincipal("246690");
    //record.setConducted(DateUtility.getDate(2019, 8, 1, 0, 54, 58, 123));
    //record.setComment("Open Time - MEM 67 CAP 30JUL19 - 01SEP19");
    result.getRecords().add(record);
    boolean success = getExternal().query(result, query);
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    //System.out.println(result.getRecords());
    Record lastRecord = null;
    for (Record resultRecord : result.getRecords()) { lastRecord = resultRecord; }
    assertSame(record, lastRecord);
  }

  @Test
  public void testQuery_WithQueryRelationshipNotSupported() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    query.setRelationship(Filter.OPERATOR_MATCH);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertFalse(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test 
  public void testQuery_WithNestedFilterOperatorNotSupported() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    NestedFilter nestedFilter = CommonTestFixture.getNestedFilter();
    nestedFilter.setOperator(Filter.OPERATOR_MATCH);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, nestedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertFalse(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test 
  public void testQuery_WithPrincipalFilterOperatorNotSupported() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    principalFilter.setOperator(Filter.OPERATOR_MATCH);
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertFalse(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(2, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test 
  public void testQuery_WithPrincipalFilterDuplicateDefined() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, principalFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertFalse(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test 
  public void testQuery_WithConductedFilterOperatorNotSupported() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    conductedFilter.setOperator(Filter.OPERATOR_MATCH);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertFalse(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(2, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterDuplicateDefined() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertFalse(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithFilterNotSupported() throws Exception {
    java.util.Date date = DateUtility.getDate();
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getFirstDayInMonth(DateUtility.getStartOfDay(date)), DateUtility.getLastDayInMonth(DateUtility.getEndOfDay(date)));
    TextFilter textFilter = CommonTestFixture.getTextFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, textFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    //System.out.println(result.getRecords());
  }

  @Test
  public void testQuery_WithPrincipalAndConductedFilterNotFullyDefined() throws Exception {
    PrincipalFilter principalFilter = new PrincipalFilter("246690"); // Requires pilot employee number!
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = getExternal().query(result, query);
    assertFalse(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

}
