package com.fedex.cis.audit.server.dao;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

import com.fedex.cis.audit.server.dao.repository.RepositoryTestSuite;

@RunWith(Suite.class)
@SuiteClasses({
  RepositoryTestSuite.class
})

public class DaoTestSuite {
  // Intentionally left blank!
}
