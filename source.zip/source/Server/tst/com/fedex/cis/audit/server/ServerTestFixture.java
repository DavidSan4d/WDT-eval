package com.fedex.cis.audit.server;

import fedex.cis.common.property.*;
import fedex.cis.common.util.PropertiesUtility;

public class ServerTestFixture {

  private static volatile java.util.Properties properties = null;
  private static String propertiesLock = new String("PropertiesLock");

  public static java.util.Properties getProperties() throws Exception {
    return getProperties(null);
  }

  public static java.util.Properties getProperties(String propertyPrefix) throws Exception {
    if (properties == null) {
      synchronized (propertiesLock) {
        if (properties == null) {
          java.util.Properties serverProperties = getPropertiesByEnvironment();
          properties = PropertiesUtility.expandProperties(serverProperties, null, null);
        }
      }
    }
    if (propertyPrefix == null) {
      return PropertiesUtility.copyProperties(properties);
    } else {
      return PropertiesUtility.extractProperties(properties, propertyPrefix);
    }
  }

  private static java.util.Properties getPropertiesByEnvironment() throws Exception {
    java.util.Properties result = null;
    String cisEnvironment = java.lang.System.getProperty("CIS_ENVIRONMENT");
    java.lang.System.setProperty("cis.deployment", "../Shared/etc/deployment_" + cisEnvironment + ".properties");
    PropertyContext propertyContext = PropertyHelper.getEnvironmentPropertyContext("cis.deployment", "cis.deployment.server.");
    PropertyManager propertyManager = PropertyFactory.getManager(propertyContext);
    result = propertyManager.getProperties();
    return result;
  }

}
