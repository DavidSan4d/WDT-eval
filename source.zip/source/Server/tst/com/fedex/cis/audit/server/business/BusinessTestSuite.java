package com.fedex.cis.audit.server.business;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

import com.fedex.cis.audit.server.business.general.GeneralTestSuite;

@RunWith(Suite.class)
@SuiteClasses({
  BusinessManagerTest.class,
  GeneralTestSuite.class,
  RecordServiceTest.class
})

public class BusinessTestSuite {
  // Intentionally left blank!
}
