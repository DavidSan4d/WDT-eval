package com.fedex.cis.audit.server.business.general;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  GeneralBusinessTest.class
})

public class GeneralTestSuite {
  // Intentionally left blank!
}
