package com.fedex.cis.audit.server.external;

import static org.junit.Assert.assertNotNull;

import org.junit.*;

import com.fedex.cis.audit.server.ServerTestFixture;

import fedex.cis.common.util.PropertiesUtility;

public class ExternalManagerTest {

  private static java.util.Properties properties = null;
  private static ExternalManager manager = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = ServerTestFixture.getProperties("cis.server.external.");
    manager = new ExternalManager(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    manager = null;
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  @SuppressWarnings("unused")
  private ExternalManager getManager() {
    return manager;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testExternalManager() {
    ExternalManager result = new ExternalManager(getProperties());
    assertNotNull(result.getVips());
  }

}
