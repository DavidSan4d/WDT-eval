package com.fedex.cis.audit.server.external;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

import com.fedex.cis.audit.server.external.vips.VipsTestSuite;

@RunWith(Suite.class)
@SuiteClasses({
  ExternalManagerTest.class,
  VipsTestSuite.class
})

public class ExternalTestSuite {
  // Intentionally left blank!
}
