package com.fedex.cis.audit.server;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.server.business.BusinessManager;
import com.fedex.cis.audit.server.external.ExternalManager;

public class ServerHelperTest {

  private static ServerHelper helper = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    helper = new ServerHelper();
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    helper = null;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  private ServerHelper getHelper() {
    return helper;
  }

  @Test
  public void testServerHelper() throws Exception {
    ServerHelper result = new ServerHelper();
    assertNotNull(result);
  }

  @Test
  public void testGetCisEnvironment() throws Exception {
    String result = getHelper().getCisEnvironment();
    assertNotNull(result);
  }

  @Test
  public void testRefresh() throws Exception {
    java.util.Properties properties1 = helper.getProperties("cis.server.");
    BusinessManager business1 = helper.getBusiness();
    ExternalManager external1 = helper.getExternal();
    assertNotNull(properties1);
    assertNotNull(business1);
    assertNotNull(external1);
    java.util.Properties properties2 = helper.getProperties("cis.server.");
    BusinessManager business2 = helper.getBusiness();
    ExternalManager external2 = helper.getExternal();
    assertEquals(properties1, properties2);
    assertSame(business1, business2);
    assertSame(external1, external2);
    Thread.sleep(10);
    helper.refresh();
    java.util.Properties properties3 = helper.getProperties("cis.server.");
    BusinessManager business3 = helper.getBusiness();
    ExternalManager external3 = helper.getExternal();
    assertNotSame(properties2, properties3);
    assertNotSame(business2, business3);
    assertNotSame(external2, external3);
  }

  @Test
  public void testGetProperties() throws Exception {
    java.util.Properties result1 = helper.getProperties("cis.server.");
    assertNotNull(result1);
    java.util.Properties result2 = helper.getProperties(null);
    assertNotNull(result2);
    assertNotEquals(result1, result2);
  }

  @Test
  public void testGetBusiness() throws Exception {
    BusinessManager result = helper.getBusiness();
    assertNotNull(result);
  }

  @Test
  public void testGetExternal() throws Exception {
    ExternalManager result = helper.getExternal();
    assertNotNull(result);
  }

  public static void main(String[] args) {
    try {
      ServerHelperTest test = new ServerHelperTest();
      ServerHelperTest.setUpBeforeClass(); 
      ServerHelper helper = test.getHelper();
      new Thread(test.new JUnitThread(helper, "A")).start();
      new Thread(test.new JUnitThread(helper, "B")).start();
      new Thread(test.new JUnitThread(helper, "C")).start();
      new Thread(test.new JUnitThread(helper, "D")).start();
      new Thread(test.new JUnitThread(helper, "E")).start();
      new Thread(test.new JUnitThread(helper, "F")).start();
      new Thread(test.new JUnitThread(helper, "G")).start();
      new Thread(test.new JUnitThread(helper, "H")).start();
      new Thread(test.new JUnitThread(helper, "I")).start();
      new Thread(test.new JUnitThread(helper, "J")).start();
      new Thread(test.new JUnitThread(helper, "K")).start();
      new Thread(test.new JUnitThread(helper, "L")).start();
      new Thread(test.new JUnitThread(helper, "M")).start();
      new Thread(test.new JUnitThread(helper, "N")).start();
      new Thread(test.new JUnitThread(helper, "O")).start();
      new Thread(test.new JUnitThread(helper, "P")).start();
      new Thread(test.new JUnitThread(helper, "Q")).start();
      new Thread(test.new JUnitThread(helper, "R")).start();
      new Thread(test.new JUnitThread(helper, "S")).start();
      new Thread(test.new JUnitThread(helper, "T")).start();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public class JUnitThread implements Runnable {

    private ServerHelper helper = null;
    private String label = null;

    public JUnitThread(ServerHelper helper, String label) {
      this.helper = helper;
      this.label = label; 
    }

    @Override
    public void run() {
      System.out.println("Starting <" + label + ">");
      for (int i = 0; i < 25; i++) {
        try {
          java.util.Properties properties = helper.getProperties("cis.server.");
          if (properties == null) { System.err.println("Error <" + label + ">: getProperties()"); }
          BusinessManager business = helper.getBusiness();
          if (business == null) { System.err.println("Error <" + label + ">: getBusiness()"); }
          ExternalManager external = helper.getExternal();
          if (external == null) { System.err.println("Error <" + label + ">: getExternal()"); }
          helper.refresh();
        } catch (Exception e) {
          System.err.println("Caught <" + label + ">");
          e.printStackTrace();
        }
      }
      System.out.println("Finished <" + label + ">");
    }

  }

}
