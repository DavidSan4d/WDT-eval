package com.fedex.cis.audit.server.dao.repository;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.fedex.cis.audit.common.CommonTestFixture;
import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.server.ServerTestConfig;

@RunWith(org.springframework.test.context.junit4.SpringJUnit4ClassRunner.class)
@org.springframework.test.context.ContextConfiguration(classes={ServerTestConfig.class})
public class RecordRepositoryTest {

  @org.springframework.beans.factory.annotation.Autowired
  private RecordRepository repository;

  @Test
  public void testCreate() throws Exception {
    Record value = CommonTestFixture.getRecord();
    int result = 0;
    try {
      result = repository.create(value);
    } finally {
      repository.delete(value.getReference());
    }
    assertEquals(1, result);
  }

  @Test
  public void testRead() throws Exception {
    Record value = CommonTestFixture.getRecord();
    Record result = null;
    try {
      repository.create(value);
      result = repository.read(value.getReference());
    } finally {
      repository.delete(value.getReference());
    }
    assertEquals(value, result);
  }

  @Test
  public void testRead_NotFound() {
    Record value = CommonTestFixture.getRecord();
    Record result = null;
    try {
      result = repository.read(value.getReference());
    } finally {
    }
    assertNull(result);
  }

  @Test
  public void testUpdate() throws Exception {
    Record value = CommonTestFixture.getRecord();
    int result = 0;
    Record recordResult = null;
    try {
      repository.create(value);
      value.setBusiness("CHANGED");
      result = repository.update(value.getReference(), value);
      recordResult = repository.read(value.getReference());
    } finally {
      repository.delete(value.getReference());
    }
    assertEquals(1, result);
    assertEquals(value, recordResult);
  }

  @Test
  public void testUpdate_NotFound() throws Exception {
    Record value = CommonTestFixture.getRecord();
    int result = 0;
    try {
      result = repository.update(value.getReference(), value);
    } finally {
    }
    assertEquals(0, result);
  }

  @Test
  public void testDelete() throws Exception {
    Record value = CommonTestFixture.getRecord();
    int result = 0;
    try {
      repository.create(value);
      result = repository.delete(value.getReference());
    } finally {
      repository.delete(value.getReference());
    }
    assertEquals(1, result);
  }

  @Test
  public void testDelete_NotFound() throws Exception {
    Record value = CommonTestFixture.getRecord();
    int result = 0;
    try {
      result = repository.delete(value.getReference());
    } finally {
    }
    assertEquals(0, result);
  }

  @Test
  public void testDuplicate() throws Exception {
    Record value = CommonTestFixture.getRecord();
    RecordResult valueResult = new RecordResult(false, new java.util.LinkedList<String>(), null);
    boolean result = false;
    try {
      repository.record(valueResult, value);
      result = repository.duplicate(value.getPrincipal(), value.getBusiness(), value.getConducted());
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(result);
  }

  @Test
  public void testDuplicate_WithNotFound() throws Exception {
    Record value = CommonTestFixture.getRecord();
    boolean result = false;
    try {
      result = repository.duplicate(value.getPrincipal(), value.getBusiness(), value.getConducted());
    } finally {
    }
    assertFalse(result);
  }

  @Test
  public void testRecord() throws Exception {
    Record value = CommonTestFixture.getRecord();
    RecordResult result = new RecordResult(false, new java.util.LinkedList<String>(), null);
    boolean success = false;
    try {
      success = repository.record(result, value);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertSame(value.getReference(), result.getReference());
  }

  @Test
  public void testQuery() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithNotFound() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithNestedFilter() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter nestedFilter = CommonTestFixture.getNestedFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, nestedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithOnlyNestedFilter() throws Exception {
    Record value = CommonTestFixture.getRecord();
    NestedFilter nestedFilter = CommonTestFixture.getNestedFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(nestedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithNestedFilterContainingDateRangeFilterOnly() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter nestedFilter = CommonTestFixture.getNestedFilter();
    nestedFilter.getQuery().setFilters(java.util.Arrays.asList(CommonTestFixture.getDateRangeFilter()));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, nestedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(2, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithComplicatedNestedFilters() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter nestedFilter1 = CommonTestFixture.getNestedFilter();
    NestedFilter nestedFilter2 = CommonTestFixture.getNestedFilter();
    NestedFilter nestedFilter2a = CommonTestFixture.getNestedFilter();
    nestedFilter2a.getQuery().setRelationship(Query.RELATIONSHIP_OR);
    nestedFilter2.getQuery().getFilters().add(nestedFilter2a);
    NestedFilter nestedFilter2ai = CommonTestFixture.getNestedFilter();
    nestedFilter2ai.getQuery().setFilters(java.util.Arrays.asList(CommonTestFixture.getClientFilter()));
    nestedFilter2a.getQuery().getFilters().add(nestedFilter2ai);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, nestedFilter1, nestedFilter2);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithCommentFilter() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    CommentFilter commentFilter = CommonTestFixture.getCommentFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, commentFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithRelationshipNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter nestedFilter = CommonTestFixture.getNestedFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, nestedFilter);
    Query query = new Query(filters);
    query.setRelationship("NOT_SUPPORTED");
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithNestedFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter nestedFilter = CommonTestFixture.getNestedFilter();
    nestedFilter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, nestedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithPrincipalFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    principalFilter.setOperator("NOT_SUPPORTED");
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    conductedFilter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithCommentFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    CommentFilter commentFilter = CommonTestFixture.getCommentFilter();
    commentFilter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, commentFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithTextFilter() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    TextFilter textFilter = CommonTestFixture.getTextFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, textFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMultipleIssues() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    principalFilter.setOperator("NOT_SUPPORTED");
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    conductedFilter.setOperator("NOT_SUPPORTED");
    NestedFilter nestedFilter = CommonTestFixture.getNestedFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, nestedFilter);
    Query query = new Query(filters);
    query.setRelationship("NOT_SUPPORTED");
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(3, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithBusinessFilter() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    BusinessFilter businessFilter = CommonTestFixture.getBusinessFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, businessFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithBusinessFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    BusinessFilter businessFilter = CommonTestFixture.getBusinessFilter();
    businessFilter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, businessFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithClientFilter() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    ClientFilter clientFilter = CommonTestFixture.getClientFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, clientFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithClientFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    ClientFilter clientFilter = CommonTestFixture.getClientFilter();
    clientFilter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, clientFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMetadataFilter() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    MetadataFilter metadataFilter = CommonTestFixture.getMetadataFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, metadataFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithMetadataFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    MetadataFilter metadataFilter = CommonTestFixture.getMetadataFilter();
    metadataFilter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, metadataFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithTransactionFilter() throws Exception {
    Record value = CommonTestFixture.getRecord();
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, transactionFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      repository.create(value);
      success = repository.query(result, query);
    } finally {
      repository.delete(value.getReference());
    }
    assertTrue(success);
    assertFalse(result.isSuccess());
    assertNotNull(result.getMessages());
    assertEquals(0, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(1, result.getRecords().size());
    assertEquals(value, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithTransactionFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    transactionFilter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, transactionFilter);
    Query query = new Query(filters);
    QueryResult result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
    boolean success = false;
    try {
      success = repository.query(result, query);
    } finally {
    }
    assertFalse(success);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertNotNull(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNotNull(result.getRecords());
    assertEquals(0, result.getRecords().size());
  }

}
