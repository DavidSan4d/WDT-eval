package com.fedex.cis.audit.server.dao.repository;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  RecordRepositoryTest.class
})

public class RepositoryTestSuite {
  // Intentionally left blank!
}
