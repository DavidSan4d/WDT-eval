package com.fedex.cis.audit.server.business;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.RunWith;

import com.fedex.cis.audit.common.CommonTestFixture;
import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.server.ServerTestConfig;
import com.fedex.cis.audit.server.dao.repository.RecordRepository;

import fedex.cis.common.util.DateUtility;

@RunWith(org.springframework.test.context.junit4.SpringJUnit4ClassRunner.class)
@org.springframework.test.context.ContextConfiguration(classes={ServerTestConfig.class})
public class RecordServiceTest {

  @org.springframework.beans.factory.annotation.Autowired
  private RecordService service;

  @org.springframework.beans.factory.annotation.Autowired
  private RecordRepository repository;

  @Test
  public void testRecord() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = null;
    try {
      result = service.record(audit, true, who);
    } finally {
      repository.delete(result.getReference());
    }
    assertNotNull(result);
    assertTrue(result.isSuccess());
    assertEquals(0, result.getMessages().size());
    //System.out.println(result.getReference());
    assertNotNull(result.getReference());
  }

  @Test(expected=RuntimeException.class)
  public void testRecord_WithExists() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = null;
    RecordResult resultReference = null;
    try {
      resultReference = service.record(audit, true, who);
      result = service.record(audit, true, who);
    } catch (Exception e) {
      //e.printStackTrace();
      throw e;
    } finally {
      repository.delete(resultReference.getReference());
    }
    assertNull(result);
  }

  @Test
  public void testRecord_WithNotPersist() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = null;
    try {
      result = service.record(audit, false, who);
    } finally {
    }
    assertNotNull(result);
    assertTrue(result.isSuccess());
    assertEquals(0, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithAuditNotDefined() throws Exception {
    Audit audit = null;
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithPrincipalNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setPrincipal(null);
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithBusinessNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setBusiness(null);
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithConductedNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setConducted(null);
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithFutureConducted() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setConducted(DateUtility.addDays(DateUtility.getDate(), 1));
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithPostedNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setPosted(null);
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithFuturePosted() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setPosted(DateUtility.addDays(DateUtility.getDate(), 1));
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithPostedBeforeConducted() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setPosted(DateUtility.addDays(audit.getConducted(), -1));
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithClientNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setClient(null);
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithCommentNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setComment(null);
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithMetadataNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setMetadata(null);
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test 
  public void testRecord_WithTransactionNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    audit.setTransaction(null);
    String who = CommonTestFixture.getRecord().getWho();
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test
  public void testRecord_WithWhoNotDefined() throws Exception {
    Audit audit = CommonTestFixture.getAudit();
    String who = null;
    RecordResult result = service.record(audit, true, who);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertNull(result.getReference());
  }

  @Test
  @Ignore
  public void testQuery_Raw() throws Exception {
    PrincipalFilter principalFilter = new PrincipalFilter("97000");
    ConductedFilter conductedFilter = new ConductedFilter(DateUtility.getDate(2019, 10, 22), DateUtility.getDate(2019, 10, 23));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    System.out.println(result);
  }

  @Test
  public void testQuery() throws Exception {
    Query query = CommonTestFixture.getQuery();
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertTrue(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(5, result.getMessages().size());
    //System.out.println(result.getRecords());
  }

  @Test
  public void testQuery_WithPersisted() throws Exception {
    Record record = CommonTestFixture.getRecord();
    Query query = CommonTestFixture.getQuery();
    QueryResult result = null;
    try {
      repository.create(record);
      result = service.query(query, true);
    } finally {
      repository.delete(record.getReference());
    }
    assertNotNull(result);
    assertTrue(result.isSuccess());
    //System.err.println(result.getMessages());
    assertEquals(5, result.getMessages().size());
    assertEquals(1, result.getRecords().size());
    assertEquals(record, result.getRecords().iterator().next());
  }

  @Test
  public void testQuery_WithPersistedButIgnored() throws Exception {
    Record record = CommonTestFixture.getRecord();
    Query query = CommonTestFixture.getQuery();
    QueryResult result = null;
    try {
      repository.create(record);
      result = service.query(query, false);
    } finally {
      repository.delete(record.getReference());
    }
    assertNotNull(result);
    assertTrue(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(5, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithNotDefined() throws Exception {
    Query query = null;
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithRelationshipNotDefined() throws Exception {
    Query query = CommonTestFixture.getQuery();
    query.setRelationship(null);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithRelationshipNotSupported() throws Exception {
    Query query = CommonTestFixture.getQuery();
    query.setRelationship("NOT_SUPPORTED");
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithFiltersNotDefined() throws Exception {
    Query query = CommonTestFixture.getQuery();
    query.setFilters(null);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(2, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithNestedFilterOperatorNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter filter = CommonTestFixture.getNestedFilter();
    filter.setOperator(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithNestedFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter filter = CommonTestFixture.getNestedFilter();
    filter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithNestedFilterQueryNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter filter = CommonTestFixture.getNestedFilter();
    filter.setQuery(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithPrincipalFilterOperatorNotDefined() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    PrincipalFilter filter = CommonTestFixture.getPrincipalFilter();
    filter.setOperator(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithPrincipalFilterOperatorNotSupported() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    PrincipalFilter filter = CommonTestFixture.getPrincipalFilter();
    filter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithPrincipalFilterTextNotDefined() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    PrincipalFilter filter = CommonTestFixture.getPrincipalFilter();
    filter.setText(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterOperatorNotDefined() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    ConductedFilter filter = CommonTestFixture.getConductedFilter();
    filter.setOperator(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterOperatorNotSupported() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    ConductedFilter filter = CommonTestFixture.getConductedFilter();
    filter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterFromDateNotDefined() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    ConductedFilter filter = CommonTestFixture.getConductedFilter();
    filter.setFromDate(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterToDateNotDefined() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    ConductedFilter filter = CommonTestFixture.getConductedFilter();
    filter.setToDate(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterToDateBeforeFrom() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    ConductedFilter filter = CommonTestFixture.getConductedFilter();
    filter.setToDate(DateUtility.addDays(filter.getFromDate(), -1));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterFutureDate() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    ConductedFilter filter = CommonTestFixture.getConductedFilter();
    filter.setFromDate(DateUtility.addDays(DateUtility.getDate(), 1));
    filter.setToDate(DateUtility.addDays(filter.getFromDate(), 1));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithConductedFilterDurationTooLong() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    ConductedFilter filter = CommonTestFixture.getConductedFilter();
    filter.setToDate(DateUtility.addMonths(filter.getFromDate(), 7));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithCommentFilterOperatorNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    CommentFilter filter = CommonTestFixture.getCommentFilter();
    filter.setOperator(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithCommentFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    CommentFilter filter = CommonTestFixture.getCommentFilter();
    filter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithCommentFilterTextNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    CommentFilter filter = CommonTestFixture.getCommentFilter();
    filter.setText(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithCommentFilterTextContainsInvalidCharacter() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    CommentFilter filter = CommonTestFixture.getCommentFilter();
    filter.setText("INVALID_CHARACTER");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test 
  public void testQuery_WithFilterNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    TextFilter filter = CommonTestFixture.getTextFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test 
  public void testQuery_WithOnlyTransactionFilterDefined() throws Exception {
    TransactionFilter transactionFilter = CommonTestFixture.getTransactionFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(transactionFilter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertTrue(result.isSuccess());
    assertEquals(2, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test 
  public void testQuery_WithOnlyConductedFilterDefined() throws Exception {
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    java.util.Collection<Filter> filters = java.util.Arrays.asList(conductedFilter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithBusinessFilterOperatorNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    BusinessFilter filter = CommonTestFixture.getBusinessFilter();
    filter.setOperator(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithBusinessFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    BusinessFilter filter = CommonTestFixture.getBusinessFilter();
    filter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithBusinessFilterTextNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    BusinessFilter filter = CommonTestFixture.getBusinessFilter();
    filter.setText(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithClientFilterOperatorNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    ClientFilter filter = CommonTestFixture.getClientFilter();
    filter.setOperator(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithClientFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    ClientFilter filter = CommonTestFixture.getClientFilter();
    filter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithClientFilterTextNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    ClientFilter filter = CommonTestFixture.getClientFilter();
    filter.setText(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMetadataFilterOperatorNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    MetadataFilter filter = CommonTestFixture.getMetadataFilter();
    filter.setOperator(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMetadataFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    MetadataFilter filter = CommonTestFixture.getMetadataFilter();
    filter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMetadataFilterTypeNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    MetadataFilter filter = CommonTestFixture.getMetadataFilter();
    filter.setType(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMetadataFilterTypeContainsInvalidCharacter() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    MetadataFilter filter = CommonTestFixture.getMetadataFilter();
    filter.setType("INVALID CHARACTER");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMetadataFilterTextNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    MetadataFilter filter = CommonTestFixture.getMetadataFilter();
    filter.setText(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithMetadataFilterTextContainsInvalidCharacter() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    MetadataFilter filter = CommonTestFixture.getMetadataFilter();
    filter.setText("INVALID CHARACTER");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithTransactionFilterOperatorNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    TransactionFilter filter = CommonTestFixture.getTransactionFilter();
    filter.setOperator(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithTransactionFilterOperatorNotSupported() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    TransactionFilter filter = CommonTestFixture.getTransactionFilter();
    filter.setOperator("NOT_SUPPORTED");
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithTransactionFilterTextNotDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    TransactionFilter filter = CommonTestFixture.getTransactionFilter();
    filter.setText(null);
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(1, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

  @Test
  public void testQuery_WithNestedAndNoSupportedFilterDefined() throws Exception {
    PrincipalFilter principalFilter = CommonTestFixture.getPrincipalFilter();
    ConductedFilter conductedFilter = CommonTestFixture.getConductedFilter();
    NestedFilter filter = CommonTestFixture.getNestedFilter();
    filter.getQuery().setFilters(java.util.Arrays.asList(CommonTestFixture.getTextFilter()));
    java.util.Collection<Filter> filters = java.util.Arrays.asList(principalFilter, conductedFilter, filter);
    Query query = new Query(filters);
    QueryResult result = service.query(query, true);
    assertNotNull(result);
    assertFalse(result.isSuccess());
    //System.out.println(result.getMessages());
    assertEquals(2, result.getMessages().size());
    assertEquals(0, result.getRecords().size());
  }

}
