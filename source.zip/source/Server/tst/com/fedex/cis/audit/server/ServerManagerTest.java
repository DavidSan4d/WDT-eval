package com.fedex.cis.audit.server;

import static org.junit.Assert.assertNotNull;

import org.junit.*;

import com.fedex.cis.audit.server.business.BusinessManager;
import com.fedex.cis.audit.server.external.ExternalManager;

public class ServerManagerTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testGetCisEnvironment() throws Exception {
    String result = ServerManager.getCisEnvironment();
    assertNotNull(result);
  }

  @Test
  public void testRefresh() {
    ServerManager.refresh();
  }

  @Test
  public void testGetProperties() throws Exception {
    java.util.Properties result = ServerManager.getProperties("cis.server.");
    assertNotNull(result);
  }

  @Test
  public void testGetBusiness() throws Exception {
    BusinessManager result = ServerManager.getBusiness();
    assertNotNull(result);
  }

  @Test
  public void testGetExternal() throws Exception {
    ExternalManager result = ServerManager.getExternal();
    assertNotNull(result);
  }

}
