package com.fedex.cis.audit.server.business;

/**
 * Business manager.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.server.business.general.GeneralBusiness;

import fedex.cis.common.util.PropertiesUtility;

public class BusinessManager {

  // Private attributes
  private final java.util.Properties generalProperties;
  private final GeneralBusiness generalBusiness;

  /**
   * Construct business manager.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public BusinessManager(java.util.Properties properties) {
    generalProperties = PropertiesUtility.extractProperties(properties, "general.");
    generalBusiness = new GeneralBusiness(generalProperties);
  }

  /**
   * Get general properties.
   * @return java.util.Properties
   * @author Michael Cronk
   */
  public java.util.Properties getGeneralProperties() {
    return generalProperties;
  }

  /**
   * Get general business.
   * @return GeneralBusiness
   * @author Michael Cronk
   */
  public GeneralBusiness getGeneral() {
    return generalBusiness;
  }

}
