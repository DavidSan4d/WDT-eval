package com.fedex.cis.audit.server;

import fedex.cis.common.util.PropertiesUtility;

@org.springframework.context.annotation.Configuration
@org.springframework.transaction.annotation.EnableTransactionManagement
public class ServerConfig {

  @org.springframework.context.annotation.Bean
  public org.springframework.transaction.PlatformTransactionManager transactionManager() {
    return new org.springframework.transaction.jta.WebLogicJtaTransactionManager();
  }

  @org.springframework.context.annotation.Bean
  public org.springframework.jdbc.core.JdbcTemplate jdbcTemplate(javax.sql.DataSource dataSource) {
    return new org.springframework.jdbc.core.JdbcTemplate(dataSource);
  }

  @org.springframework.context.annotation.Bean
  public javax.sql.DataSource dataSource(java.util.Properties repositoryProperties) throws javax.naming.NamingException {
    javax.naming.Context context = new javax.naming.InitialContext();
    String jndiName = repositoryProperties.getProperty("jndi");
    return (javax.sql.DataSource) context.lookup(jndiName);
  }

  @org.springframework.context.annotation.Bean
  public java.util.Properties repositoryProperties(java.util.Properties allProperties) {
    return PropertiesUtility.extractProperties(allProperties, "cis.server.dao.repository.");
  }

  @org.springframework.context.annotation.Bean
  public java.util.Properties allProperties() throws Exception {
    return ServerManager.getProperties(null);
  }

}
