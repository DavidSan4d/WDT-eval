package com.fedex.cis.audit.server.business;

import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.server.ServerManager;
import com.fedex.cis.audit.server.dao.repository.RecordRepository;

import fedex.cis.common.exception.CisException;
import fedex.cis.common.service.util.ServiceUtility;
import fedex.cis.common.util.*;

@org.springframework.stereotype.Service
public class RecordService {

  private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RecordService.class);

  @org.springframework.beans.factory.annotation.Autowired
  private RecordRepository repository;

  /**
   * Record audit.
   * 
   * result.success : True if not aborted
   * result.value   : True if modified
   * 
   * @param audit Audit
   * @param persist boolean
   * @param who String
   * @return RecordResult
   * @throws CisException
   * @author Michael Cronk
   */
  @org.springframework.transaction.annotation.Transactional
  public RecordResult record(
      Audit audit,
      boolean persist, // For backward compatibility!
      String who) {
    RecordResult result = null;
    try {
      result = new RecordResult(false, new java.util.LinkedList<String>(), null);
      boolean success = false;

      // Parse record
      Record record = _prepareRecord(result, audit, who);
      if (record == null) { return result; }

      // Update repository
      if (persist) {
        if (repository.duplicate(record.getPrincipal(), record.getBusiness(), record.getConducted())) {
          String message = record.getPrincipal() + "/" + record.getBusiness() + "/" + record.getConducted();
          throw new CisException("Record already exists (principal/business/conducted): " + message, true);
        }
        success |= repository.record(result, record);
      }

      // Update VIPS
      try {
        success |= ServerManager.getExternal().getVips().record(result, record);
      } catch (Exception e) {
        String message = "VIPS: Audit record partially failed";
        result.getMessages().add(message);
        if (logger.isErrorEnabled()) { logger.error(message, e); }
      }

      result.setSuccess(success);
    } catch (Exception e) {
      // Trigger rollback with runtime exception!
      throw new RuntimeException("Failed to record audit", e);
    }
    return result;
  }

  private Record _prepareRecord(Result result, Audit audit, String who) {
    boolean abort = false;
    java.util.Date when = DateUtility.getDate();
    String reference = ServiceUtility.getReferenceIdentifier(when, null, 32);
    if (audit == null) { result.getMessages().add("Audit not defined"); return null; }
    if (ObjectUtility.isValue(audit.getPrincipal()) == false) { result.getMessages().add("Principal not defined"); abort = true; }
    if (ObjectUtility.isValue(audit.getBusiness()) == false) { result.getMessages().add("Business not defined"); abort = true; }
    if (audit.getConducted() == null) { result.getMessages().add("Conducted not defined"); abort = true; }
    else if (when.before(audit.getConducted())) { result.getMessages().add("Future conducted date not supported"); abort = true; }
    else if (audit.getPosted() == null) { result.getMessages().add("Posted not defined"); abort = true; }
    else if (when.before(audit.getPosted())) { result.getMessages().add("Future posted date not supported"); abort = true; }
    else if (audit.getPosted().before(audit.getConducted())) { result.getMessages().add("Posted date before conducted"); abort = true; }
    if (ObjectUtility.isValue(audit.getClient()) == false) { result.getMessages().add("Client not defined"); abort = true; }
    if (ObjectUtility.isValue(audit.getComment()) == false) { result.getMessages().add("Comment not defined"); abort = true; }
    if (ObjectUtility.isValue(audit.getMetadata()) == false) { result.getMessages().add("Metadata not defined"); abort = true; }
    if (ObjectUtility.isValue(audit.getTransaction()) == false) { result.getMessages().add("Transaction not defined"); abort = true; }
    if (ObjectUtility.isValue(who) == false) { result.getMessages().add("Who not defined"); abort = true; }
    return (abort == false) ? Record.getInstance(audit, reference, who, when) : null;
  }

  /**
   * Query audit.
   * 
   * result.success  : True if not aborted
   * result.records  : Zero or more matching records
   * 
   * @param query Query
   * @param persist boolean
   * @return QueryResult
   * @throws CisException
   * @author Michael Cronk
   */
  public QueryResult query(
      Query query,
      boolean persist) // For backward compatibility!
          throws CisException {
    QueryResult result = null;
    try {
      java.util.Date nowDate = DateUtility.getDate();
      result = new QueryResult(false, new java.util.LinkedList<String>(), new java.util.LinkedList<Record>());
      boolean success = false;

      // Verify query
      boolean abort = _verifyQuery(result, query, nowDate, new java.util.HashSet<String>(), false);
      if (abort) { return result; }

      // Query repository
      if (persist) {
        try {
          success |= repository.query(result, query);
        } catch (Exception e) {
          String message = "Repository: Audit query partially failed";
          result.getMessages().add(message);
          if (logger.isErrorEnabled()) { logger.error(message, e); }
        }
      }

      // Query VIPS
      try {
        success |= ServerManager.getExternal().getVips().query(result, query);
      } catch (Exception e) {
        String message = "VIPS: Audit query partially failed";
        result.getMessages().add(message);
        if (logger.isErrorEnabled()) { logger.error(message, e); }
      }

      result.setSuccess(success);
    } catch (Exception e) {
      throw new CisException("Failed to query audit", e);
    }
    return result;
  }

  private static final String PRINCIPAL_FILTER = "PRINCIPAL";
  private static final String BUSINESS_FILTER = "BUSINESS";
  private static final String CONDUCTED_FILTER = "CONDUCTED";
  private static final String CLIENT_FILTER = "CLIENT";
  private static final String COMMENT_FILTER = "COMMENT";
  private static final String METADATA_FILTER = "METADATA";
  private static final String TRANSACTION_FILTER = "TRANSACTION";

  private boolean _verifyQuery(QueryResult result, Query query, java.util.Date nowDate, java.util.Set<String> filters, boolean nested) {
    boolean abort = false;
    boolean found = false;

    // Query
    if (query == null) { result.getMessages().add("Query not defined"); return true; }

    // Relationship
    if (ObjectUtility.isValue(query.getRelationship()) == false) { result.getMessages().add("Query relationship not defined"); abort = true; }
    else if ((ObjectUtility.equals(query.getRelationship(), Query.RELATIONSHIP_AND) == false) && (ObjectUtility.equals(query.getRelationship(), Query.RELATIONSHIP_OR) == false)) {
      result.getMessages().add("Query relationship not supported: " + query.getRelationship());
      abort = true;
    }

    // Filters
    if (ObjectUtility.isValue(query.getFilters()) == false) { result.getMessages().add("Query filters not defined"); abort = true; }
    else {
      for (Filter filter : query.getFilters()) {

        // Nested
        if (filter instanceof NestedFilter) {
          NestedFilter nestedFilter = (NestedFilter) filter;
          if (ObjectUtility.isValue(nestedFilter.getOperator()) == false) { result.getMessages().add("Nested filter operator not defined"); abort = true; }
          else if (ObjectUtility.equals(nestedFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) { result.getMessages().add("Nested filter operator not supported: " + nestedFilter.getOperator()); abort = true; }
          else if (nestedFilter.getQuery() == null) { result.getMessages().add("Nested filter query not defined"); abort = true; }
          else { abort |= _verifyQuery(result, nestedFilter.getQuery(), nowDate, filters, true); found = true; }

          // Principal
        } else if (filter instanceof PrincipalFilter) {
          PrincipalFilter principalFilter = (PrincipalFilter) filter;
          if (ObjectUtility.isValue(principalFilter.getOperator()) == false) { result.getMessages().add("Principal filter operator not defined"); abort = true; }
          else if (ObjectUtility.equals(principalFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) { result.getMessages().add("Principal filter operator not supported: " + principalFilter.getOperator()); abort = true; }
          else if (ObjectUtility.isValue(principalFilter.getText()) == false) { result.getMessages().add("Principal filter text not defined"); abort = true; }
          else { filters.add(PRINCIPAL_FILTER); found = true; }

          // Business
        } else if (filter instanceof BusinessFilter) {
          BusinessFilter businessFilter = (BusinessFilter) filter;
          if (ObjectUtility.isValue(businessFilter.getOperator()) == false) { result.getMessages().add("Business filter operator not defined"); abort = true; }
          else if (ObjectUtility.equals(businessFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) { result.getMessages().add("Business filter operator not supported: " + businessFilter.getOperator()); abort = true; }
          else if (ObjectUtility.isValue(businessFilter.getText()) == false) { result.getMessages().add("Business filter text not defined"); abort = true; }
          else { filters.add(BUSINESS_FILTER); found = true; }

          // Conducted
        } else if (filter instanceof ConductedFilter) {
          ConductedFilter conductedFilter = (ConductedFilter) filter;
          if (ObjectUtility.isValue(conductedFilter.getOperator()) == false) { result.getMessages().add("Conducted filter operator not defined"); abort = true; }
          else if (ObjectUtility.equals(conductedFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) { result.getMessages().add("Conducted filter operator not supported: " + conductedFilter.getOperator()); abort = true; }
          else if (conductedFilter.getFromDate() == null) { result.getMessages().add("Conducted filter from date not defined"); abort = true; }
          else if (conductedFilter.getToDate() == null) { result.getMessages().add("Conducted filter to date not defined"); abort = true; }
          else if (conductedFilter.getToDate().before(conductedFilter.getFromDate())) { result.getMessages().add("Conducted filter to date before from"); abort = true; }
          else if (nowDate.before(conductedFilter.getFromDate())) { result.getMessages().add("Conducted filter future date not supported"); abort = true; }
          else if (DateUtility.getDaysDifference(conductedFilter.getFromDate(), conductedFilter.getToDate()) > 90) {
            result.getMessages().add("Conducted filter date duration too long (90 days): " + DateUtility.getDaysDifference(conductedFilter.getFromDate(), conductedFilter.getToDate())); abort = true;
          }
          else { filters.add(CONDUCTED_FILTER); found = true; }

          // Client
        } else if (filter instanceof ClientFilter) {
          ClientFilter clientFilter = (ClientFilter) filter;
          if (ObjectUtility.isValue(clientFilter.getOperator()) == false) { result.getMessages().add("Client filter operator not defined"); abort = true; }
          else if (ObjectUtility.equals(clientFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) { result.getMessages().add("Client filter operator not supported: " + clientFilter.getOperator()); abort = true; }
          else if (ObjectUtility.isValue(clientFilter.getText()) == false) { result.getMessages().add("Client filter text not defined"); abort = true; }
          else { filters.add(CLIENT_FILTER); found = true; }

          // Comment
        } else if (filter instanceof CommentFilter) {
          char[] special = { ' ' };
          CommentFilter commentFilter = (CommentFilter) filter;
          if (ObjectUtility.isValue(commentFilter.getOperator()) == false) { result.getMessages().add("Comment filter operator not defined"); abort = true; }
          else if (ObjectUtility.equals(commentFilter.getOperator(), Filter.OPERATOR_MATCH) == false) { result.getMessages().add("Comment filter operator not supported: " + commentFilter.getOperator()); abort = true; }
          else if (ObjectUtility.isValue(commentFilter.getText()) == false) { result.getMessages().add("Comment filter text not defined"); abort = true; }
          else if (StringUtility.isMatch(commentFilter.getText(), true, true, special) == false) { result.getMessages().add("Comment filter text contains invalid character (alphanumeric and space only): " + commentFilter.getText()); abort = true; }
          else { filters.add(COMMENT_FILTER); found = true; }

          // Metadata
        } else if (filter instanceof MetadataFilter) {
          char[] special = null;
          MetadataFilter metadataFilter = (MetadataFilter) filter;
          if (ObjectUtility.isValue(metadataFilter.getOperator()) == false) { result.getMessages().add("Metadata filter operator not defined"); abort = true; }
          else if (ObjectUtility.equals(metadataFilter.getOperator(), Filter.OPERATOR_MATCH) == false) { result.getMessages().add("Metadata filter operator not supported: " + metadataFilter.getOperator()); abort = true; }
          else if (ObjectUtility.isValue(metadataFilter.getType()) == false) { result.getMessages().add("Metadata filter type not defined"); abort = true; }
          else if (StringUtility.isMatch(metadataFilter.getType(), true, true, special) == false) { result.getMessages().add("Metadata filter type contains invalid character (alphanumeric only): " + metadataFilter.getType()); abort = true; }
          else if (ObjectUtility.isValue(metadataFilter.getText()) == false) { result.getMessages().add("Metadata filter text not defined"); abort = true; }
          else if (StringUtility.isMatch(metadataFilter.getText(), true, true, special) == false) { result.getMessages().add("Metadata filter text contains invalid character (alphanumeric only): " + metadataFilter.getText()); abort = true; }
          else { filters.add(METADATA_FILTER); found = true; }

          // Transaction
        } else if (filter instanceof TransactionFilter) {
          TransactionFilter transactionFilter = (TransactionFilter) filter;
          if (ObjectUtility.isValue(transactionFilter.getOperator()) == false) { result.getMessages().add("Transaction filter operator not defined"); abort = true; }
          else if (ObjectUtility.equals(transactionFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) { result.getMessages().add("Transaction filter operator not supported: " + transactionFilter.getOperator()); abort = true; }
          else if (ObjectUtility.isValue(transactionFilter.getText()) == false) { result.getMessages().add("Transaction filter text not defined"); abort = true; }
          else { filters.add(TRANSACTION_FILTER); found = true; }

          // Unsupported
        } else {
          result.getMessages().add("Query filter not supported: " + filter.getClass().getName()); abort = true;
        }

      }
    }

    if (nested == false) {
      // A transaction OR conducted with at least another filter must be defined
      if ((filters.contains(TRANSACTION_FILTER) == false) &&
          ((filters.contains(CONDUCTED_FILTER) == false) || (filters.size() < 2))) {
        result.getMessages().add("A transaction or conducted with at least another filter must be defined"); abort = true;
      }
    } else if (found == false) {
      // A nested filter needs at least one supported filter defined
      result.getMessages().add("A nested filter needs at least one supported filter defined"); abort = true;
    }

    return abort;
  }

}
