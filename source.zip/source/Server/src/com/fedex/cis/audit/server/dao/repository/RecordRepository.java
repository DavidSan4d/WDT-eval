package com.fedex.cis.audit.server.dao.repository;

import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.server.dao.repository.mapper.RecordRowMapper;

import fedex.cis.common.exception.CisException;
import fedex.cis.common.util.ObjectUtility;

@org.springframework.stereotype.Repository
public class RecordRepository {

  public static final String TABLE = "CIS_AUDIT_RECORD";
  public static final String COLUMN_REFERENCE = "REFERENCE_SEQ_NBR";
  public static final String COLUMN_PRINCIPAL = "PRINCIPAL_CD";
  public static final String COLUMN_BUSINESS = "BUSINESS_CD";
  public static final String COLUMN_CONDUCT = "CONDUCT_TMSTP";
  public static final String COLUMN_POST = "POST_TMSTP";
  public static final String COLUMN_CLIENT = "CLIENT_NM";
  public static final String COLUMN_COMMENT = "COMMENT_TXT";
  public static final String COLUMN_METADATA = "METADATA_TXT";
  public static final String COLUMN_TRANSACTION = "TRANSACTION_SEQ_NBR";
  public static final String COLUMN_WHO = "WHO_NM";
  public static final String COLUMN_WHEN = "WHEN_TMSTP";

  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;

  // CRUD queries

  public int create(Record value) throws CisException {
    String sql = "insert into " + TABLE + " (" +
        COLUMN_REFERENCE + ", " +
        COLUMN_PRINCIPAL + ", " +
        COLUMN_BUSINESS + ", " +
        COLUMN_CONDUCT + ", " +
        COLUMN_POST + ", " +
        COLUMN_CLIENT + ", " +
        COLUMN_COMMENT + ", " +
        COLUMN_METADATA + ", " +
        COLUMN_TRANSACTION + ", " +
        COLUMN_WHO + ", " +
        COLUMN_WHEN +
        ") values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    int result = jdbcTemplate.update(sql,
        value.getReference(),
        value.getPrincipal(),
        value.getBusiness(),
        value.getConducted(),
        value.getPosted(),
        value.getClient(),
        value.getComment(),
        value.getMetadata(),
        value.getTransaction(),
        value.getWho(),
        value.getWhen());
    if (result != 1) { throw new CisException("Number of records created unexpected: " + result); }
    return result;
  }

  public Record read(String reference) {
    Record result = null;
    String sql = "select * from " + TABLE + " " +
        "where " + COLUMN_REFERENCE + " = ?";
    try {
      result = jdbcTemplate.queryForObject(sql, new RecordRowMapper(), reference);
    } catch (org.springframework.dao.EmptyResultDataAccessException e) {
      // Does nothing intentionally!
    }
    return result;
  }

  public int update(String reference, Record value) throws CisException {
    String sql = "update " + TABLE + " set " +
        COLUMN_PRINCIPAL + " = ?, " +
        COLUMN_BUSINESS + " = ?, " +
        COLUMN_CONDUCT + " = ?, " +
        COLUMN_POST + " = ?, " +
        COLUMN_CLIENT + " = ?, " +
        COLUMN_COMMENT + " = ?, " +
        COLUMN_METADATA + " = ?, " +
        COLUMN_TRANSACTION + " = ?, " +
        COLUMN_WHO + " = ?, " +
        COLUMN_WHEN + " = ? " +
        "where " + COLUMN_REFERENCE + " = ?";
    int result = jdbcTemplate.update(sql,
        value.getPrincipal(),
        value.getBusiness(),
        value.getConducted(),
        value.getPosted(),
        value.getClient(),
        value.getComment(),
        value.getMetadata(),
        value.getTransaction(),
        value.getWho(),
        value.getWhen(),
        reference);
    if (result > 1) { throw new CisException("Number of records updated unexpected: " + result); }
    return result;
  }

  public int delete(String reference) throws CisException {
    String sql = "delete from " + TABLE + " " +
        "where " + COLUMN_REFERENCE + " = ?";
    int result = jdbcTemplate.update(sql,
        reference);
    if (result > 1) { throw new CisException("Number of records deleted unexpected: " + result); }
    return result;
  }

  //
  // Other queries
  //

  public boolean duplicate(String principal, String business, java.util.Date conducted) {
    java.util.List<Object> parameters = java.util.Arrays.asList(principal, business, conducted);
    String sql = "select count(*) from " + TABLE + " " +
        "where " + COLUMN_PRINCIPAL + " = ?" + " " +
        "and " + COLUMN_BUSINESS + " = ?" + " " +
        "and " + COLUMN_CONDUCT + " = ?";
    int size = jdbcTemplate.queryForObject(sql, parameters.toArray(), Integer.class);
    return (size > 0) ? true : false;
  }

  public boolean record(RecordResult result, Record record) throws CisException {
    boolean success = false;
    create(record);
    result.setReference(record.getReference());
    success = true;
    return success;
  }

  public boolean query(QueryResult result, Query query) {
    boolean success = false;
    // Get where clause
    StringBuilder whereSql = new StringBuilder();
    java.util.List<Object> parameters = new java.util.ArrayList<Object>();
    boolean abort = _parseSql(result, whereSql, parameters, query);
    if (abort) { return false; }
    // Count
    int limit = 1000;
    String sql = "select count(*) from " + TABLE + " where " + whereSql;
    int size = jdbcTemplate.queryForObject(sql, parameters.toArray(), Integer.class);
    if (size > limit) { result.getMessages().add(_toMessage("Query result too large (restricted to " + limit + "): " + size)); }
    // Fetch
    sql = "select * from " + TABLE + " " +
        "where " + whereSql + " " +
        "and ROWNUM <= " + limit + " " +
        "order by " + COLUMN_CONDUCT;
    try {
      result.getRecords().addAll(jdbcTemplate.query(sql, new RecordRowMapper(), parameters.toArray()));
      success = true;
    } catch (org.springframework.dao.EmptyResultDataAccessException e) {
      success = true;
    }
    return success;
  }

  private boolean _parseSql(
      QueryResult result,
      StringBuilder sql,
      java.util.Collection<Object> parameters,
      Query query) {
    boolean abort = false;
    boolean found = false;

    // Relationship
    String relationship = "";
    if (ObjectUtility.equals(query.getRelationship(), Query.RELATIONSHIP_AND)) { relationship = "and"; }
    else if (ObjectUtility.equals(query.getRelationship(), Query.RELATIONSHIP_OR)) { relationship = "or"; }
    else { result.getMessages().add(_toMessage("Query relationship not supported: " + query.getRelationship())); abort = true; }

    // Filters
    for (Filter filter : query.getFilters()) {

      // Filter relationship
      String filterRelationship = found ? (" " + relationship + " ") : "";

      // Nested
      if (filter instanceof NestedFilter) {
        NestedFilter nestedFilter = (NestedFilter) filter;
        if (ObjectUtility.equals(nestedFilter.getOperator(), Filter.OPERATOR_EQUAL)) {
          sql.append(filterRelationship + "(");
          abort |= _parseSql(result, sql, parameters, nestedFilter.getQuery());
          sql.append(")");
          found = true;
        } else {
          result.getMessages().add(_toMessage("Nested filter operator not supported: " + nestedFilter.getOperator())); abort = true;
        }

        // Principal
      } else if (filter instanceof PrincipalFilter) {
        PrincipalFilter principalFilter = (PrincipalFilter) filter;
        if (ObjectUtility.equals(principalFilter.getOperator(), Filter.OPERATOR_EQUAL)) {
          sql.append(filterRelationship + COLUMN_PRINCIPAL + " = ?"); // Already uppercase!
          parameters.add(principalFilter.getText().toUpperCase());
          found = true;
        } else {
          result.getMessages().add(_toMessage("Principal filter operator not supported: " + principalFilter.getOperator())); abort = true;
        }

        // Business
      } else if (filter instanceof BusinessFilter) {
        BusinessFilter businessFilter = (BusinessFilter) filter;
        if (ObjectUtility.equals(businessFilter.getOperator(), Filter.OPERATOR_EQUAL)) {
          sql.append(filterRelationship + COLUMN_BUSINESS + " = ?"); // Already uppercase!
          parameters.add(businessFilter.getText().toUpperCase());
          found = true;
        } else {
          result.getMessages().add(_toMessage("Business filter operator not supported: " + businessFilter.getOperator())); abort = true;
        }

        // Conducted
      } else if (filter instanceof ConductedFilter) {
        ConductedFilter conductedFilter = (ConductedFilter) filter;
        if (ObjectUtility.equals(conductedFilter.getOperator(), Filter.OPERATOR_EQUAL)) {
          sql.append(filterRelationship + COLUMN_CONDUCT + " <= ? ");
          parameters.add(conductedFilter.getToDate());
          sql.append("and " + COLUMN_CONDUCT + " >= ?");
          parameters.add(conductedFilter.getFromDate());
          found = true;
        } else {
          result.getMessages().add(_toMessage("Conducted filter operator not supported: " + conductedFilter.getOperator())); abort = true;
        }

        // Client
      } else if (filter instanceof ClientFilter) {
        ClientFilter clientFilter = (ClientFilter) filter;
        if (ObjectUtility.equals(clientFilter.getOperator(), Filter.OPERATOR_EQUAL)) {
          sql.append(filterRelationship + COLUMN_CLIENT + " = ?"); // Already uppercase!
          parameters.add(clientFilter.getText().toUpperCase());
          found = true;
        } else {
          result.getMessages().add(_toMessage("Client filter operator not supported: " + clientFilter.getOperator())); abort = true;
        }

        // Comment
      } else if (filter instanceof CommentFilter) {
        CommentFilter commentFilter = (CommentFilter) filter;
        if (ObjectUtility.equals(commentFilter.getOperator(), Filter.OPERATOR_MATCH)) {
          sql.append(filterRelationship + "UPPER(" + COLUMN_COMMENT + ") like ?");
          parameters.add("%" + commentFilter.getText().toUpperCase() + "%");
          found = true;
        } else {
          result.getMessages().add(_toMessage("Comment filter operator not supported: " + commentFilter.getOperator())); abort = true;
        }

        // Metadata
      } else if (filter instanceof MetadataFilter) {
        MetadataFilter metadataFilter = (MetadataFilter) filter;
        if (ObjectUtility.equals(metadataFilter.getOperator(), Filter.OPERATOR_MATCH)) {
          sql.append(filterRelationship + "UPPER(" + COLUMN_METADATA + ") like ?");
          String value = "-" + metadataFilter.getType() + ":" + metadataFilter.getText() + ";";
          parameters.add("%" + value.toUpperCase() + "%");
          found = true;
        } else {
          result.getMessages().add(_toMessage("Metadata filter operator not supported: " + metadataFilter.getOperator())); abort = true;
        }

        // Transaction
      } else if (filter instanceof TransactionFilter) {
        TransactionFilter transactionFilter = (TransactionFilter) filter;
        if (ObjectUtility.equals(transactionFilter.getOperator(), Filter.OPERATOR_EQUAL)) {
          sql.append(filterRelationship + COLUMN_TRANSACTION + " = ?");  // Already uppercase!
          parameters.add(transactionFilter.getText().toUpperCase());
          found = true;
        } else {
          result.getMessages().add(_toMessage("Transaction filter operator not supported: " + transactionFilter.getOperator())); abort = true;
        }

        // Unsupported
      } else {
        result.getMessages().add(_toMessage("Query filter ignored: " + filter.getClass().getName()));
        // Intentionally does not abort!
      }

    }

    // At least one supported filter must be defined
    if (found == false) {
      result.getMessages().add(_toMessage("At least one supported filter must be defined")); abort = true;
    }

    return abort;
  }

  private String _toMessage(String message) {
    return "Repository: " + message;
  }

}
