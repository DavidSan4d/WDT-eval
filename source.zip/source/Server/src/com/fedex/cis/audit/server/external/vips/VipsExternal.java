package com.fedex.cis.audit.server.external.vips;

/**
 * VIPS external adapter.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.common.bean.*;

import fedex.cis.common.exception.CisException;
import fedex.cis.common.net.http.*;
import fedex.cis.common.util.*;

public class VipsExternal {

  // Private constants
  private static final String URL_PROPERTY = "url";
  private static final String RECORD_URI_PROPERTY = "record.uri";
  private static final String QUERY_URI_PROPERTY = "query.uri";

  // Private attributes
  private final String recordUrl;
  private final String queryUrl;

  /**
   * Construct external adapter.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public VipsExternal(java.util.Properties properties) {
    try {
      String url = properties.getProperty(URL_PROPERTY);
      recordUrl = url + properties.getProperty(RECORD_URI_PROPERTY);
      queryUrl = url + properties.getProperty(QUERY_URI_PROPERTY);
    } catch (Exception e) {
      throw new RuntimeException("Failed to construct VIPS external adapter", e);
    }
  }

  /**
   * Record audit.
   * @param result RecordResult
   * @param record Record
   * @return boolean
   * @throws CisException
   * @author Michael Cronk
   */
  public boolean record(
      RecordResult result,
      Record record)
          throws CisException {
    boolean success = false;
    java.io.ByteArrayOutputStream outputStream = null;
    java.io.InputStream inputStream = null;
    try {
      java.util.Map<String, String> parameters = new java.util.HashMap<>();
      // VIPS requires any prefix letter to properly parse POST parameters
      parameters.put("nREQUESTTYPE", "PilotAuditUpdate");
      parameters.put("nwho", record.getPrincipal());       // VIPS: PilotID
      parameters.put("nwhat", record.getBusiness());       // VIPS: App (for example, VIEW)
      parameters.put("nwhen", DateUtility.getDateFormat("yyyyMMdd HH:mm:ss", false).format(record.getConducted())); // VIPS: Date/Time (Z)
      parameters.put("nwhere", record.getClient());        // VIPS: Typ (for example, NUCLEUS)
      parameters.put("nwhy", record.getComment());         // VIPS: Transaction Information
      parameters.put("nhow", record.getWho());             // VIPS: App (for example, CISCALENDER)
      outputStream = new java.io.ByteArrayOutputStream();
      HttpResponse response = getResponse(HttpRequest.POST_FORM_METHOD, recordUrl, parameters, outputStream);
      if (response.getCode() != java.net.HttpURLConnection.HTTP_OK) {
        throw new CisException("HTTP Error: " + response.getCode() + ": " + response.getMessage());
      }
      // Verify status
      inputStream = new java.io.ByteArrayInputStream(outputStream.toByteArray());
      success = verifyStatus(result, inputStream);
    } catch (Exception e) {
      throw new CisException("Failed to record audit to VIPS", e);
    } finally {
      if (inputStream != null) { try { inputStream.close(); } catch (Exception e) {} }
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
    }
    return success;
  }

  /**
   * Get response.
   * @param method String
   * @param url String
   * @param parameters java.util.Map<String, String>
   * @param outputStream java.io.OutputStream
   * @return HttpResponse
   * @throws CisException
   * @author Michael Cronk
   */
  private HttpResponse getResponse(
      String method,
      String url,
      java.util.Map<String, String> parameters,
      java.io.OutputStream outputStream)
          throws CisException {
    HttpResponse result = null;
    try {
      HttpRequest httpRequest = new HttpRequest();
      httpRequest.setMethod(method);
      httpRequest.setUrl(url);
      httpRequest.setParameters(parameters);
      httpRequest.setTimeout(10 * 1000); // 10 seconds for connect and read in milliseconds
      httpRequest.setOutputStream(outputStream);
      HttpManager httpManager = new CisHttpManager(null);
      result = httpManager.handle(httpRequest);
    } catch (Exception e) {
      throw new CisException("Failed to get response", e);
    }
    return result;
  }

  /**
   * Verify status.
   * 
   *  - Success
   *  
   *    |STATUS|00|
   *  
   *  - Fail
   * 
   *    |STATUS|99|
   *    |MESSAGE|System or business error message|
   * 
   * @param result BooleanResult
   * @param inputStream java.io.InputStream
   * @return boolean
   * @throws CisException
   * @author Michael Cronk
   */
  private boolean verifyStatus(
      RecordResult result,
      java.io.InputStream inputStream)
          throws CisException {
    boolean success = false;
    java.io.InputStreamReader isr = null;
    java.io.BufferedReader br = null;
    try {
      isr = new java.io.InputStreamReader(inputStream);
      br = new java.io.BufferedReader(isr);
      String line = null;
      String status = null;
      String message = null;
      while ((line = br.readLine()) != null) {
        if (line.startsWith("|STATUS|")) {
          String[] attributes = line.split("\\|");
          if (attributes.length < 3) { throw new CisException("Status record malformed: " + line); }
          status = attributes[2];
        } else if (line.startsWith("|MESSAGE|")) {
          String[] attributes = line.split("\\|");
          if (attributes.length < 3) { throw new CisException("Message record malformed: " + line); }
          message = attributes[2];
        }
        if (status != null) { if (status.equals("00") || status.equals("01") || (message != null)) { break; } }
      }
      if (status == null) { throw new CisException("Status not defined"); }
      else if (status.equals("00")) { _mergeReference(result); success = true; }
      else if (status.equals("01")) { success = true; } // Ignored unless real pilot employee number is used!
      else { result.getMessages().add(_toMessage(status + ": " + message)); }
    } catch (Exception e) {
      throw new CisException("Failed to verify status", e);
    } finally {
      if (br != null) { try { br.close(); } catch (Exception e) {} }
      if (isr != null) { try { isr.close(); } catch (Exception e) {} }
    }
    return success;
  }

  private void _mergeReference(RecordResult result) {
    if (ObjectUtility.isValue(result.getReference()) == false) {
      result.setReference("UNKNOWN");
    }
  }

  // Private constants
  private static final String QUERY_PARAMETER_REQUEST_TYPE = "PilotAuditInquiry";
  private static final String QUERY_PARAMETER_PRINCIPAL = "PILOTID";
  private static final String QUERY_PARAMETER_CONDUCTED_FROM = "STARTDATE";
  private static final String QUERY_PARAMETER_CONDUCTED_TO = "ENDDATE";
  private static final String QUERY_DATE_PATTERN = "yyyyMMdd";
  private static final String QUERY_TIME_PATTERN = "HH:mm:ss";

  /**
   * Query audit.
   * @param result QueryResult
   * @param query Query
   * @return boolean
   * @throws CisException
   * @author Michael Cronk
   */
  public boolean query(
      QueryResult result,
      Query query)
          throws CisException {
    boolean success = false;
    java.io.ByteArrayOutputStream outputStream = null;
    java.io.InputStream is = null;
    java.io.InputStreamReader isr = null;
    java.io.BufferedReader br = null;
    try {
      // Set parameters
      java.util.Map<String, String> parameters = new java.util.HashMap<String, String>();
      parameters.put("REQUESTTYPE", QUERY_PARAMETER_REQUEST_TYPE);
      boolean abort = _parseParameters(result, parameters, query, false);
      if (abort) { return false; }
      // Get response
      outputStream = new java.io.ByteArrayOutputStream();
      HttpResponse response = getResponse(HttpRequest.GET_METHOD, queryUrl, parameters, outputStream);
      if (response.getCode() != java.net.HttpURLConnection.HTTP_OK) {
        throw new CisException("HTTP Error: " + response.getCode() + ": " + response.getMessage());
      }
      // Verify status
      Status status = getStatus(outputStream.toByteArray());
      if (status.getCode().equals("00")) {
        // Extract records
        java.util.Collection<Record> records = new java.util.LinkedList<Record>();
        is = new java.io.ByteArrayInputStream(outputStream.toByteArray());
        isr = new java.io.InputStreamReader(is);
        br = new java.io.BufferedReader(isr);
        String line = null;
        while ((line = br.readLine()) != null) {
          // |AUDITREC|<PRINCIPAL>|<DATE>|<TIME>|<TYP>|<APP>|<COMMENT>|
          // |AUDITREC|246690|20190702|16:02:22|WEB|NXT|TRIP  293 03JUL19 2015 MEM 67 CAP|
          if (line.startsWith("|AUDITREC|")) {
            String[] recordAttributes = line.split("\\|");
            if (recordAttributes.length < 8) { throw new CisException("Audit record malformed: " + line); }
            Record record = new Record();
            record.setPrincipal(recordAttributes[2]);
            record.setBusiness(recordAttributes[6]);
            record.setConducted(DateUtility.getDateFormat(QUERY_DATE_PATTERN + " " + QUERY_TIME_PATTERN, false).parse(recordAttributes[3] + " " + recordAttributes[4]));
            record.setPosted(null);      // Not persisted by VIPS!
            record.setClient(recordAttributes[5]);
            record.setComment(recordAttributes[7]);
            record.setMetadata(null);    // Not persisted by VIPS!
            record.setTransaction(null); // Not persisted by VIPS!
            record.setReference(null);   // Not persisted by VIPS!
            record.setWho(null);         // Not persisted by VIPS!
            record.setWhen(null);        // Not persisted by VIPS!
            records.add(record);
          }
        }
        _mergeRecords(result, records);
        success = true;
      } else if (status.getCode().equals("01")) {
        // Employee number not found
        success = true;
      } else {
        // VIPS error
        result.getMessages().add(_toMessage(status.getCode() + ": " + status.getMessage()));
      }
    } catch (Exception e) {
      throw new CisException("Failed to query audit from VIPS", e);
    } finally {
      if (outputStream != null) { try { outputStream.close(); } catch (Exception e) {} }
      if (br != null) { try { br.close(); } catch (Exception e) {} }
      if (isr != null) { try { isr.close(); } catch (Exception e) {} }
      if (is != null) { try { is.close(); } catch (Exception e) {} }
    }
    return success;
  }

  /**
   * Parse parameters.
   * @param queryResult QueryResult
   * @param parameters java.util.Map<String, String>
   * @param query Query
   * @param nested boolean
   * @return boolean
   * @author Michael Cronk
   */
  private boolean _parseParameters(
      QueryResult result,
      java.util.Map<String, String> parameters,
      Query query,
      boolean nested) {
    boolean abort = false;

    // Relationship
    if (ObjectUtility.equals(query.getRelationship(), Query.RELATIONSHIP_AND) == false) {
      result.getMessages().add(_toMessage("Query relationship not supported: " + query.getRelationship()));
      abort = true;
    }

    // Filters
    for (Filter filter : query.getFilters()) {

      // Nested
      if (filter instanceof NestedFilter) {
        NestedFilter nestedFilter = (NestedFilter) filter;
        if (ObjectUtility.equals(nestedFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) {
          result.getMessages().add(_toMessage("Nested filter operator not supported: " + nestedFilter.getOperator()));
          abort = true;
        } else {
          abort |= _parseParameters(result, parameters, nestedFilter.getQuery(), true);
        }

        // Principal
      } else if (filter instanceof PrincipalFilter) {
        PrincipalFilter principalFilter = (PrincipalFilter) filter;
        if (ObjectUtility.equals(principalFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) {
          result.getMessages().add(_toMessage("Principal filter operator not supported: " + principalFilter.getOperator()));
          abort = true;
        } else if (parameters.containsKey(QUERY_PARAMETER_PRINCIPAL)) {
          result.getMessages().add(_toMessage("Duplicate principal filters defined"));
          abort = true;
        } else {
          parameters.put(QUERY_PARAMETER_PRINCIPAL, principalFilter.getText());
        }

        // Conducted
      } else if (filter instanceof ConductedFilter) {
        ConductedFilter conductedFilter = (ConductedFilter) filter;
        if (ObjectUtility.equals(conductedFilter.getOperator(), Filter.OPERATOR_EQUAL) == false) {
          result.getMessages().add(_toMessage("Conducted filter operator not supported: " + conductedFilter.getOperator()));
          abort = true;
        } else if (parameters.containsKey(QUERY_PARAMETER_CONDUCTED_FROM) || parameters.containsKey(QUERY_PARAMETER_CONDUCTED_TO)) {
          result.getMessages().add(_toMessage("Duplicate conducted filters defined"));
          abort = true;
        } else {
          parameters.put(QUERY_PARAMETER_CONDUCTED_FROM, DateUtility.getDateFormat(QUERY_DATE_PATTERN, false).format(conductedFilter.getFromDate())); // VIPS: Date/Time (Z)
          parameters.put(QUERY_PARAMETER_CONDUCTED_TO, DateUtility.getDateFormat(QUERY_DATE_PATTERN, false).format(conductedFilter.getToDate())); // VIPS: Date/Time (Z)
        }

        // Unsupported
      } else {
        result.getMessages().add(_toMessage("Query filter ignored: " + filter.getClass().getName()));
        // Intentionally does not abort!
      }

    }

    // Both principal and conducted filters must be defined
    if (nested == false) {
      if ((parameters.containsKey(QUERY_PARAMETER_PRINCIPAL) == false) ||
          (parameters.containsKey(QUERY_PARAMETER_CONDUCTED_FROM) == false) ||
          (parameters.containsKey(QUERY_PARAMETER_CONDUCTED_TO) == false)) {
        result.getMessages().add(_toMessage("Both principal and conducted filters must be defined"));
        abort = true;
      }
    }

    return abort;
  }

  private String _toMessage(String message) {
    return "VIPS: " + message;
  }

  private void _mergeRecords(QueryResult result, java.util.Collection<Record> records) {
    boolean merged = false;
    for (Record record : records) { merged |= _mergeRecord(result, record); }
    if (merged) { // Sort merged records!
      java.util.List<Record> sortedRecords = new java.util.ArrayList<Record>(result.getRecords());
      sortedRecords.sort((lhs, rhs) -> { return ObjectUtility.compareTo(lhs.getConducted(), rhs.getConducted()); });
      result.setRecords(sortedRecords);
    }
  }

  private boolean _mergeRecord(QueryResult result, Record record) {
    for (Record resultRecord : result.getRecords()) {
      String resultComment = ((resultRecord != null) && (resultRecord.getComment() != null) && (resultRecord.getComment().length() > 50)) ? resultRecord.getComment().substring(0, 50) : null;
      if (ObjectUtility.equals(resultRecord.getPrincipal(), record.getPrincipal()) &&
          ObjectUtility.equals(DateUtility.getStartOfSecond(resultRecord.getConducted()), record.getConducted()) &&
          ObjectUtility.equals(resultComment, record.getComment())) {
        return false;
      }
    }
    result.getRecords().add(record);
    return true;
  }

  /**
   * VIPS status.
   * @author Michael Cronk
   */
  private class Status {

    private String code;
    public String getCode() { return code; }
    public void setCode(String value) { code = value; }

    private String message;
    public String getMessage() { return message; }
    public void setMessage(String value) { message = value; }

  }

  /**
   * Get status.
   * @param outputByteArray byte[]
   * @return Status
   * @throws CisException
   * @author Michael Cronk
   */
  private Status getStatus(
      byte[] outputByteArray)
          throws CisException {
    Status result = null;
    java.io.InputStream is = null;
    java.io.InputStreamReader isr = null;
    java.io.BufferedReader br = null;
    try {
      is = new java.io.ByteArrayInputStream(outputByteArray);
      isr = new java.io.InputStreamReader(is);
      br = new java.io.BufferedReader(isr);
      String line = null;
      String code = null;
      String message = null;
      while ((line = br.readLine()) != null) {
        if (line.startsWith("|STATUS|")) {
          // |STATUS|00|
          String[] attributes = line.split("\\|");
          if (attributes.length < 3) { throw new CisException("Status record malformed: " + line); }
          code = attributes[2];
        } else if (line.startsWith("|MESSAGE|")) {
          // |MESSAGE|Empty, system or business error message|
          String[] attributes = line.split("\\|");
          if (attributes.length == 2) { message = ""; }
          else if (attributes.length == 3) { message = attributes[2]; }
          else { throw new CisException("Message record malformed: " + line); }
        }
        if ((code != null) && (message != null)) { break; }
      }
      if (code == null) { throw new CisException("Code not defined"); }
      result = new Status();
      result.setCode(code);
      result.setMessage(ObjectUtility.isValue(message) ? message : null);
    } catch (Exception e) {
      throw new CisException("Failed to get status", e);
    } finally {
      if (br != null) { try { br.close(); } catch (Exception e) {} }
      if (isr != null) { try { isr.close(); } catch (Exception e) {} }
      if (is != null) { try { is.close(); } catch (Exception e) {} }
    }
    return result;
  }

}
