package com.fedex.cis.audit.server.external;

/**
 * External manager.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.server.external.vips.VipsExternal;

import fedex.cis.common.util.PropertiesUtility;

public class ExternalManager {

  // Private attributes
  private final VipsExternal vipsExternal;

  /**
   * Construct external manager.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public ExternalManager(java.util.Properties properties) {
    vipsExternal = new VipsExternal(PropertiesUtility.extractProperties(properties, "vips."));
  }

  /**
   * Get VIPS external.
   * @return VipsExternal
   * @author Michael Cronk
   */
  public VipsExternal getVips() {
    return vipsExternal;
  }

}
