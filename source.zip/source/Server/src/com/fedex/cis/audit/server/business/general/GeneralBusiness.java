package com.fedex.cis.audit.server.business.general;

/**
 * General business adapter.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.common.bean.Ping;
import com.fedex.cis.audit.server.ServerManager;

@org.springframework.stereotype.Service
public class GeneralBusiness {

  // Private constants
  private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(GeneralBusiness.class);
  private static final String NAME_PROPERTY = "name";

  // Private attributes
  private String name;

  /**
   * Construct business adapter.
   * @author Michael Cronk
   */
  public GeneralBusiness() {
    try {
      java.util.Properties properties = ServerManager.getBusiness().getGeneralProperties();
      setAttributes(properties);
    } catch (Exception e) {
      throw new java.lang.RuntimeException("Failed to instantiate business adapter", e);
    }
  }

  /**
   * Construct business adapter.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public GeneralBusiness(java.util.Properties properties) {
    setAttributes(properties);
  }

  /**
   * Set attributes.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  private void setAttributes(java.util.Properties properties) {
    name = properties.getProperty(NAME_PROPERTY);
  }

  /**
   * Ping.
   * @return Ping
   * @author Michael Cronk
   */
  public Ping ping() {
    Ping result = new Ping();
    result.setText("Microservice \"" + name + "\" is alive!");
    if (logger.isInfoEnabled()) { logger.info(result.getText()); }
    return result;
  }

}
