package com.fedex.cis.audit.server;

/**
 * Server manager.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.server.business.BusinessManager;
import com.fedex.cis.audit.server.external.ExternalManager;

import fedex.cis.common.server.exception.ServerCisException;

public class ServerManager {

  // Private attributes
  private static final ServerHelper helper = new ServerHelper();

  /**
   * Get CIS environment.
   * @return String
   * @author Michael Cronk
   */
  public static String getCisEnvironment() {
    return helper.getCisEnvironment();
  }

  /**
   * Refresh.
   * @author Michael Cronk
   */
  public static void refresh() {
    helper.refresh();
  }

  /**
   * Get properties.
   * @param prefix String
   * @return java.util.Properties
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public static java.util.Properties getProperties(String prefix) throws ServerCisException {
    return helper.getProperties(prefix);
  }

  /**
   * Get business.
   * @return BusinessManager
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public static BusinessManager getBusiness() throws ServerCisException {
    return helper.getBusiness();
  }

  /**
   * Get external.
   * @return ExternalManager
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public static ExternalManager getExternal() throws ServerCisException {
    return helper.getExternal();
  }

}
