package com.fedex.cis.audit.server.dao.repository.mapper;

import com.fedex.cis.audit.common.bean.Record;
import com.fedex.cis.audit.server.dao.repository.RecordRepository;

public class RecordRowMapper implements org.springframework.jdbc.core.RowMapper<Record> {

  @Override
  public Record mapRow(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
    Record result = new Record();
    result.setReference(rs.getString(RecordRepository.COLUMN_REFERENCE));
    result.setPrincipal(rs.getString(RecordRepository.COLUMN_PRINCIPAL));
    result.setBusiness(rs.getString(RecordRepository.COLUMN_BUSINESS));
    result.setConducted(rs.getTimestamp(RecordRepository.COLUMN_CONDUCT));
    result.setPosted(rs.getTimestamp(RecordRepository.COLUMN_POST));
    result.setClient(rs.getString(RecordRepository.COLUMN_CLIENT));
    result.setComment(rs.getString(RecordRepository.COLUMN_COMMENT));
    result.setMetadata(rs.getString(RecordRepository.COLUMN_METADATA));
    result.setTransaction(rs.getString(RecordRepository.COLUMN_TRANSACTION));
    result.setWho(rs.getString(RecordRepository.COLUMN_WHO));
    result.setWhen(rs.getTimestamp(RecordRepository.COLUMN_WHEN));
    return result;
  }

}
