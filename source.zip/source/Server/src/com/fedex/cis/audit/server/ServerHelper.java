package com.fedex.cis.audit.server;

/**
 * Server helper.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.server.business.BusinessManager;
import com.fedex.cis.audit.server.external.ExternalManager;

import fedex.cis.common.property.*;
import fedex.cis.common.server.exception.ServerCisException;
import fedex.cis.common.util.*;

public class ServerHelper {

  // Private constants
  private static final String CIS_DEPLOYMENT_PROPERTY = "CIS_DEPLOYMENT";
  private static final String CIS_ENVIRONMENT_PROPERTY = "CIS_ENVIRONMENT";

  // Private attributes
  private final java.util.concurrent.locks.ReentrantReadWriteLock readWriteLock;
  private final java.util.concurrent.locks.Lock readLock;
  private final java.util.concurrent.locks.Lock writeLock;
  @SuppressWarnings("unused")
  private String cisDeployment = null;
  private String cisEnvironment = null;

  // Private lock methods
  private void getReadLock() { readLock.lock(); }
  private void releaseReadLock() { readLock.unlock(); }
  private void getWriteLock() { writeLock.lock(); }
  private void releaseWriteLock() { writeLock.unlock(); }
  private void upgradeReadToWriteLock() { readLock.unlock(); writeLock.lock(); }
  private void downgradeWriteToReadLock() { readLock.lock(); writeLock.unlock(); }

  /**
   * Construct server helper.
   * @author Michael Cronk
   */
  public ServerHelper() {
    readWriteLock = new java.util.concurrent.locks.ReentrantReadWriteLock(true);
    readLock = readWriteLock.readLock();
    writeLock = readWriteLock.writeLock();
    cisDeployment = java.lang.System.getProperty(CIS_DEPLOYMENT_PROPERTY);
    cisEnvironment = java.lang.System.getProperty(CIS_ENVIRONMENT_PROPERTY);
  }

  /**
   * Get CIS environment.
   * @return String
   * @author Michael Cronk
   */
  public String getCisEnvironment() {
    return cisEnvironment;
  }

  // ---------------------------------------------------------------------- //
  //                           P R O P E R T I E S                          //
  // ---------------------------------------------------------------------- //

  // Private constants
  private static final String DEPLOYMENT_PROPERTIES = "cis.deployment.server.";
  private static final String ENVIRONMENT_PROPERTY = "CIS_PROPERTIES";
  private static final String CLASSPATH_DEPLOYMENT_PREFIX = "deployment_";
  private static final String CLASSPATH_DEPLOYMENT_SUFFIX = ".properties";
  private static final String HELPER_PROPERTIES = "cis.server.";

  // Private attributes
  private java.util.Properties properties = null;
  private java.util.Date propertiesLoaded = null;

  /**
   * Refresh.
   * @author Michael Cronk
   */
  public void refresh() {
    getWriteLock();
    try {
      propertiesLoaded = null;
    } finally {
      releaseWriteLock();
    }
  }

  /**
   * Get properties.
   * @param prefix String
   * @return java.util.Properties
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public java.util.Properties getProperties(String prefix) throws ServerCisException {
    java.util.Properties result = null;
    getReadLock();
    try {
      java.util.Properties allProperties = properties;
      if ((properties == null) || (propertiesLoaded == null)) {
        upgradeReadToWriteLock();
        try {
          allProperties = getProperties();
        } finally {
          downgradeWriteToReadLock();
        }
      }
      if (ObjectUtility.isValue(prefix)) { 
        result = PropertiesUtility.extractProperties(allProperties, prefix);
      } else {
        result = PropertiesUtility.copyProperties(allProperties);
      }
    } finally {
      releaseReadLock();
    }
    return result;
  }

  /**
   * Get properties.
   * @return java.util.Properties
   * @throws ServerCisException
   * @author Michael Cronk
   */
  private java.util.Properties getProperties() throws ServerCisException {
    java.util.Properties result = null;
    // Guaranteed to already be in a write lock!
    try {
      if ((properties == null) || (propertiesLoaded == null)) {
        setPropertiesByEnvironment();
        if (properties == null) {
          setPropertiesByClasspath();
        }
        properties = PropertiesUtility.expandProperties(properties, null, null);
        propertiesLoaded = DateUtility.getDate();
      }
      result = properties;
    } catch (Exception e) {
      throw new ServerCisException("Failed to get properties", e);
    }
    return result;
  }

  /**
   * Set properties by environment.
   * @throws ServerCisException
   * @author Michael Cronk
   */
  private void setPropertiesByEnvironment() throws ServerCisException {
    try {
      PropertyContext propertyContext = PropertyHelper.getEnvironmentPropertyContext(ENVIRONMENT_PROPERTY, DEPLOYMENT_PROPERTIES);
      PropertyManager propertyManager = PropertyFactory.getManager(propertyContext);
      properties = propertyManager.getProperties();
    } catch (Exception e) {
      throw new ServerCisException("Failed to set properties by environment", e);
    }
  }

  /**
   * Set properties by classpath.
   * @throws ServerCisException
   * @author Michael Cronk
   */
  private void setPropertiesByClasspath() throws ServerCisException {
    try {
      String deploymentResource = new String(CLASSPATH_DEPLOYMENT_PREFIX + cisEnvironment + CLASSPATH_DEPLOYMENT_SUFFIX);
      PropertyContext propertyContext = PropertyHelper.getClasspathPropertyContext(deploymentResource, DEPLOYMENT_PROPERTIES);
      PropertyManager propertyManager = PropertyFactory.getManager(propertyContext);
      properties = propertyManager.getProperties();
    } catch (Exception e) {
      throw new ServerCisException("Failed to set properties by classpath", e);
    }
  }

  // ---------------------------------------------------------------------- //
  //                            B U S I N E S S                             //
  // ---------------------------------------------------------------------- //

  // Private constants
  private static final String BUSINESS_PROPERTIES = HELPER_PROPERTIES + "business.";

  // Private attributes
  private BusinessManager business = null;
  private java.util.Date businessLoaded = null;

  /**
   * Get business.
   * @return BusinessManager
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public BusinessManager getBusiness() throws ServerCisException {
    BusinessManager result = null;
    getReadLock();
    try {
      if ((business == null) || (businessLoaded == null) || (businessLoaded.equals(propertiesLoaded) == false)) {
        upgradeReadToWriteLock();
        try {
          if ((business == null) || (businessLoaded == null) || (businessLoaded.equals(propertiesLoaded) == false)) {
            business = new BusinessManager(PropertiesUtility.extractProperties(getProperties(), BUSINESS_PROPERTIES));
            businessLoaded = propertiesLoaded;
          }
        } finally {
          downgradeWriteToReadLock();
        }
      }
      result = business;
    } finally {
      releaseReadLock();
    }
    return result;
  }

  // ---------------------------------------------------------------------- //
  //                            E X T E R N A L                             //
  // ---------------------------------------------------------------------- //

  // Private constants
  private static final String EXTERNAL_PROPERTIES = HELPER_PROPERTIES + "external.";

  // Private attributes
  private ExternalManager external = null;
  private java.util.Date externalLoaded = null;

  /**
   * Get external.
   * @return ExternalManager
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public ExternalManager getExternal() throws ServerCisException {
    ExternalManager result = null;
    getReadLock();
    try {
      if ((external == null) || (externalLoaded == null) || (externalLoaded.equals(propertiesLoaded) == false)) {
        upgradeReadToWriteLock();
        try {
          if ((external == null) || (externalLoaded == null) || (externalLoaded.equals(propertiesLoaded) == false)) {
            external = new ExternalManager(PropertiesUtility.extractProperties(getProperties(), EXTERNAL_PROPERTIES));
            externalLoaded = propertiesLoaded;
          }
        } finally {
          downgradeWriteToReadLock();
        }
      }
      result = external;
    } finally {
      releaseReadLock();
    }
    return result;
  }

}
