package com.fedex.cis.audit.common.tbd.v1;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;
import com.fedex.cis.audit.common.bean.Record;

@SuppressWarnings("deprecation")
public class AuditTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void getInstance() {
    Record record = CommonTestFixture.getRecord();
    Audit result = Audit.getInstance(record);
    assertSame(record.getPrincipal(), result.getPrincipal());
    assertSame(record.getBusiness(), result.getBusiness());
    assertSame(record.getTransaction(), result.getTransaction());
    assertSame(record.getConducted(), result.getConducted());
    assertSame(record.getPosted(), result.getPosted());
    assertSame(record.getWhen(), result.getReceived());
    assertSame(record.getWho(), result.getService());
    assertSame(record.getClient(), result.getClient());
    assertSame(record.getComment(), result.getComment());
    assertSame(record.getMetadata(), result.getMetadata());
  }

  @Test
  public void getInstance_WithRecordNotDefined() {
    Record record = null;
    Audit result = Audit.getInstance(record);
    assertNull(result);
  }

  @Test
  public void toAudit() {
    Audit audit = CommonTestFixture.getTbdAudit();
    com.fedex.cis.audit.common.bean.Audit result = Audit.toAudit(audit);
    assertSame(audit.getPrincipal(), result.getPrincipal());
    assertSame(audit.getBusiness(), result.getBusiness());
    assertSame(audit.getTransaction(), result.getTransaction());
    assertSame(audit.getConducted(), result.getConducted());
    assertSame(audit.getPosted(), result.getPosted());
    assertSame(audit.getClient(), result.getClient());
    assertSame(audit.getComment(), result.getComment());
    assertSame(audit.getMetadata(), result.getMetadata());
  }

  @Test
  public void toAudit_WithAuditNotDefined() {
    Audit audit = null;
    com.fedex.cis.audit.common.bean.Audit result = Audit.toAudit(audit);
    assertNull(result);
  }

  @Test
  public void testAudit() {
    Audit result = new Audit();
    assertNotNull(result);
  }

  @Test
  public void testSetAndGetPrincipal() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getTbdAudit();
    result.setPrincipal(value);
    assertSame(value, result.getPrincipal());
  }

  @Test
  public void testSetAndGetBusiness() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getTbdAudit();
    result.setBusiness(value);
    assertSame(value, result.getBusiness());
  }

  @Test
  public void testSetAndGetTransaction() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getTbdAudit();
    result.setTransaction(value);
    assertSame(value, result.getTransaction());
  }

  @Test
  public void testSetAndGetConducted() {
    java.util.Date value = new java.util.Date();
    Audit result = CommonTestFixture.getTbdAudit();
    result.setConducted(value);
    assertSame(value, result.getConducted());
  }

  @Test
  public void testSetAndGetPosted() {
    java.util.Date value = new java.util.Date();
    Audit result = CommonTestFixture.getTbdAudit();
    result.setPosted(value);
    assertSame(value, result.getPosted());
  }

  @Test
  public void testSetAndGetReceived() {
    java.util.Date value = new java.util.Date();
    Audit result = CommonTestFixture.getTbdAudit();
    result.setReceived(value);
    assertSame(value, result.getReceived());
  }

  @Test
  public void testSetAndGetService() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getTbdAudit();
    result.setService(value);
    assertSame(value, result.getService());
  }

  @Test
  public void testSetAndGetClient() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getTbdAudit();
    result.setClient(value);
    assertSame(value, result.getClient());
  }

  @Test
  public void testSetAndGetComment() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getTbdAudit();
    result.setComment(value);
    assertSame(value, result.getComment());
  }

  @Test
  public void testSetAndGetMetadata() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getTbdAudit();
    result.setMetadata(value);
    assertSame(value, result.getMetadata());
  }

}
