package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class MetadataFilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testMetadataFilter() {
    MetadataFilter result = new MetadataFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_MATCH, result.getOperator());
    assertNull(result.getType());
    assertNull(result.getText());
  }

  @Test
  public void testMetadataFilter_String() {
    String type = "TYPE";
    String text = "TEXT";
    MetadataFilter result = new MetadataFilter(type, text);
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_MATCH, result.getOperator());
    assertSame(type, result.getType());
    assertSame(text, result.getText());
  }

  @Test
  public void testMetadataFilter_String_String_String() {
    String operator = "OPERATOR";
    String type = "TYPE";
    String text = "TEXT";
    MetadataFilter result = new MetadataFilter(operator, type, text);
    assertNotNull(result);
    assertSame(operator, result.getOperator());
    assertSame(type, result.getType());
    assertSame(text, result.getText());
  }

  @Test
  public void testSetAndGetType() {
    String value = "VALUE";
    MetadataFilter result = CommonTestFixture.getMetadataFilter();
    result.setType(value);
    assertSame(value, result.getType());
  }

}
