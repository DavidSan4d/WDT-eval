package com.fedex.cis.audit.common;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

import com.fedex.cis.audit.common.bean.BeanTestSuite;
import com.fedex.cis.audit.common.tbd.TbdTestSuite;

@RunWith(Suite.class)
@SuiteClasses({
  TbdTestSuite.class,
  BeanTestSuite.class
})

public class CommonTestSuite {
  // Intentionally left blank!
}
