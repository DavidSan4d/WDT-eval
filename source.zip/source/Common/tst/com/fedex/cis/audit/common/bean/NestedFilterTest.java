package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class NestedFilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testNestedFilter() {
    NestedFilter result = new NestedFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertNull(result.getQuery());
  }

  @Test
  public void testNestedFilter_Query() {
    Query query = CommonTestFixture.getQuery();
    NestedFilter result = new NestedFilter(query);
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertSame(query, result.getQuery());
  }

  @Test
  public void testNestedFilter_String_Query() {
    String operator = "OPERATOR";
    Query query = CommonTestFixture.getQuery();
    NestedFilter result = new NestedFilter(operator, query);
    assertNotNull(result);
    assertSame(operator, result.getOperator());
    assertSame(query, result.getQuery());
  }

  @Test
  public void testSetAndGetQuery() {
    Query value = CommonTestFixture.getQuery();
    NestedFilter result = CommonTestFixture.getNestedFilter();
    result.setQuery(value);
    assertSame(value, result.getQuery());
  }

}
