package com.fedex.cis.audit.common.tbd.v1;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  AuditTest.class,
  AuditListDtoTest.class})

public class V1TestSuite {
  // Intentionally left blank!
}
