package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class ResultTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testResult() {
    Result result = new Result();
    assertNotNull(result);
    assertFalse(result.isSuccess());
    assertNull(result.getMessages());
  }

  @Test
  public void testResult_BooleanCollection() {
    boolean success = true;
    java.util.Collection<String> messages = java.util.Arrays.asList("MESSAGE");
    Result result = new Result(success, messages);
    assertNotNull(result);
    assertSame(success, result.isSuccess());
    assertSame(messages, result.getMessages());
  }

  @Test
  public void testSetAndIsSuccess() {
    boolean value = false;
    Result result = CommonTestFixture.getResult();
    result.setSuccess(value);
    assertSame(value, result.isSuccess());
  }


  @Test
  public void testSetAndGetMessages() {
    java.util.Collection<String> value = java.util.Arrays.asList("VALUE");
    Result result = CommonTestFixture.getResult();
    result.setMessages(value);
    assertSame(value, result.getMessages());
  }

  @Test
  public void testEquals() {
    Result value = CommonTestFixture.getResult();
    assertTrue(value.equals(value));
  }

  @Test
  public void testEqualsWithThatNull() {
    Result thisValue = CommonTestFixture.getResult();
    Result thatValue = null;
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatClassNotEqual() {
    Result thisValue = CommonTestFixture.getResult();
    String thatValue = new String("VALUE");
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatEqual() {
    Result thisValue = CommonTestFixture.getResult();
    Result thatValue = CommonTestFixture.getResult();
    assertTrue(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatNotEqual() {
    Result thisValue = CommonTestFixture.getResult();
    Result thatValue = CommonTestFixture.getResult();
    thatValue.setSuccess(true);
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testHashCode() {
    Result thisValue = CommonTestFixture.getResult();
    Result thatValue = CommonTestFixture.getResult();
    assertTrue(thisValue.hashCode() == thatValue.hashCode());
    thatValue.setMessages(null);
    assertFalse(thisValue.hashCode() == thatValue.hashCode());
  }

  @Test
  public void testToString() {
    Result thisValue = CommonTestFixture.getResult();
    Result thatValue = CommonTestFixture.getResult();
    assertEquals(thisValue.toString(), thatValue.toString());
    thatValue.setSuccess(true);
    assertFalse(thisValue.toString().equals(thatValue.toString()));
  }

}
