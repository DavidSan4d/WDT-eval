package com.fedex.cis.audit.common.tbd;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

import com.fedex.cis.audit.common.tbd.v1.V1TestSuite;

@RunWith(Suite.class)
@SuiteClasses({
  V1TestSuite.class
})

public class TbdTestSuite {
  // Intentionally left blank!
}
