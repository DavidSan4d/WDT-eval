package com.fedex.cis.audit.common.tbd.v1;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;
import com.fedex.cis.audit.common.bean.Record;

@SuppressWarnings("deprecation")
public class AuditListDtoTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void getInstance() {
    java.util.Collection<Record> records = java.util.Arrays.asList(CommonTestFixture.getRecord());
    AuditListDto result = AuditListDto.getInstance(records);
    assertEquals(records.size(), result.getAudits().size());
  }

  @Test
  public void getInstance_WithRecordsNotDefined() {
    java.util.Collection<Record> records = null;
    AuditListDto result = AuditListDto.getInstance(records);
    assertNull(result);
  }

  @Test
  public void testAuditListDto() {
    AuditListDto result = new AuditListDto();
    assertNotNull(result);
    assertNull(result.getAudits());
  }

  @Test
  public void testSetAndGetAudits() {
    java.util.Collection<Audit> value = new java.util.ArrayList<Audit>(1);
    value.add(CommonTestFixture.getTbdAudit());
    AuditListDto result = CommonTestFixture.getTbdAuditListDto();
    result.setAudits(value);
    assertSame(value, result.getAudits());
  }

}
