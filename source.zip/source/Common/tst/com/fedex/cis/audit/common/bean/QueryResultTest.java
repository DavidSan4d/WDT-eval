package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class QueryResultTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testQueryResult() {
    QueryResult result = new QueryResult();
    assertNotNull(result);
    assertFalse(result.isSuccess());
    assertNull(result.getMessages());
    assertNull(result.getRecords());
  }

  @Test
  public void testQueryResult_BooleanCollectionCollection() {
    boolean success = true;
    java.util.Collection<String> messages = java.util.Arrays.asList("MESSAGE");
    java.util.Collection<Record> records = java.util.Arrays.asList(CommonTestFixture.getRecord());
    QueryResult result = new QueryResult(success, messages, records);
    assertNotNull(result);
    assertSame(success, result.isSuccess());
    assertSame(messages, result.getMessages());
    assertSame(records, result.getRecords());
  }

  @Test
  public void testSetAndGetRecords() {
    java.util.Collection<Record> value = java.util.Arrays.asList(CommonTestFixture.getRecord());
    QueryResult result = CommonTestFixture.getQueryResult();
    result.setRecords(value);
    assertSame(value, result.getRecords());
  }

  @Test
  public void testEquals() {
    QueryResult value = CommonTestFixture.getQueryResult();
    assertTrue(value.equals(value));
  }

  @Test
  public void testEqualsWithThatNull() {
    QueryResult thisValue = CommonTestFixture.getQueryResult();
    QueryResult thatValue = null;
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatClassNotEqual() {
    QueryResult thisValue = CommonTestFixture.getQueryResult();
    String thatValue = new String("VALUE");
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatEqual() {
    QueryResult thisValue = CommonTestFixture.getQueryResult();
    QueryResult thatValue = CommonTestFixture.getQueryResult();
    assertTrue(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatNotEqual() {
    QueryResult thisValue = CommonTestFixture.getQueryResult();
    QueryResult thatValue = CommonTestFixture.getQueryResult();
    thatValue.setRecords(null);
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testHashCode() {
    QueryResult thisValue = CommonTestFixture.getQueryResult();
    QueryResult thatValue = CommonTestFixture.getQueryResult();
    assertTrue(thisValue.hashCode() == thatValue.hashCode());
    thatValue.setRecords(null);
    assertFalse(thisValue.hashCode() == thatValue.hashCode());
  }

  @Test
  public void testToString() {
    QueryResult thisValue = CommonTestFixture.getQueryResult();
    QueryResult thatValue = CommonTestFixture.getQueryResult();
    assertEquals(thisValue.toString(), thatValue.toString());
    thatValue.setRecords(null);
    assertFalse(thisValue.toString().equals(thatValue.toString()));
  }

}
