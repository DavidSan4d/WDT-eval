package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class FilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testFilter() {
    Filter result = new JUnitFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
  }

  @Test
  public void testFilter_String() {
    String operator = "OPERATOR";
    Filter result = new JUnitFilter(operator);
    assertNotNull(result);
    assertEquals(operator, result.getOperator());
  }

  @Test
  public void testSetAndGetOperator() {
    String value = "VALUE";
    Filter result = CommonTestFixture.getFilter();
    result.setOperator(value);
    assertSame(value, result.getOperator());
  }

}
