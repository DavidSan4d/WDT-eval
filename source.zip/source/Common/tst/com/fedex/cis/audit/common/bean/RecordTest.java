package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

import fedex.cis.common.util.DateUtility;

public class RecordTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void getInstance() {
    Audit audit = CommonTestFixture.getAudit();
    String reference = "20181205122938987123456789098765";
    String who = "CISCALENDAR";
    java.util.Date when = null;
    try { when = DateUtility.getDate(2018, 12, 5, 12, 29, 38, 987); } catch (Exception e) {}
    Record result = Record.getInstance(audit, reference, who, when);
    assertSame(audit.getPrincipal(), result.getPrincipal());
    assertSame(audit.getBusiness(), result.getBusiness());
    assertSame(audit.getConducted(), result.getConducted());
    assertSame(audit.getPosted(), result.getPosted());
    assertSame(audit.getClient(), result.getClient());
    assertSame(audit.getComment(), result.getComment());
    assertSame(audit.getMetadata(), result.getMetadata());
    assertSame(audit.getTransaction(), result.getTransaction());
    assertSame(reference, result.getReference());
    assertSame(who, result.getWho());
    assertSame(when, result.getWhen());
  }

  @Test
  public void getInstance_WithAuditNotDefined() {
    Audit audit = null;
    String reference = "20181205122938987123456789098765";
    String who = "CISCALENDAR";
    java.util.Date when = null;
    try { when = DateUtility.getDate(2018, 12, 5, 12, 29, 38, 987); } catch (Exception e) {}
    Record result = Record.getInstance(audit, reference, who, when);
    assertNull(result.getPrincipal());
    assertNull(result.getBusiness());
    assertNull(result.getConducted());
    assertNull(result.getPosted());
    assertNull(result.getClient());
    assertNull(result.getComment());
    assertNull(result.getMetadata());
    assertNull(result.getTransaction());
    assertSame(reference, result.getReference());
    assertSame(who, result.getWho());
    assertSame(when, result.getWhen());
  }

  @Test
  public void getInstance_WithCommentAllWhitespace() {
    Audit audit = CommonTestFixture.getAudit();
    audit.setComment(" ");
    String reference = "20181205122938987123456789098765";
    String who = "CISCALENDAR";
    java.util.Date when = null;
    try { when = DateUtility.getDate(2018, 12, 5, 12, 29, 38, 987); } catch (Exception e) {}
    Record result = Record.getInstance(audit, reference, who, when);
    assertSame(audit.getPrincipal(), result.getPrincipal());
    assertSame(audit.getBusiness(), result.getBusiness());
    assertSame(audit.getConducted(), result.getConducted());
    assertSame(audit.getPosted(), result.getPosted());
    assertSame(audit.getClient(), result.getClient());
    assertNull(result.getComment());
    assertSame(audit.getMetadata(), result.getMetadata());
    assertSame(audit.getTransaction(), result.getTransaction());
    assertSame(reference, result.getReference());
    assertSame(who, result.getWho());
    assertSame(when, result.getWhen());
  }

  @Test
  public void getInstance_WithCommentTrimWhitespace() {
    Audit audit = CommonTestFixture.getAudit();
    audit.setComment(" " + audit.getComment() + " ");
    String reference = "20181205122938987123456789098765";
    String who = "CISCALENDAR";
    java.util.Date when = null;
    try { when = DateUtility.getDate(2018, 12, 5, 12, 29, 38, 987); } catch (Exception e) {}
    Record result = Record.getInstance(audit, reference, who, when);
    assertSame(audit.getPrincipal(), result.getPrincipal());
    assertSame(audit.getBusiness(), result.getBusiness());
    assertSame(audit.getConducted(), result.getConducted());
    assertSame(audit.getPosted(), result.getPosted());
    assertSame(audit.getClient(), result.getClient());
    assertNotSame(audit.getComment(), result.getComment());
    assertSame(audit.getMetadata(), result.getMetadata());
    assertSame(audit.getTransaction(), result.getTransaction());
    assertSame(reference, result.getReference());
    assertSame(who, result.getWho());
    assertSame(when, result.getWhen());
  }

  @Test
  public void testRecord() {
    Record result = new Record();
    assertNotNull(result);
  }

  @Test
  public void testSetAndGetReference() {
    String value = "VALUE";
    Record result = CommonTestFixture.getRecord();
    result.setReference(value);
    assertSame(value, result.getReference());
  }

  @Test
  public void testSetAndGetWho() {
    String value = "VALUE";
    Record result = CommonTestFixture.getRecord();
    result.setWho(value);
    assertSame(value, result.getWho());
  }

  @Test
  public void testSetAndGetWhen() {
    java.util.Date value = new java.util.Date();
    Record result = CommonTestFixture.getRecord();
    result.setWhen(value);
    assertSame(value, result.getWhen());
  }

  @Test
  public void testEquals() {
    Record value = CommonTestFixture.getRecord();
    assertTrue(value.equals(value));
  }

  @Test
  public void testEqualsWithThatNull() {
    Record thisValue = CommonTestFixture.getRecord();
    Record thatValue = null;
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatClassNotEqual() {
    Record thisValue = CommonTestFixture.getRecord();
    String thatValue = new String("VALUE");
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatEqual() {
    Record thisValue = CommonTestFixture.getRecord();
    Record thatValue = CommonTestFixture.getRecord();
    assertTrue(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatNotEqual() {
    Record thisValue = CommonTestFixture.getRecord();
    Record thatValue = CommonTestFixture.getRecord();
    thatValue.setReference(null);
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testHashCode() {
    Record thisValue = CommonTestFixture.getRecord();
    Record thatValue = CommonTestFixture.getRecord();
    assertTrue(thisValue.hashCode() == thatValue.hashCode());
    thatValue.setWho(null);
    assertFalse(thisValue.hashCode() == thatValue.hashCode());
  }

  @Test
  public void testToString() {
    Record thisValue = CommonTestFixture.getRecord();
    Record thatValue = CommonTestFixture.getRecord();
    assertEquals(thisValue.toString(), thatValue.toString());
    thatValue.setWhen(null);
    assertFalse(thisValue.toString().equals(thatValue.toString()));
  }

}
