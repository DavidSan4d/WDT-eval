package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

public class CommentFilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testCommentFilter() {
    CommentFilter result = new CommentFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_MATCH, result.getOperator());
    assertNull(result.getText());
  }

  @Test
  public void testCommentFilter_String() {
    String text = "TEXT";
    CommentFilter result = new CommentFilter(text);
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_MATCH, result.getOperator());
    assertSame(text, result.getText());
  }

  @Test
  public void testCommentFilter_String_String() {
    String operator = "OPERATOR";
    String text = "TEXT";
    CommentFilter result = new CommentFilter(operator, text);
    assertNotNull(result);
    assertSame(operator, result.getOperator());
    assertSame(text, result.getText());
  }

}
