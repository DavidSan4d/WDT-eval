package com.fedex.cis.audit.common.bean;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  PingTest.class,
  ResultTest.class,
  AuditTest.class,
  RecordTest.class,
  RecordResultTest.class,
  FilterTest.class,
  QueryTest.class,
  TextFilterTest.class,
  DateRangeFilterTest.class,
  NestedFilterTest.class,
  PrincipalFilterTest.class,
  BusinessFilterTest.class,
  ConductedFilterTest.class,
  ClientFilterTest.class,
  CommentFilterTest.class,
  MetadataFilterTest.class,
  TransactionFilterTest.class,
  QueryResultTest.class
})

public class BeanTestSuite {
  // Intentionally left blank!
}
