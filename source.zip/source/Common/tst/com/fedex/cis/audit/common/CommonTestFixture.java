package com.fedex.cis.audit.common;

import com.fedex.cis.audit.common.bean.*;

import fedex.cis.common.util.DateUtility;

public class CommonTestFixture {

  public static Ping getPing() {
    Ping result = new Ping();
    result.setText("Ping text");
    return result;
  }

  public static Result getResult() {
    Result result = new Result();
    result.setSuccess(false);
    result.setMessages(java.util.Arrays.asList("MESSAGE"));
    return result;
  }

  public static Audit getAudit() {
    Audit result = new Audit();
    result.setPrincipal("474768");
    result.setBusiness("VIEW");
    try { result.setConducted(DateUtility.getDate(2018, 12, 5, 12, 29, 34, 246)); } catch (Exception e) {}
    try { result.setPosted(DateUtility.getDate(2018, 12, 5, 12, 29, 36, 357)); } catch (Exception e) {}
    result.setClient("NUCLEUS");
    result.setComment("User 474768 viewed calendar of pilot 246690 in bid month 201802");
    result.setMetadata("-P:246690;-BM:201802;");
    result.setTransaction("20181205122934246123456789098765");
    return result;
  }

  public static Record getRecord() {
    Audit audit = getAudit();
    String reference = "20181205122938987123456789098765";
    String who = "CISCALENDAR";
    java.util.Date when = null;
    try { when = DateUtility.getDate(2018, 12, 5, 12, 29, 38, 987); } catch (Exception e) {}
    return Record.getInstance(audit, reference, who, when);
  }

  public static RecordResult getRecordResult() {
    RecordResult result = new RecordResult();
    result.setSuccess(false);
    result.setMessages(java.util.Arrays.asList("MESSAGE"));
    result.setReference(getRecord().getReference());
    return result;
  }

  @Deprecated
  public static com.fedex.cis.audit.common.tbd.v1.Audit getTbdAudit() {
    return com.fedex.cis.audit.common.tbd.v1.Audit.getInstance(getRecord());
  }

  @Deprecated
  public static com.fedex.cis.audit.common.tbd.v1.AuditListDto getTbdAuditListDto() {
    return com.fedex.cis.audit.common.tbd.v1.AuditListDto.getInstance(java.util.Arrays.asList(getRecord()));
  }

  public static Filter getFilter() {
    return new JUnitFilter();
  }

  public static Query getQuery() {
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(2);
    filters.add(getPrincipalFilter());
    filters.add(getBusinessFilter());
    filters.add(getConductedFilter());
    filters.add(getClientFilter());
    filters.add(getCommentFilter());
    filters.add(getMetadataFilter());
    filters.add(getTransactionFilter());
    return new Query(filters);
  }

  public static NestedFilter getNestedFilter() {
    Query query = getQuery();
    return new NestedFilter(query);
  }

  public static TextFilter getTextFilter() {
    return new TextFilter("TEXT");
  }

  public static PrincipalFilter getPrincipalFilter() {
    return new PrincipalFilter(getAudit().getPrincipal());
  }

  public static BusinessFilter getBusinessFilter() {
    return new BusinessFilter(getAudit().getBusiness());
  }

  public static DateRangeFilter getDateRangeFilter() {
    java.util.Date date = DateUtility.getDate();
    return new DateRangeFilter(DateUtility.getStartOfDay(date), DateUtility.getEndOfDay(date));
  }

  public static ConductedFilter getConductedFilter() {
    Audit audit = getAudit();
    return new ConductedFilter(DateUtility.getStartOfDay(audit.getConducted()), DateUtility.getEndOfDay(audit.getConducted()));
  }

  public static ClientFilter getClientFilter() {
    return new ClientFilter(getAudit().getClient());
  }

  public static CommentFilter getCommentFilter() {
    return new CommentFilter("pilot 246690 in");
  }

  public static MetadataFilter getMetadataFilter() {
    return new MetadataFilter("P", "246690");
  }

  public static TransactionFilter getTransactionFilter() {
    return new TransactionFilter(getAudit().getTransaction());
  }

  public static QueryResult getQueryResult() {
    QueryResult result = new QueryResult();
    result.setSuccess(false);
    result.setMessages(java.util.Arrays.asList("MESSAGE"));
    result.setRecords(java.util.Arrays.asList(getRecord()));
    return result;
  }

}
