package com.fedex.cis.audit.common.bean;

public class JUnitFilter extends Filter {

  public JUnitFilter() {
    super();
  }

  public JUnitFilter(String operator) {
    super(operator);
  }

}
