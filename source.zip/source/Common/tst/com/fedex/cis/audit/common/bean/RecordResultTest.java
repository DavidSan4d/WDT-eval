package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class RecordResultTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testRecordResult() {
    RecordResult result = new RecordResult();
    assertNotNull(result);
    assertFalse(result.isSuccess());
    assertNull(result.getMessages());
    assertNull(result.getReference());
  }

  @Test
  public void testRecordResult_RecordCollectionString() {
    boolean success = true;
    java.util.Collection<String> messages = java.util.Arrays.asList("MESSAGE");
    String reference = "REFERENCE";
    RecordResult result = new RecordResult(success, messages, reference);
    assertNotNull(result);
    assertSame(success, result.isSuccess());
    assertSame(messages, result.getMessages());
    assertSame(reference, result.getReference());
  }

  @Test
  public void testSetAndGetReference() {
    String value = "VALUE";
    RecordResult result = CommonTestFixture.getRecordResult();
    result.setReference(value);
    assertSame(value, result.getReference());
  }

  @Test
  public void testEquals() {
    RecordResult value = CommonTestFixture.getRecordResult();
    assertTrue(value.equals(value));
  }

  @Test
  public void testEqualsWithThatNull() {
    RecordResult thisValue = CommonTestFixture.getRecordResult();
    RecordResult thatValue = null;
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatClassNotEqual() {
    RecordResult thisValue = CommonTestFixture.getRecordResult();
    String thatValue = new String("VALUE");
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatEqual() {
    RecordResult thisValue = CommonTestFixture.getRecordResult();
    RecordResult thatValue = CommonTestFixture.getRecordResult();
    assertTrue(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatNotEqual() {
    RecordResult thisValue = CommonTestFixture.getRecordResult();
    RecordResult thatValue = CommonTestFixture.getRecordResult();
    thatValue.setReference(null);
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testHashCode() {
    RecordResult thisValue = CommonTestFixture.getRecordResult();
    RecordResult thatValue = CommonTestFixture.getRecordResult();
    assertTrue(thisValue.hashCode() == thatValue.hashCode());
    thatValue.setReference(null);
    assertFalse(thisValue.hashCode() == thatValue.hashCode());
  }

  @Test
  public void testToString() {
    RecordResult thisValue = CommonTestFixture.getRecordResult();
    RecordResult thatValue = CommonTestFixture.getRecordResult();
    assertEquals(thisValue.toString(), thatValue.toString());
    thatValue.setReference(null);
    assertFalse(thisValue.toString().equals(thatValue.toString()));
  }

}
