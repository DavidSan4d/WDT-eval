package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import fedex.cis.common.util.DateUtility;

public class ConductedFilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testConductedFilter() {
    ConductedFilter result = new ConductedFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertNull(result.getFromDate());
    assertNull(result.getToDate());
  }

  @Test
  public void testConductedFilter_Date_Date() {
    java.util.Date fromDate = DateUtility.getDate();
    java.util.Date toDate = DateUtility.getDate();
    ConductedFilter result = new ConductedFilter(fromDate, toDate);
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertSame(fromDate, result.getFromDate());
    assertSame(toDate, result.getToDate());
  }

  @Test
  public void testConductedFilter_String_String() {
    String operator = "OPERATOR";
    java.util.Date fromDate = DateUtility.getDate();
    java.util.Date toDate = DateUtility.getDate();
    ConductedFilter result = new ConductedFilter(operator, fromDate, toDate);
    assertNotNull(result);
    assertSame(operator, result.getOperator());
    assertSame(fromDate, result.getFromDate());
    assertSame(toDate, result.getToDate());
  }

}
