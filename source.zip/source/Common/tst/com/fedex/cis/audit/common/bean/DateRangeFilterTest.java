package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

import fedex.cis.common.util.DateUtility;

public class DateRangeFilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testDateRangeFilter() {
    DateRangeFilter result = new DateRangeFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertNull(result.getFromDate());
    assertNull(result.getToDate());
  }

  @Test
  public void testDateRangeFilter_Date_Date() {
    java.util.Date fromDate = DateUtility.getDate();
    java.util.Date toDate = DateUtility.getDate();
    DateRangeFilter result = new DateRangeFilter(fromDate, toDate);
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertSame(fromDate, result.getFromDate());
    assertSame(toDate, result.getToDate());
  }

  @Test
  public void testDateRangeFilter_String_String() {
    String operator = "OPERATOR";
    java.util.Date fromDate = DateUtility.getDate();
    java.util.Date toDate = DateUtility.getDate();
    DateRangeFilter result = new DateRangeFilter(operator, fromDate, toDate);
    assertNotNull(result);
    assertSame(operator, result.getOperator());
    assertSame(fromDate, result.getFromDate());
    assertSame(toDate, result.getToDate());
  }

  @Test
  public void testSetAndGetFromDate() {
    java.util.Date value = DateUtility.getDate();
    DateRangeFilter result = CommonTestFixture.getDateRangeFilter();
    result.setFromDate(value);
    assertSame(value, result.getFromDate());
  }

  @Test
  public void testSetAndGetToDate() {
    java.util.Date value = DateUtility.getDate();
    DateRangeFilter result = CommonTestFixture.getDateRangeFilter();
    result.setToDate(value);
    assertSame(value, result.getToDate());
  }

}
