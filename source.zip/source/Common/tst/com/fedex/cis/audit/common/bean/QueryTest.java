package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class QueryTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testQuery() {
    Query result = new Query();
    assertNotNull(result);
    assertEquals(Query.RELATIONSHIP_AND, result.getRelationship());
    assertNull(result.getFilters());
  }

  @Test
  public void testQuery_Filters() {
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(2);
    filters.add(CommonTestFixture.getFilter());
    Query result = new Query(filters);
    assertNotNull(result);
    assertEquals(Query.RELATIONSHIP_AND, result.getRelationship());
    assertEquals(filters, result.getFilters());
  }

  @Test
  public void testQuery_String_Filters() {
    String relationship = "RELATIONSHIP";
    java.util.Collection<Filter> filters = new java.util.ArrayList<Filter>(2);
    filters.add(CommonTestFixture.getFilter());
    Query result = new Query(relationship, filters);
    assertNotNull(result);
    assertEquals(relationship, result.getRelationship());
    assertEquals(filters, result.getFilters());
  }

  @Test
  public void testSetAndGetRelationship() {
    String value = "RELATIONSHIP";
    Query result = CommonTestFixture.getQuery();
    result.setRelationship(value);
    assertSame(value, result.getRelationship());
  }

  @Test
  public void testSetAndGetFilters() {
    java.util.Collection<Filter> value = new java.util.ArrayList<Filter>(2);
    value.add(CommonTestFixture.getFilter());
    Query result = CommonTestFixture.getQuery();
    result.setFilters(value);
    assertSame(value, result.getFilters());
  }

}
