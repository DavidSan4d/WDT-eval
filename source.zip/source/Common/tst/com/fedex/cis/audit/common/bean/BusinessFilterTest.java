package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

public class BusinessFilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testBusinessFilter() {
    BusinessFilter result = new BusinessFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertNull(result.getText());
  }

  @Test
  public void testBusinessFilter_String() {
    String text = "TEXT";
    BusinessFilter result = new BusinessFilter(text);
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertSame(text, result.getText());
  }

  @Test
  public void testBusinessFilter_String_String() {
    String operator = "OPERATOR";
    String text = "TEXT";
    BusinessFilter result = new BusinessFilter(operator, text);
    assertNotNull(result);
    assertSame(operator, result.getOperator());
    assertSame(text, result.getText());
  }

}
