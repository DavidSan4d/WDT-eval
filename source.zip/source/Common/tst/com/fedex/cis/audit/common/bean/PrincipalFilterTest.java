package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

public class PrincipalFilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testPrincipalFilter() {
    PrincipalFilter result = new PrincipalFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertNull(result.getText());
  }

  @Test
  public void testPrincipalFilter_String() {
    String text = "TEXT";
    PrincipalFilter result = new PrincipalFilter(text);
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertSame(text, result.getText());
  }

  @Test
  public void testPrincipalFilter_String_String() {
    String operator = "OPERATOR";
    String text = "TEXT";
    PrincipalFilter result = new PrincipalFilter(operator, text);
    assertNotNull(result);
    assertSame(operator, result.getOperator());
    assertSame(text, result.getText());
  }

}
