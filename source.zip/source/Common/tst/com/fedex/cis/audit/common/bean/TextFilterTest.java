package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class TextFilterTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testTextFilter() {
    TextFilter result = new TextFilter();
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertNull(result.getText());
  }

  @Test
  public void testTextFilter_String() {
    String text = "TEXT";
    TextFilter result = new TextFilter(text);
    assertNotNull(result);
    assertEquals(Filter.OPERATOR_EQUAL, result.getOperator());
    assertSame(text, result.getText());
  }

  @Test
  public void testTextFilter_String_String() {
    String operator = "OPERATOR";
    String text = "TEXT";
    TextFilter result = new TextFilter(operator, text);
    assertNotNull(result);
    assertSame(operator, result.getOperator());
    assertSame(text, result.getText());
  }

  @Test
  public void testSetAndGetText() {
    String value = "VALUE";
    TextFilter result = CommonTestFixture.getTextFilter();
    result.setText(value);
    assertSame(value, result.getText());
  }

}
