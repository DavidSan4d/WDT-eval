package com.fedex.cis.audit.common.bean;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.common.CommonTestFixture;

public class AuditTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testAudit() {
    Audit result = new Audit();
    assertNotNull(result);
  }

  @Test
  public void testSetAndGetPrincipal() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getAudit();
    result.setPrincipal(value);
    assertSame(value, result.getPrincipal());
  }

  @Test
  public void testSetAndGetBusiness() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getAudit();
    result.setBusiness(value);
    assertSame(value, result.getBusiness());
  }

  @Test
  public void testSetAndGetConducted() {
    java.util.Date value = new java.util.Date();
    Audit result = CommonTestFixture.getAudit();
    result.setConducted(value);
    assertSame(value, result.getConducted());
  }

  @Test
  public void testSetAndGetPosted() {
    java.util.Date value = new java.util.Date();
    Audit result = CommonTestFixture.getAudit();
    result.setPosted(value);
    assertSame(value, result.getPosted());
  }

  @Test
  public void testSetAndGetClient() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getAudit();
    result.setClient(value);
    assertSame(value, result.getClient());
  }

  @Test
  public void testSetAndGetComment() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getAudit();
    result.setComment(value);
    assertSame(value, result.getComment());
  }

  @Test
  public void testSetAndGetMetadata() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getAudit();
    result.setMetadata(value);
    assertSame(value, result.getMetadata());
  }

  @Test
  public void testSetAndGetTransaction() {
    String value = "VALUE";
    Audit result = CommonTestFixture.getAudit();
    result.setTransaction(value);
    assertSame(value, result.getTransaction());
  }

  @Test
  public void testEquals() {
    Audit value = CommonTestFixture.getAudit();
    assertTrue(value.equals(value));
  }

  @Test
  public void testEqualsWithThatNull() {
    Audit thisValue = CommonTestFixture.getAudit();
    Audit thatValue = null;
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatClassNotEqual() {
    Audit thisValue = CommonTestFixture.getAudit();
    String thatValue = new String("VALUE");
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatEqual() {
    Audit thisValue = CommonTestFixture.getAudit();
    Audit thatValue = CommonTestFixture.getAudit();
    assertTrue(thisValue.equals(thatValue));
  }

  @Test
  public void testEqualsWithThatNotEqual() {
    Audit thisValue = CommonTestFixture.getAudit();
    Audit thatValue = CommonTestFixture.getAudit();
    thatValue.setPrincipal(null);
    assertFalse(thisValue.equals(thatValue));
  }

  @Test
  public void testHashCode() {
    Audit thisValue = CommonTestFixture.getAudit();
    Audit thatValue = CommonTestFixture.getAudit();
    assertTrue(thisValue.hashCode() == thatValue.hashCode());
    thatValue.setBusiness(null);
    assertFalse(thisValue.hashCode() == thatValue.hashCode());
  }

  @Test
  public void testToString() {
    Audit thisValue = CommonTestFixture.getAudit();
    Audit thatValue = CommonTestFixture.getAudit();
    assertEquals(thisValue.toString(), thatValue.toString());
    thatValue.setConducted(null);
    assertFalse(thisValue.toString().equals(thatValue.toString()));
  }

}
