package com.fedex.cis.audit.common.bean;

import fedex.cis.common.util.ObjectUtility;

@javax.xml.bind.annotation.XmlRootElement
public class RecordResult extends Result {

  public RecordResult() {}

  public RecordResult(boolean success, java.util.Collection<String> messages, String reference) {
    super(success, messages);
    setReference(reference);
  }

  private String reference;
  public String getReference() { return reference; }
  public void setReference(String value) { reference = value; }

  @Override
  public boolean equals(Object anObject) {
    boolean result = false;
    if ((super.equals(anObject)) && (anObject instanceof RecordResult)) {
      RecordResult that = (RecordResult) anObject;
      if (ObjectUtility.equals(getReference(), that.getReference())) {
        result = true;
      }
    }
    return result;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 37 * result + ObjectUtility.hashCode(getReference());
    return result;
  }

  @Override
  public String toString() {
    StringBuffer result = new StringBuffer();
    String lineSeparator = java.lang.System.getProperty("line.separator");
    result.append(super.toString() + lineSeparator);
    result.append(" - Reference: " + getReference());
    return result.toString();
  }

}
