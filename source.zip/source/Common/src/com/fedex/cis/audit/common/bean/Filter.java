package com.fedex.cis.audit.common.bean;

@javax.xml.bind.annotation.XmlSeeAlso({
  TextFilter.class,
  DateRangeFilter.class,
  NestedFilter.class,
  PrincipalFilter.class,
  BusinessFilter.class,
  ConductedFilter.class,
  ClientFilter.class,
  CommentFilter.class,
  MetadataFilter.class,
  TransactionFilter.class
})
@com.fasterxml.jackson.annotation.JsonTypeInfo(
    use = com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NAME, 
    include = com.fasterxml.jackson.annotation.JsonTypeInfo.As.PROPERTY, 
    property = "type")
@com.fasterxml.jackson.annotation.JsonSubTypes({  
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = TextFilter.class, name = "TEXT"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = DateRangeFilter.class, name = "DATERANGE"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = NestedFilter.class, name = "NESTED"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = PrincipalFilter.class, name = "PRINCIPAL"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = BusinessFilter.class, name = "BUSINESS"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = ConductedFilter.class, name = "CONDUCTED"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = ClientFilter.class, name = "CLIENT"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = CommentFilter.class, name = "COMMENT"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = MetadataFilter.class, name = "METADATA"),
  @com.fasterxml.jackson.annotation.JsonSubTypes.Type(value = TransactionFilter.class, name = "TRANSACTION")
})
public abstract class Filter {

  public static final String OPERATOR_EQUAL = "EQUAL";
  public static final String OPERATOR_MATCH = "MATCH";

  public Filter() {
    setOperator(OPERATOR_EQUAL);
  }

  public Filter(String operator) {
    setOperator(operator);
  }

  @io.swagger.annotations.ApiModelProperty(value="Filter operator",required=true,allowableValues="EQUAL,MATCH")
  //@io.swagger.v3.oas.annotations.media.Schema(description="Filter operator",required=true,allowableValues="EQUAL,MATCH")
  private String operator;
  public String getOperator() { return operator; }
  public void setOperator(String value) { operator = value; }

}
