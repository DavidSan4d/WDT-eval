package com.fedex.cis.audit.common.bean;

import fedex.cis.common.util.ObjectUtility;

@javax.xml.bind.annotation.XmlRootElement
public class Audit {

  //
  // Who conducted the action
  //

  private String principal;
  public String getPrincipal() { return principal; }
  public void setPrincipal(String value) { principal = value; }

  //
  // What action was conducted
  //

  private String business;
  public String getBusiness() { return business; }
  public void setBusiness(String value) { business = value; }

  //
  // When was action conducted
  //

  @com.fasterxml.jackson.annotation.JsonFormat(shape = com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private java.util.Date conducted;
  public java.util.Date getConducted() { return conducted; }
  public void setConducted(java.util.Date value) { conducted = value; }

  @com.fasterxml.jackson.annotation.JsonFormat(shape = com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private java.util.Date posted;
  public java.util.Date getPosted() { return posted; }
  public void setPosted(java.util.Date value) { posted = value; }

  //
  // Where was action conducted
  //

  private String client;
  public String getClient() { return client; }
  public void setClient(String value) { client = value; }

  //
  // Why was action conducted
  //

  private String comment;
  public String getComment() { return comment; }
  public void setComment(String value) { comment = value; } 

  private String metadata;
  public String getMetadata() { return metadata; }
  public void setMetadata(String value) { metadata = value; }

  //
  // How was action conducted
  //

  private String transaction;
  public String getTransaction() { return transaction; }
  public void setTransaction(String value) { transaction = value; }

  @Override
  public boolean equals(Object anObject) {
    boolean result = false;
    if (this == anObject) {
      result = true;
    } else if ((anObject != null) && (anObject instanceof Audit)) {
      Audit that = (Audit) anObject;
      if (ObjectUtility.equals(getPrincipal(), that.getPrincipal()) &&
          ObjectUtility.equals(getBusiness(), that.getBusiness()) &&
          ObjectUtility.equals(getConducted(), that.getConducted()) &&
          ObjectUtility.equals(getPosted(), that.getPosted()) &&
          ObjectUtility.equals(getClient(), that.getClient()) &&
          ObjectUtility.equals(getComment(), that.getComment()) &&
          ObjectUtility.equals(getMetadata(), that.getMetadata()) &&
          ObjectUtility.equals(getTransaction(), that.getTransaction())) {
        result = true;
      }
    }
    return result;
  }

  @Override
  public int hashCode() {
    int result = 23;
    result = 37 * result + ObjectUtility.hashCode(getPrincipal());
    result = 37 * result + ObjectUtility.hashCode(getBusiness());
    result = 37 * result + ObjectUtility.hashCode(getConducted());
    result = 37 * result + ObjectUtility.hashCode(getPosted());
    result = 37 * result + ObjectUtility.hashCode(getClient());
    result = 37 * result + ObjectUtility.hashCode(getComment());
    result = 37 * result + ObjectUtility.hashCode(getMetadata());
    result = 37 * result + ObjectUtility.hashCode(getTransaction());
    return result;
  }

  @Override
  public String toString() {
    StringBuffer result = new StringBuffer();
    String lineSeparator = java.lang.System.getProperty("line.separator");
    result.append(getClass().getName() + lineSeparator);
    result.append(" - Principal: " + getPrincipal() + lineSeparator);
    result.append(" - Business: " + getBusiness() + lineSeparator);
    result.append(" - Conducted: " + getConducted() + lineSeparator);
    result.append(" - Posted: " + getPosted() + lineSeparator);
    result.append(" - Client: " + getClient() + lineSeparator);
    result.append(" - Comment: " + getComment() + lineSeparator);
    result.append(" - Metadata: " + getMetadata() + lineSeparator);
    result.append(" - Transaction: " + getTransaction());
    return result.toString();
  }

}
