package com.fedex.cis.audit.common.bean;

@javax.xml.bind.annotation.XmlRootElement
@javax.xml.bind.annotation.XmlAccessorType(javax.xml.bind.annotation.XmlAccessType.FIELD)
public class Query {

  public static final String RELATIONSHIP_AND = "AND";
  public static final String RELATIONSHIP_OR = "OR";

  public Query() {
    setRelationship(RELATIONSHIP_AND);
  }

  public Query(java.util.Collection<Filter> filters) {
    setRelationship(RELATIONSHIP_AND);
    setFilters(filters);
  }

  public Query(String relationship, java.util.Collection<Filter> filters) {
    setRelationship(relationship);
    setFilters(filters);
  }

  @io.swagger.annotations.ApiModelProperty(value="Filter relationship",required=true,allowableValues="AND,OR")
  //@io.swagger.v3.oas.annotations.media.Schema(description="Filter relationship",required=true,allowableValues="AND,OR")
  private String relationship;
  public String getRelationship() { return relationship; }
  public void setRelationship(String value) { relationship = value; }

  @javax.xml.bind.annotation.XmlElement(name = "filter")
  @com.fasterxml.jackson.annotation.JsonProperty("filters")
  private java.util.Collection<Filter> filters;
  public java.util.Collection<Filter> getFilters() { return filters; }
  public void setFilters(java.util.Collection<Filter> value) { filters = value; }

}
