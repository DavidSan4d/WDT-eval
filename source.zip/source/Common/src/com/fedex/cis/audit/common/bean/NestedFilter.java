package com.fedex.cis.audit.common.bean;

public class NestedFilter extends Filter {

  public NestedFilter() {
    super();
  }

  public NestedFilter(Query query) {
    super();
    setQuery(query);
  }

  public NestedFilter(String operator, Query query) {
    super(operator);
    setQuery(query);
  }

  private Query query;
  public Query getQuery() { return query; }
  public void setQuery(Query value) { query = value; }

}
