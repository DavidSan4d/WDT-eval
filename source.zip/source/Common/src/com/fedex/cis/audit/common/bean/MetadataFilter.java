package com.fedex.cis.audit.common.bean;

public class MetadataFilter extends TextFilter {

  public MetadataFilter() {
    this(null, null);
  }

  public MetadataFilter(String type, String text) {
    this(OPERATOR_MATCH, type, text);
  }

  public MetadataFilter(String operator, String type, String text) {
    super(operator, text);
    setType(type);
  }

  private String type;
  public String getType() { return type; }
  public void setType(String value) { type = value; }

}
