package com.fedex.cis.audit.common.bean;

import fedex.cis.common.util.ObjectUtility;

@javax.xml.bind.annotation.XmlRootElement
@javax.xml.bind.annotation.XmlAccessorType(javax.xml.bind.annotation.XmlAccessType.FIELD)
public class QueryResult extends Result {

  public QueryResult() {}

  public QueryResult(boolean success, java.util.Collection<String> messages, java.util.Collection<Record> records) {
    super(success, messages);
    setRecords(records);
  }

  @javax.xml.bind.annotation.XmlElement(name = "record")
  @com.fasterxml.jackson.annotation.JsonProperty("records")
  private java.util.Collection<Record> records;
  public java.util.Collection<Record> getRecords() { return records; }
  public void setRecords(java.util.Collection<Record> value) { records = value; }

  @Override
  public boolean equals(Object anObject) {
    boolean result = false;
    if ((super.equals(anObject)) && (anObject instanceof QueryResult)) {
      QueryResult that = (QueryResult) anObject;
      if (ObjectUtility.equals(getRecords(), that.getRecords())) {
        result = true;
      }
    }
    return result;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 37 * result + ObjectUtility.hashCode(getRecords());
    return result;
  }

  @Override
  public String toString() {
    StringBuffer result = new StringBuffer();
    String lineSeparator = java.lang.System.getProperty("line.separator");
    result.append(super.toString() + lineSeparator);
    result.append(" - Records: " + getRecords());
    return result.toString();
  }

}
