package com.fedex.cis.audit.common.bean;

import fedex.cis.common.util.ObjectUtility;

public class Record extends Audit {

  public static Record getInstance(Audit audit, String reference, String who, java.util.Date when) {
    Record result = new Record();
    if (audit != null) {
      if (ObjectUtility.isValue(audit.getPrincipal())) { result.setPrincipal(audit.getPrincipal().trim().toUpperCase()); }
      if (ObjectUtility.isValue(audit.getBusiness())) { result.setBusiness(audit.getBusiness().trim().toUpperCase()); }
      result.setConducted(audit.getConducted());
      result.setPosted(audit.getPosted());
      if (ObjectUtility.isValue(audit.getClient())) { result.setClient(audit.getClient().trim().toUpperCase()); }
      if (ObjectUtility.isValue(audit.getComment())) { result.setComment(audit.getComment().trim()); }    // Leave case sensitive!
      if (ObjectUtility.isValue(audit.getMetadata())) { result.setMetadata(audit.getMetadata().trim()); } // Leave case sensitive!
      if (ObjectUtility.isValue(audit.getTransaction())) { result.setTransaction(audit.getTransaction().trim().toUpperCase()); }
    }
    result.setReference(reference);
    result.setWho(who);
    result.setWhen(when);
    return result;
  }

  private String reference;
  public String getReference() { return reference; }
  public void setReference(String value) { reference = value; }

  private String who;
  public String getWho() { return who; }
  public void setWho(String value) { who = value; }

  @com.fasterxml.jackson.annotation.JsonFormat(shape = com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private java.util.Date when;
  public java.util.Date getWhen() { return when; }
  public void setWhen(java.util.Date value) { when = value; }


  @Override
  public boolean equals(Object anObject) {
    boolean result = false;
    if ((super.equals(anObject)) && (anObject instanceof Record)) {
      Record that = (Record) anObject;
      if (ObjectUtility.equals(getReference(), that.getReference()) &&
          ObjectUtility.equals(getWho(), that.getWho()) &&
          ObjectUtility.equals(getWhen(), that.getWhen())) {
        result = true;
      }
    }
    return result;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 37 * result + ObjectUtility.hashCode(getReference());
    result = 37 * result + ObjectUtility.hashCode(getWho());
    result = 37 * result + ObjectUtility.hashCode(getWhen());
    return result;
  }

  @Override
  public String toString() {
    StringBuffer result = new StringBuffer();
    String lineSeparator = java.lang.System.getProperty("line.separator");
    result.append(super.toString() + lineSeparator);
    result.append(" - Reference: " + getReference() + lineSeparator);
    result.append(" - Who: " + getWho() + lineSeparator);
    result.append(" - When: " + getWhen());
    return result.toString();
  }

}
