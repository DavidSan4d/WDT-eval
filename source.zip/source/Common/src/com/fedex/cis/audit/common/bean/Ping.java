package com.fedex.cis.audit.common.bean;

@javax.xml.bind.annotation.XmlRootElement
public class Ping {

  private String text;
  public String getText() { return text; }
  public void setText(String value) { text = value; }

}
