package com.fedex.cis.audit.common.bean;

public class TextFilter extends Filter {

  public TextFilter() {
    super();
  }

  public TextFilter(String text) {
    super();
    setText(text);
  }

  public TextFilter(String operator, String text) {
    super(operator);
    setText(text);
  }

  private String text;
  public String getText() { return text; }
  public void setText(String value) { text = value; }

}
