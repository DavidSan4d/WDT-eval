package com.fedex.cis.audit.common.tbd.v1;

import com.fedex.cis.audit.common.bean.Record;

import fedex.cis.common.util.ObjectUtility;

@SuppressWarnings("deprecation")
@javax.xml.bind.annotation.XmlRootElement(name="audits")
@javax.xml.bind.annotation.XmlAccessorType(javax.xml.bind.annotation.XmlAccessType.FIELD)
public class AuditListDto {

  public static AuditListDto getInstance(java.util.Collection<Record> records) {
    AuditListDto result = null;
    if (ObjectUtility.isValue(records)) {
      result = new AuditListDto();
      java.util.Collection<Audit> audits = new java.util.ArrayList<Audit>(records.size());
      for (Record record : records) { audits.add(Audit.getInstance(record)); }
      result.setAudits(audits);
    }
    return result;
  }

  @javax.xml.bind.annotation.XmlElement(name="audit")
  @com.fasterxml.jackson.annotation.JsonProperty("audits")
  private java.util.Collection<Audit> audits;
  public java.util.Collection<Audit> getAudits() { return audits; }
  public void setAudits(java.util.Collection<Audit> value) { audits = value; }

}
