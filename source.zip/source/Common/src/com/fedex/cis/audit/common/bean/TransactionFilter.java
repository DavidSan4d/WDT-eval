package com.fedex.cis.audit.common.bean;

public class TransactionFilter extends TextFilter {

  public TransactionFilter() {
    super();
  }

  public TransactionFilter(String text) {
    super(text);
  }

  public TransactionFilter(String operator, String text) {
    super(operator, text);
  }

}
