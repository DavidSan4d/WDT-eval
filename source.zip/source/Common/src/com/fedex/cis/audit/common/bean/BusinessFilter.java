package com.fedex.cis.audit.common.bean;

public class BusinessFilter extends TextFilter {

  public BusinessFilter() {
    super();
  }

  public BusinessFilter(String text) {
    super(text);
  }

  public BusinessFilter(String operator, String text) {
    super(operator, text);
  }

}
