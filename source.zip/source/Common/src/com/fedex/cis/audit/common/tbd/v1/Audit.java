package com.fedex.cis.audit.common.tbd.v1;

import com.fedex.cis.audit.common.bean.Record;

@Deprecated
@javax.xml.bind.annotation.XmlRootElement
public class Audit {

  public static Audit getInstance(Record record) {
    Audit result = null;
    if (record != null) {
      result = new Audit();
      result.setPrincipal(record.getPrincipal());
      result.setBusiness(record.getBusiness());
      result.setTransaction(record.getTransaction());
      result.setConducted(record.getConducted());
      result.setPosted(record.getPosted());
      result.setReceived(record.getWhen());
      result.setService(record.getWho());
      result.setClient(record.getClient());
      result.setComment(record.getComment());
      result.setMetadata(record.getMetadata());
    }
    return result;
  }

  public static com.fedex.cis.audit.common.bean.Audit toAudit(Audit audit) {
    com.fedex.cis.audit.common.bean.Audit result = null;
    if (audit != null) {
      result = new com.fedex.cis.audit.common.bean.Audit();
      result.setPrincipal(audit.getPrincipal());
      result.setBusiness(audit.getBusiness());
      result.setTransaction(audit.getTransaction());
      result.setConducted(audit.getConducted());
      result.setPosted(audit.getPosted());
      result.setClient(audit.getClient());
      result.setComment(audit.getComment());
      result.setMetadata(audit.getMetadata());
    }
    return result;
  }

  //
  // Who conducted the action
  //

  private String principal;
  public String getPrincipal() { return principal; }
  public void setPrincipal(String value) { principal = value; }

  //
  // What action was conducted
  //

  private String business;
  public String getBusiness() { return business; }
  public void setBusiness(String value) { business = value; }

  private String transaction;
  public String getTransaction() { return transaction; }
  public void setTransaction(String value) { transaction = value; }

  //
  // When was action conducted
  //

  @com.fasterxml.jackson.annotation.JsonFormat(shape = com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private java.util.Date conducted;
  public java.util.Date getConducted() { return conducted; }
  public void setConducted(java.util.Date value) { conducted = value; }

  @com.fasterxml.jackson.annotation.JsonFormat(shape = com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private java.util.Date posted;
  public java.util.Date getPosted() { return posted; }
  public void setPosted(java.util.Date value) { posted = value; }

  @com.fasterxml.jackson.annotation.JsonFormat(shape = com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private java.util.Date received;
  public java.util.Date getReceived() { return received; }
  public void setReceived(java.util.Date value) { received = value; }

  //
  // Where was action conducted
  //

  private String service;
  public String getService() { return service; }
  public void setService(String value) { service = value; }

  private String client;
  public String getClient() { return client; }
  public void setClient(String value) { client = value; }

  //
  // Why was action conducted
  //

  private String comment;
  public String getComment() { return comment; }
  public void setComment(String value) { comment = value; } 

  //
  // How was action conducted
  //

  private String metadata;
  public String getMetadata() { return metadata; }
  public void setMetadata(String value) { metadata = value; }

}
