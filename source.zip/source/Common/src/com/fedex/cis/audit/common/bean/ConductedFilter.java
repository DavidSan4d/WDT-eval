package com.fedex.cis.audit.common.bean;

public class ConductedFilter extends DateRangeFilter {

  public ConductedFilter() {
    super();
  }

  public ConductedFilter(java.util.Date fromDate, java.util.Date toDate) {
    super(fromDate, toDate);
  }

  public ConductedFilter(String operator, java.util.Date fromDate, java.util.Date toDate) {
    super(operator, fromDate, toDate);
  }

}
