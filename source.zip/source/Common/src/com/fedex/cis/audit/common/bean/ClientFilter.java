package com.fedex.cis.audit.common.bean;

public class ClientFilter extends TextFilter {

  public ClientFilter() {
    super();
  }

  public ClientFilter(String text) {
    super(text);
  }

  public ClientFilter(String operator, String text) {
    super(operator, text);
  }

}
