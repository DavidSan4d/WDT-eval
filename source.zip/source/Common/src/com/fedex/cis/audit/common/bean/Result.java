package com.fedex.cis.audit.common.bean;

import fedex.cis.common.util.ObjectUtility;

@javax.xml.bind.annotation.XmlRootElement
@javax.xml.bind.annotation.XmlAccessorType(javax.xml.bind.annotation.XmlAccessType.FIELD)
public class Result {

  public Result() {}

  public Result(boolean success, java.util.Collection<String> messages) {
    setSuccess(success);
    setMessages(messages);
  }

  private boolean success;
  public boolean isSuccess() { return success; }
  public void setSuccess(boolean value) { success = value; }

  @javax.xml.bind.annotation.XmlElement(name = "message")
  @com.fasterxml.jackson.annotation.JsonProperty("messages")
  private java.util.Collection<String> messages;
  public java.util.Collection<String> getMessages() { return messages; }
  public void setMessages(java.util.Collection<String> value) { messages = value; }

  @Override
  public boolean equals(Object anObject) {
    boolean result = false;
    if (this == anObject) {
      result = true;
    } else if ((anObject != null) && (anObject instanceof Result)) {
      Result that = (Result) anObject;
      if (ObjectUtility.equals(isSuccess(), that.isSuccess()) &&
          ObjectUtility.equals(getMessages(), that.getMessages())) {
        result = true;
      }
    }
    return result;
  }

  @Override
  public int hashCode() {
    int result = 23;
    result = 37 * result + ObjectUtility.hashCode(isSuccess());
    result = 37 * result + ObjectUtility.hashCode(getMessages());
    return result;
  }

  @Override
  public String toString() {
    StringBuffer result = new StringBuffer();
    String lineSeparator = java.lang.System.getProperty("line.separator");
    result.append(getClass().getName() + lineSeparator);
    result.append(" - Success: " + isSuccess() + lineSeparator);
    result.append(" - Messages: " + getMessages());
    return result.toString();
  }

}
