package com.fedex.cis.audit.common.bean;

public class CommentFilter extends TextFilter {

  public CommentFilter() {
    this(null);
  }

  public CommentFilter(String text) {
    this(OPERATOR_MATCH, text);
  }

  public CommentFilter(String operator, String text) {
    super(operator, text);
  }

}
