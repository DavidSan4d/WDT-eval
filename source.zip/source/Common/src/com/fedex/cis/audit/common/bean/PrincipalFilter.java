package com.fedex.cis.audit.common.bean;

public class PrincipalFilter extends TextFilter {

  public PrincipalFilter() {
    super();
  }

  public PrincipalFilter(String text) {
    super(text);
  }

  public PrincipalFilter(String operator, String text) {
    super(operator, text);
  }

}
