package com.fedex.cis.audit.common.bean;

@javax.xml.bind.annotation.XmlAccessorType(javax.xml.bind.annotation.XmlAccessType.FIELD)
public class DateRangeFilter extends Filter {

  public DateRangeFilter() {
    super();
  }

  public DateRangeFilter(java.util.Date fromDate, java.util.Date toDate) {
    super();
    setFromDate(fromDate);
    setToDate(toDate);
  }

  public DateRangeFilter(String operator, java.util.Date fromDate, java.util.Date toDate) {
    super(operator);
    setFromDate(fromDate);
    setToDate(toDate);
  }

  @javax.xml.bind.annotation.XmlElement(name = "from")
  @com.fasterxml.jackson.annotation.JsonFormat(shape = com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private java.util.Date fromDate;
  public java.util.Date getFromDate() { return fromDate; }
  public void setFromDate(java.util.Date value) { fromDate = value; }

  @javax.xml.bind.annotation.XmlElement(name = "to")
  @com.fasterxml.jackson.annotation.JsonFormat(shape = com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private java.util.Date toDate;
  public java.util.Date getToDate() { return toDate; }
  public void setToDate(java.util.Date value) { toDate = value; }

}
