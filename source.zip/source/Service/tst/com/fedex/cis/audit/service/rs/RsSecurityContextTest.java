package com.fedex.cis.audit.service.rs;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.service.ServiceTestFixture;
import com.fedex.cis.audit.service.session.SessionPrincipal;

public class RsSecurityContextTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testRsSecurityContext() {
    SessionPrincipal principal = ServiceTestFixture.getSessionPrincipal();
    String scheme = "SCHEME";
    boolean secure = true;
    RsSecurityContext result = new RsSecurityContext(principal, scheme, secure);
    assertNotNull(result);
  }

  @Test
  public void testGetUserPrincipal() {
    RsSecurityContext value = ServiceTestFixture.getRsSecurityContext();
    java.security.Principal result = value.getUserPrincipal();
    assertNotNull(result);
    assertTrue(result instanceof SessionPrincipal);
  }

  @Test
  public void testGetAuthenticationScheme() {
    RsSecurityContext value = ServiceTestFixture.getRsSecurityContext();
    String result = value.getAuthenticationScheme();
    assertEquals("SCHEME", result);
  }

  @Test
  public void testIsSecure() {
    RsSecurityContext value = ServiceTestFixture.getRsSecurityContext();
    boolean result = value.isSecure();
    assertTrue(result);
  }

  @Test
  public void testIsUserInRole() {
    String role = "ROLE";
    RsSecurityContext value = ServiceTestFixture.getRsSecurityContext();
    boolean result = value.isUserInRole(role);
    assertTrue(result);
  }

}
