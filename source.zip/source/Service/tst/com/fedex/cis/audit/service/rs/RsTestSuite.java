package com.fedex.cis.audit.service.rs;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  RsSecurityContextTest.class,
  RsErrorTest.class
  // All web services should be tested via Remote project! 
})

public class RsTestSuite {
  // Intentionally left blank!
}
