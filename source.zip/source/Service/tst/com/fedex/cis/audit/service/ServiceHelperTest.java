package com.fedex.cis.audit.service;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.server.business.BusinessManager;
import com.fedex.cis.audit.service.session.SessionManager;

public class ServiceHelperTest {

  private static ServiceHelper helper = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    helper = new ServiceHelper();
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    helper = null;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  private ServiceHelper getHelper() {
    return helper;
  }

  @Test
  public void testServiceHelper() throws Exception {
    ServiceHelper result = new ServiceHelper();
    assertNotNull(result);
  }

  @Test
  public void testRefresh() throws Exception {
    SessionManager session1 = helper.getSession();
    BusinessManager business1 = helper.getBusiness();
    assertNotNull(session1);
    assertNotNull(business1);
    SessionManager session2 = helper.getSession();
    BusinessManager business2 = helper.getBusiness();
    assertSame(session1, session2);
    assertSame(business1, business2);
    helper.refresh();
    SessionManager session3 = helper.getSession();
    BusinessManager business3 = helper.getBusiness();
    assertNotSame(session2, session3);
    assertNotSame(business2, business3);
  }

  @Test
  public void testGetSession() throws Exception {
    SessionManager result = helper.getSession();
    assertNotNull(result);
  }

  @Test
  public void testGetBusiness() throws Exception {
    BusinessManager result = helper.getBusiness();
    assertNotNull(result);
  }

  public static void main(String[] args) {
    try {
      ServiceHelperTest test = new ServiceHelperTest();
      ServiceHelperTest.setUpBeforeClass(); 
      ServiceHelper helper = test.getHelper();
      new Thread(test.new JUnitThread(helper, "A")).start();
      new Thread(test.new JUnitThread(helper, "B")).start();
      new Thread(test.new JUnitThread(helper, "C")).start();
      new Thread(test.new JUnitThread(helper, "D")).start();
      new Thread(test.new JUnitThread(helper, "E")).start();
      new Thread(test.new JUnitThread(helper, "F")).start();
      new Thread(test.new JUnitThread(helper, "G")).start();
      new Thread(test.new JUnitThread(helper, "H")).start();
      new Thread(test.new JUnitThread(helper, "I")).start();
      new Thread(test.new JUnitThread(helper, "J")).start();
      new Thread(test.new JUnitThread(helper, "K")).start();
      new Thread(test.new JUnitThread(helper, "L")).start();
      new Thread(test.new JUnitThread(helper, "M")).start();
      new Thread(test.new JUnitThread(helper, "N")).start();
      new Thread(test.new JUnitThread(helper, "O")).start();
      new Thread(test.new JUnitThread(helper, "P")).start();
      new Thread(test.new JUnitThread(helper, "Q")).start();
      new Thread(test.new JUnitThread(helper, "R")).start();
      new Thread(test.new JUnitThread(helper, "S")).start();
      new Thread(test.new JUnitThread(helper, "T")).start();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public class JUnitThread implements Runnable {

    private ServiceHelper helper = null;
    private String label = null;

    public JUnitThread(ServiceHelper helper, String label) {
      this.helper = helper;
      this.label = label; 
    }

    @Override
    public void run() {
      System.out.println("Starting <" + label + ">");
      for (int i = 0; i < 25; i++) {
        try {
          SessionManager session = helper.getSession();
          if (session == null) { System.err.println("Error <" + label + ">: getSession()"); }
          BusinessManager business = helper.getBusiness();
          if (business == null) { System.err.println("Error <" + label + ">: getBusiness()"); }
          helper.refresh();
        } catch (Exception e) {
          System.err.println("Caught <" + label + ">");
          e.printStackTrace();
        }
      }
      System.out.println("Finished <" + label + ">");
    }

  }

}
