package com.fedex.cis.audit.service.session;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  SessionPrincipalTest.class,
  SessionManagerTest.class
})

public class SessionTestSuite {
  // Intentionally left blank!
}
