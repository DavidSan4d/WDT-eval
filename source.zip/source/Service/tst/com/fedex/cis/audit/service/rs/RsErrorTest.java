package com.fedex.cis.audit.service.rs;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.service.ServiceTestFixture;

public class RsErrorTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testRsError() {
    RsError result = new RsError();
    assertNotNull(result);
  }

  @Test
  public void testSetAndGetMessage() {
    String value = "VALUE";
    RsError result = ServiceTestFixture.getRsError();
    result.setMessage(value);
    assertSame(value, result.getMessage());
  }

  @Test
  public void testSetAndIsBusiness() {
    boolean value = true;
    RsError result = ServiceTestFixture.getRsError();
    result.setBusiness(value);
    assertSame(value, result.isBusiness());
  }

}
