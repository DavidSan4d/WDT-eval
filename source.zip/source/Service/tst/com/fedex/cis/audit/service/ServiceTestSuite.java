package com.fedex.cis.audit.service;

import org.junit.runner.RunWith;
import org.junit.runners.*;
import org.junit.runners.Suite.SuiteClasses;

import com.fedex.cis.audit.service.rs.RsTestSuite;
import com.fedex.cis.audit.service.session.SessionTestSuite;

@RunWith(Suite.class)
@SuiteClasses({
  ServiceHelperTest.class,
  ServiceManagerTest.class,
  SessionTestSuite.class,
  RsTestSuite.class
})

public class ServiceTestSuite {
  // Intentionally left blank!
}
