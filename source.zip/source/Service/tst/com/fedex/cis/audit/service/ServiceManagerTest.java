package com.fedex.cis.audit.service;

import static org.junit.Assert.assertNotNull;

import org.junit.*;

import com.fedex.cis.audit.server.business.BusinessManager;
import com.fedex.cis.audit.service.session.SessionManager;

public class ServiceManagerTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testRefresh() {
    ServiceManager.refresh();
  }

  @Test
  public void testGetSession() throws Exception {
    SessionManager result = ServiceManager.getSession();
    assertNotNull(result);
  }

  @Test
  public void testGetBusiness() throws Exception {
    BusinessManager result = ServiceManager.getBusiness();
    assertNotNull(result);
  }

}
