package com.fedex.cis.audit.service;

import com.fedex.cis.audit.server.ServerTestFixture;
import com.fedex.cis.audit.service.rs.*;
import com.fedex.cis.audit.service.session.SessionPrincipal;

import fedex.cis.common.property.*;
import fedex.cis.common.util.PropertiesUtility;

public class ServiceTestFixture {

  private static volatile java.util.Properties properties = null;
  private static String propertiesLock = new String("PropertiesLock");

  public static java.util.Properties getProperties() throws Exception {
    return getProperties(null);
  }

  public static java.util.Properties getProperties(String propertyPrefix) throws Exception {
    if (properties == null) {
      synchronized (propertiesLock) {
        if (properties == null) {
          java.util.Properties serviceProperties = getPropertiesByEnvironment();
          properties = PropertiesUtility.expandProperties(serviceProperties, null, null);
          ServerTestFixture.getProperties(); // Forces server to preload test properties!
        }
      }
    }
    if (propertyPrefix == null) {
      return PropertiesUtility.copyProperties(properties);
    } else {
      return PropertiesUtility.extractProperties(properties, propertyPrefix);
    }
  }

  private static java.util.Properties getPropertiesByEnvironment() throws Exception {
    java.util.Properties result = null;
    String cisEnvironment = java.lang.System.getProperty("CIS_ENVIRONMENT");
    java.lang.System.setProperty("cis.deployment", "../Shared/etc/deployment_" + cisEnvironment + ".properties");
    PropertyContext propertyContext = PropertyHelper.getEnvironmentPropertyContext("cis.deployment", "cis.deployment.service.");
    PropertyManager propertyManager = PropertyFactory.getManager(propertyContext);
    result = propertyManager.getProperties();
    return result;
  }

  private static volatile String token = null;
  private static String tokenLock = new String("TokenLock");

  public static String getTestToken() throws Exception {
    if (token == null) {
      synchronized (tokenLock) {
        if (token == null) {
          token = downloadContent("http://cis-services-l1.ute.fedex.com:7001/authn/rs/o2b/token/access/test", "application/jwt");
        }
      }
    }
    return token;
  }

  private static String downloadContent(String url, String accept) throws Exception {
    String result = null;
    java.net.HttpURLConnection connection = null;
    java.io.InputStreamReader streamReader = null;
    java.io.BufferedReader bufferedReader = null;
    try {
      connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", accept);
      int responseCode = connection.getResponseCode();
      if (responseCode != 200) { throw new Exception("Unexpected HTTP response code: " + responseCode + ": " + connection.getResponseMessage()); }
      streamReader = new java.io.InputStreamReader(connection.getInputStream());
      bufferedReader = new java.io.BufferedReader(streamReader);
      String line;
      StringBuilder content = new StringBuilder();
      while ((line = bufferedReader.readLine()) != null) {
        content.append(line);
      }
      result = content.toString();
    } catch (Exception e) {
      throw new Exception("Failed to download content", e);
    } finally {
      if (bufferedReader != null) { try { bufferedReader.close(); } catch (Exception e) {} }
      if (streamReader != null) { try { streamReader.close(); } catch (Exception e) {} }
      if (connection != null) { try { connection.disconnect(); } catch (Exception e) {} }
    }
    return result;
  }

  public static SessionPrincipal getSessionPrincipal() {
    String role = "ROLE";
    java.util.Set<String> roles = new java.util.HashSet<String>();
    roles.add(role);
    return getSessionPrincipal(roles);
  }

  public static SessionPrincipal getSessionPrincipal(java.util.Set<String> roles) {
    String name = "USER";
    return getSessionPrincipal(name, roles);
  }

  public static SessionPrincipal getSessionPrincipal(String name, java.util.Set<String> roles) {
    boolean trusted = false;
    return getSessionPrincipal(name, roles, trusted);
  }

  public static SessionPrincipal getSessionPrincipal(String name, java.util.Set<String> roles, boolean trusted) {
    String domain = "DOMAIN";
    return new SessionPrincipal(name, domain, roles, trusted);
  }

  public static RsSecurityContext getRsSecurityContext() {
    return getRsSecurityContext(getSessionPrincipal());
  }

  public static RsSecurityContext getRsSecurityContext(SessionPrincipal principal) {
    String scheme = "SCHEME";
    boolean secure = true;
    RsSecurityContext result = new RsSecurityContext(principal, scheme, secure);
    return result;
  }

  public static RsError getRsError() {
    RsError result = new RsError();
    result.setMessage("MESSAGE");
    result.setBusiness(true);
    return result;
  }

}
