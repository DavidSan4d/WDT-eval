package com.fedex.cis.audit.service.session;

import static org.junit.Assert.*;

import org.junit.*;

import com.fedex.cis.audit.service.ServiceTestFixture;

import fedex.cis.common.util.PropertiesUtility;

public class SessionManagerTest {

  private static java.util.Properties properties = null;
  private static SessionManager manager = null;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    properties = ServiceTestFixture.getProperties("cis.service.session.");
    manager = new SessionManager(properties);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    manager = null;
    properties = null;
  }

  private java.util.Properties getProperties() {
    return PropertiesUtility.copyProperties(properties);
  }

  private SessionManager getManager() {
    return manager;
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testSessionManager() {
    SessionManager result = new SessionManager(getProperties());
    assertNotNull(result);
  }

  @Test
  public void testGetPrincipal() throws Exception {
    String audience = "c2b";
    String domainName = SessionManager.DOMAIN + audience.toUpperCase();
    SessionPrincipal result = getManager().getPrincipal(ServiceTestFixture.getTestToken(), audience, domainName);
    assertNotNull(result);
    assertNotNull(result.getName());
    assertSame(domainName, result.getDomain());
    assertFalse(result.isTrusted());
    assertTrue(0 < result.getRoles().size());
  }

  @Test
  public void testGetPrincipal_WithDomainNotDefined() throws Exception {
    String audience = "c2b";
    String domainName = null;
    SessionPrincipal result = getManager().getPrincipal(ServiceTestFixture.getTestToken(), audience, domainName);
    assertNotNull(result);
    assertNotNull(result.getName());
    assertNull(result.getDomain());
    assertFalse(result.isTrusted());
    assertNull(result.getRoles());
  }

}
