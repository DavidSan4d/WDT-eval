package com.fedex.cis.audit.service.session;

import static org.junit.Assert.*;

import org.junit.*;

public class SessionPrincipalTest {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testSessionPrincipal() {
    String name = "USER";
    String domain = "DOMAIN";
    String role = "ROLE";
    java.util.Set<String> roles = new java.util.HashSet<String>();
    roles.add(role);
    boolean trusted = true;
    SessionPrincipal result = new SessionPrincipal(name, domain, roles, trusted);
    assertNotNull(result);
    assertSame(name, result.getName());
    assertSame(domain, result.getDomain());
    assertSame(role, result.getRoles().iterator().next());
    assertSame(trusted, result.isTrusted());
  }

}
