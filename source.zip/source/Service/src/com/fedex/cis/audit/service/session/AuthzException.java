package com.fedex.cis.audit.service.session;

public class AuthzException extends Exception {

  private static final long serialVersionUID = 1L;

  public AuthzException(String message) { super(message); }

  public AuthzException(String message, Throwable cause) { super(message, cause); }

}
