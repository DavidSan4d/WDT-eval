package com.fedex.cis.audit.service.rs;

/**
 * Exception to Response mapper for all CIS exceptions.
 * @author Michael Cronk
 */

import fedex.cis.common.exception.CisException;
import fedex.cis.common.util.ExceptionUtility;

@javax.ws.rs.ext.Provider
public class RsCisExceptionMapper implements javax.ws.rs.ext.ExceptionMapper<CisException> {

  // Private constants
  private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RsCisExceptionMapper.class);
  private static final String SYSTEM_MESSAGE = "Contact CIS support";

  /**
   * Map an exception to a Response.
   * @param e CisException
   * @return javax.ws.rs.core.Response
   * @author Michael Cronk
   */
  @Override
  public javax.ws.rs.core.Response toResponse(CisException e) {
    // Get cause
    java.lang.Throwable cause = ExceptionUtility.getCause(e);
    // Get error
    RsError error = new RsError();
    if (ExceptionUtility.isBusinessException(cause)) {
      error.setMessage(cause.getMessage());
      error.setBusiness(true);
      if (logger.isInfoEnabled()) { logger.info(error.getMessage()); }
    } else {
      error.setMessage(SYSTEM_MESSAGE);
      if (logger.isErrorEnabled()) { logger.error(error.getMessage(), e); }
    }
    // Return response
    return javax.ws.rs.core.Response
        .status(javax.ws.rs.core.Response.Status.INTERNAL_SERVER_ERROR)
        .entity(error)
        .build();
  }

}
