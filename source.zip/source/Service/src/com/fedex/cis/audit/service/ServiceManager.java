package com.fedex.cis.audit.service;

/**
 * Service manager.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.server.business.BusinessManager;
import com.fedex.cis.audit.service.session.SessionManager;

import fedex.cis.common.server.exception.ServerCisException;

public class ServiceManager {

  // Private attributes
  private static final ServiceHelper helper = new ServiceHelper();

  /**
   * Refresh.
   * @author Michael Cronk
   */
  public static void refresh() {
    helper.refresh();
  }

  /**
   * Get session.
   * @return SessionManager
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public static SessionManager getSession() throws ServerCisException {
    return helper.getSession();
  }

  /**
   * Get business.
   * @return BusinessManager
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public static BusinessManager getBusiness() throws ServerCisException {
    return helper.getBusiness();
  }

}
