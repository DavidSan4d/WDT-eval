package com.fedex.cis.audit.service;

/**
 * Service helper.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.server.ServerManager;
import com.fedex.cis.audit.server.business.BusinessManager;
import com.fedex.cis.audit.service.session.SessionManager;

import fedex.cis.common.property.*;
import fedex.cis.common.server.exception.ServerCisException;
import fedex.cis.common.util.*;

public class ServiceHelper {

  // Private attributes
  private final java.util.concurrent.locks.ReentrantReadWriteLock readWriteLock;
  private final java.util.concurrent.locks.Lock readLock;
  private final java.util.concurrent.locks.Lock writeLock;

  // Private lock methods
  private void getReadLock() { readLock.lock(); }
  private void releaseReadLock() { readLock.unlock(); }
  private void getWriteLock() { writeLock.lock(); }
  private void releaseWriteLock() { writeLock.unlock(); }
  private void upgradeReadToWriteLock() { readLock.unlock(); writeLock.lock(); }
  private void downgradeWriteToReadLock() { readLock.lock(); writeLock.unlock(); }

  /**
   * Construct service helper.
   * @author Michael Cronk
   */
  public ServiceHelper() {
    readWriteLock = new java.util.concurrent.locks.ReentrantReadWriteLock(true);
    readLock = readWriteLock.readLock();
    writeLock = readWriteLock.writeLock();
  }

  // ---------------------------------------------------------------------- //
  //                           P R O P E R T I E S                          //
  // ---------------------------------------------------------------------- //

  // Private constants
  private static final String DEPLOYMENT_PROPERTIES = "cis.deployment.service.";
  private static final String ENVIRONMENT_PROPERTY = "CIS_PROPERTIES";
  private static final String CLASSPATH_DEPLOYMENT_PREFIX = "deployment_";
  private static final String CLASSPATH_DEPLOYMENT_SUFFIX = ".properties";
  private static final String HELPER_PROPERTIES = "cis.service.";

  // Private attributes
  private java.util.Properties properties = null;
  private java.util.Date propertiesLoaded = null;

  /**
   * Refresh.
   * @author Michael Cronk
   */
  public void refresh() {
    getWriteLock();
    try {
      propertiesLoaded = null;
      ServerManager.refresh();
    } finally {
      releaseWriteLock();
    }
  }

  /**
   * Get properties.
   * @return java.util.Properties
   * @throws ServerCisException
   * @author Michael Cronk
   */
  private java.util.Properties getProperties() throws ServerCisException {
    java.util.Properties result = null;
    // Guaranteed to already be in a write lock!
    try {
      if ((properties == null) || (propertiesLoaded == null)) {
        setPropertiesByEnvironment();
        if (properties == null) {
          setPropertiesByClasspath();
        }
        properties = PropertiesUtility.expandProperties(properties, null, null);
        propertiesLoaded = DateUtility.getDate();
      }
      result = properties;
    } catch (Exception e) {
      throw new ServerCisException("Failed to get properties", e);
    }
    return result;
  }

  /**
   * Set properties by environment.
   * @throws ServerCisException
   * @author Michael Cronk
   */
  private void setPropertiesByEnvironment() throws ServerCisException {
    try {
      PropertyContext propertyContext = PropertyHelper.getEnvironmentPropertyContext(ENVIRONMENT_PROPERTY, DEPLOYMENT_PROPERTIES);
      PropertyManager propertyManager = PropertyFactory.getManager(propertyContext);
      properties = propertyManager.getProperties();
    } catch (Exception e) {
      throw new ServerCisException("Failed to set properties by environment", e);
    }
  }

  /**
   * Set properties by classpath.
   * @throws ServerCisException
   * @author Michael Cronk
   */
  private void setPropertiesByClasspath() throws ServerCisException {
    try {
      String deploymentResource = new String(CLASSPATH_DEPLOYMENT_PREFIX + ServerManager.getCisEnvironment() + CLASSPATH_DEPLOYMENT_SUFFIX);
      PropertyContext propertyContext = PropertyHelper.getClasspathPropertyContext(deploymentResource, DEPLOYMENT_PROPERTIES);
      PropertyManager propertyManager = PropertyFactory.getManager(propertyContext);
      properties = propertyManager.getProperties();
    } catch (Exception e) {
      throw new ServerCisException("Failed to set properties by classpath", e);
    }
  }

  // ---------------------------------------------------------------------- //
  //                             S E S S I O N                              //
  // ---------------------------------------------------------------------- //

  // Private constants
  private static final String SESSION_PROPERTIES = HELPER_PROPERTIES + "session.";

  // Private attributes
  private SessionManager session = null;
  private java.util.Date sessionLoaded = null;

  /**
   * Get session.
   * @return SessionManager
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public SessionManager getSession() throws ServerCisException {
    SessionManager result = null;
    getReadLock();
    try {
      if ((session == null) || (sessionLoaded == null) || (sessionLoaded.equals(propertiesLoaded) == false)) {
        upgradeReadToWriteLock();
        try {
          if ((session == null) || (sessionLoaded == null) || (sessionLoaded.equals(propertiesLoaded) == false)) {
            session = new SessionManager(PropertiesUtility.extractProperties(getProperties(), SESSION_PROPERTIES));
            sessionLoaded = propertiesLoaded;
          }
        } finally {
          downgradeWriteToReadLock();
        }
      }
      result = session;
    } finally {
      releaseReadLock();
    }
    return result;
  }

  // ---------------------------------------------------------------------- //
  //                            B U S I N E S S                             //
  // ---------------------------------------------------------------------- //

  /**
   * Get business.
   * @return BusinessManager
   * @throws ServerCisException
   * @author Michael Cronk
   */
  public BusinessManager getBusiness() throws ServerCisException {
    return ServerManager.getBusiness();
  }

}
