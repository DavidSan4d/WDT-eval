package com.fedex.cis.audit.service.rs;

@javax.xml.bind.annotation.XmlRootElement(name="error")
public class RsError {

  private String message = null;
  public String getMessage() { return message; }
  public void setMessage(String value) { message = value; }

  private boolean business = false;
  public boolean isBusiness() { return business; }
  public void setBusiness(boolean value) { business = value; }

}
