package com.fedex.cis.audit.service.session;

/**
 * This standalone example application authorizes the principal identified with
 * a JSON Web Token (JWT) token issued by a trusted service.  In test
 * environments, the principal must also have the TEST role for the domain.  In
 * the event authorization fails, the service should return a proper HTTP 403
 * Forbidden response.
 * 
 * -- Dependencies --
 * 
 * JRE 8 or higher
 *  
 * @author Michael Cronk
 */

public class AuthzHelper {

  public static void main(String[] args) {
    try {

      // Configure properties
      java.util.Properties properties = new java.util.Properties();
      properties.put("test", "true");
      // Roles cache
      //properties.put("url", "http://127.0.0.1:2001/authz/rs");
      properties.put("url", "http://cis-services-l1.ute.fedex.com:7001/authz/rs");
      //properties.put("url", "http://cis-services-l2.ute.fedex.com:7001/authz/rs");
      properties.put("capacity", "5000");
      properties.put("expire", "15"); // 15 minutes
      properties.put("preload", true);

      // Get helper
      AuthzHelper helper = new AuthzHelper(properties);

      // Download test access token from CisAuthn service and blindly parse JWT from token
      String token = helper.downloadContent("http://cis-services-l1.ute.fedex.com:7001/authn/rs/o2b/token/access/test", "application/jwt");
      com.nimbusds.jwt.JWT jwt = com.nimbusds.jwt.JWTParser.parse(token);
      String principal = jwt.getJWTClaimsSet().getSubject();

      // Get roles
      String domain = "CISAUTHZC2B";
      java.util.Set<String> roles = helper.getRoles(principal, domain, token);
      helper.backup();

      //
      // Now the roles can be used to authorize session principal
      //

      System.out.println(roles);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // Private attributes
  private final boolean test;
  private final AuthzRoleCache roleCache;

  /**
   * Construct helper.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public AuthzHelper(java.util.Properties properties) {
    this(properties, new AuthzRoleCache(properties));
  }

  /**
   * Construct helper.
   * @param properties java.util.Properties
   * @param roleCache AuthzRoleCache
   * @author Michael Cronk
   */
  public AuthzHelper(java.util.Properties properties, AuthzRoleCache roleCache) {
    test = Boolean.valueOf(properties.getProperty("test"));
    // Set caches
    this.roleCache = roleCache;
  }

  /**
   * Backup.
   * 
   * NOTE: Should only be invoked through an asynchronous mechanism!
   * 
   * @throws Exception
   * @author Michael Cronk
   */
  public void backup() throws Exception {
    try {
      roleCache.backup();
    } catch (Exception e) {
      throw new Exception("Failed to backup", e);
    }
  }

  /**
   * Get roles.
   * @param principal String
   * @param domain String
   * @param token String
   * @return java.util.Set<String>
   * @throws AuthzException
   * @author Michael Cronk
   */
  public java.util.Set<String> getRoles(String principal, String domain, String token) throws AuthzException {
    java.util.Set<String> result = null;
    try {

      //
      // STEP 1: Get roles
      //
      result = roleCache.getRoles(principal, domain, token);

      //
      // STEP 2: (Optional) Verify principal is a tester (has TEST role)
      //

      // Is test principal?
      if (test) {
        boolean allowed = (result != null) && result.contains("TEST");
        if (allowed == false) { throw new AuthzException("Principal not a tester"); }
      }

    } catch (Exception e) {
      throw new AuthzException("Failed to get roles", e);
    }
    return result;
  }

  //
  // Helper methods
  //

  protected String downloadContent(String url, String accept) throws Exception {
    String result = null;
    java.net.HttpURLConnection connection = null;
    java.io.InputStreamReader streamReader = null;
    java.io.BufferedReader bufferedReader = null;
    try {
      connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", accept);
      connection.setConnectTimeout(5000); //  5 seconds to connect
      connection.setReadTimeout(10000);   // 10 seconds to wait for response
      int responseCode = connection.getResponseCode();
      if (responseCode == 200) {
        streamReader = new java.io.InputStreamReader(connection.getInputStream());
        bufferedReader = new java.io.BufferedReader(streamReader);
        String line;
        StringBuilder content = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null) {
          content.append(line);
        }
        result = content.toString();
      } else if (responseCode == 204) {
        // Intentionally does nothing!
      } else {
        throw new Exception("Unexpected HTTP response code: " + responseCode + ": " + connection.getResponseMessage());
      };
    } catch (Exception e) {
      throw new Exception("Failed to download content", e);
    } finally {
      if (bufferedReader != null) { try { bufferedReader.close(); } catch (Exception e) {} }
      if (streamReader != null) { try { streamReader.close(); } catch (Exception e) {} }
      if (connection != null) { try { connection.disconnect(); } catch (Exception e) {} }
    }
    return result;
  }

}
