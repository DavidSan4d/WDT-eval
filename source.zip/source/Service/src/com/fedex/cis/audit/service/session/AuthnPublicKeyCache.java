package com.fedex.cis.audit.service.session;

/**
 * This cache stores public keys for trusted access token issuers, with the
 * intent to be leveraged by a request filter for token verification prior to
 * processing the request.  In order to improve efficiency, each public key
 * utilized by the issuer are cached until they are considered expired.  For
 * robustness, the last known state (if known) is utilized in the event the
 * authentication service is unavailable; hence, a delay equivalent to the
 * expiration minutes is applied before attempting another refresh with the
 * service for that issuer public key.
 * 
 * This helper is considered thread-safe and is intended to be integrated as a
 * singleton class.
 * 
 * -- Backups --
 * 
 * To further enhance robustness, an asynchronous mechanism can periodically
 * invoke the backup() method to persist the cache.  When the helper is
 * instantiated, it can optionally preload the cache.  Consequently, if the
 * authentication service is unavailable, any token signed with a backed up
 * issuer public key can still access the protected service.  Both the preload()
 * and backup() methods do nothing by default, left to the protected service to
 * optionally implement.
 * 
 * -- Dependencies --
 * 
 * JRE 8 or higher.
 *
 *  -- Notes --
 * 
 * In order to get a valid issuer and public key identifier, a test token is
 * simply downloaded from the CisAuthn service.  Normally, the token itself
 * would be verified, but it is blindly parsed for the purposes of testing this
 * cache.
 * 
 * @author Michael Cronk
 */

public class AuthnPublicKeyCache {

  public static void main(String[] args) {
    try {

      // Configure properties
      java.util.Properties properties = new java.util.Properties();
      properties.put("issuer.cis-authn-ll", "http://127.0.0.1:2001/authn/rs");
      properties.put("issuer.cis-authn-474768", "http://199.81.168.132:2001/authn/rs");
      properties.put("issuer.cis-authn-l1", "http://cis-services-l1.ute.fedex.com:7001/authn/rs");
      properties.put("issuer.cis-authn-l2", "http://cis-services-l2.ute.fedex.com:7001/authn/rs");
      properties.put("capacity", "10");
      properties.put("expire", "720"); // 720 minutes or 12 hours
      properties.put("preload", true);

      // Get cache
      AuthnPublicKeyCache cache = new AuthnPublicKeyCache(properties);

      // Download test access token from CisAuthn service and blindly parse JWT from token
      String token = cache.downloadContent("http://cis-services-l1.ute.fedex.com:7001/authn/rs/o2b/token/access/test", "application/jwt");
      com.nimbusds.jwt.JWT jwt = com.nimbusds.jwt.JWTParser.parse(token);
      String issuer = jwt.getJWTClaimsSet().getIssuer();
      String kid = jwt.getJWTClaimsSet().getStringClaim("kid");

      // Get public key
      java.security.interfaces.RSAPublicKey publicKey = cache.getPublicKey(issuer, kid);
      publicKey = cache.getPublicKey(issuer, kid);
      cache.backup();

      //
      // The public key can now be used to verify the token signature
      //

      System.out.println(publicKey);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // Private attributes
  private final java.util.concurrent.locks.ReentrantReadWriteLock readWriteLock;
  private final java.util.concurrent.locks.Lock readLock;
  private final java.util.concurrent.locks.Lock writeLock;

  private final java.util.Map<String, String> issuers;
  private final int capacity;
  private final int expire;
  private final boolean preload;
  private final Cache cache;

  private void getReadLock() { readLock.lock(); }
  private void releaseReadLock() { readLock.unlock(); }
  private void upgradeReadToWriteLock() { readLock.unlock(); writeLock.lock(); }
  private void downgradeWriteToReadLock() { readLock.lock(); writeLock.unlock(); }

  /**
   * Construct cache.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public AuthnPublicKeyCache(java.util.Properties properties) {
    readWriteLock = new java.util.concurrent.locks.ReentrantReadWriteLock(true);
    readLock = readWriteLock.readLock();
    writeLock = readWriteLock.writeLock();
    // Set issuers formatted as "issuer.<ISSUER>=<URL>"
    issuers = new java.util.HashMap<String, String>();
    for (String propertyName : properties.stringPropertyNames()) {
      if (propertyName.startsWith("issuer.")) {
        issuers.put(propertyName.substring("issuer.".length()), properties.getProperty(propertyName));
      }
    }
    capacity = Integer.valueOf(properties.getProperty("capacity"));
    expire = Integer.valueOf(properties.getProperty("expire")); // Minutes
    preload = Boolean.valueOf(properties.getProperty("preload"));
    cache = new Cache(capacity);
    if (preload) { try { preload(); } catch (Exception e) { throw new RuntimeException(e); } }
  }

  /**
   * Preload from backup.
   * 
   * NOTE: Should only be invoked from constructor!
   * 
   * @throws Exception
   * @author Michael Cronk
   */
  private void preload() throws Exception {

    // Fetch backup
    java.util.Map<CacheKey, java.security.interfaces.RSAPublicKey> backup = new java.util.HashMap<CacheKey, java.security.interfaces.RSAPublicKey>();
    try {

      //
      // INSERT CODE TO FETCH FROM BACKUP
      //

    } catch (Exception e) {
      throw new Exception("Failed to preload from backup", e);
    }

    // Preload
    if (backup.size() > 0) {
      for (CacheKey cacheKey : backup.keySet()) {
        cache.put(cacheKey, new CacheValue(backup.get(cacheKey)));
      }
    }

  }

  /**
   * Backup.
   * 
   * NOTE: Should only be invoked through an asynchronous mechanism!
   * 
   * @throws Exception
   * @author Michael Cronk
   */
  public void backup() throws Exception {

    // Extract backup quickly in order to minimize cache performance impact
    java.util.Map<CacheKey, java.security.interfaces.RSAPublicKey> backup = new java.util.HashMap<CacheKey, java.security.interfaces.RSAPublicKey>();
    getReadLock();
    try {
      for (CacheKey cacheKey : cache.keySet()) {
        backup.put(cacheKey, cache.get(cacheKey).getPublicKey());
      }
    } finally {
      releaseReadLock();
    }

    // Backup
    if (backup.size() > 0) {
      try {

        //
        // INSERT CODE TO BACKUP
        //

      } catch (Exception e) {
        throw new Exception("Failed to backup", e);
      }
    }

  }

  /**
   * Get public key from issuer.
   * @param issuer String
   * @param kid String
   * @return java.security.interfaces.RSAPublicKey
   * @throws Exception
   * @author Michael Cronk
   */
  public java.security.interfaces.RSAPublicKey getPublicKey(String issuer, String kid) throws Exception {
    java.security.interfaces.RSAPublicKey result = null;
    getReadLock();
    try {
      CacheKey cacheKey = new CacheKey(issuer, kid);
      CacheValue cacheValue = cache.get(cacheKey);
      if ((cacheValue == null) || cacheValue.hasExpired(expire)) {
        // Fetch but do not block, capturing any exceptions
        java.security.interfaces.RSAPublicKey fetchedValue = null;
        Exception caughtException = null;
        try {
          fetchedValue = fetchValue(issuer, kid);
        } catch (Exception e) {
          caughtException = e;
        }
        // Update cache
        upgradeReadToWriteLock();
        try {
          CacheValue postCacheValue = cache.get(cacheKey);
          if ((postCacheValue == null) || postCacheValue.hasExpired(expire)) {
            if (caughtException == null) {
              // Update
              cacheValue = new CacheValue(fetchedValue);
              cache.put(cacheKey, cacheValue);
            } else if (cacheValue != null) {
              // Use last known state
              cacheValue = new CacheValue(cacheValue.getPublicKey());
              cache.remove(cacheKey); // Otherwise insertion order is not affected!
              cache.put(cacheKey, cacheValue);
            } else {
              // Out of options
              throw caughtException;
            }
          } else {
            // Another thread already refreshed the cache
            cacheValue = postCacheValue;
          }
        } finally {
          downgradeWriteToReadLock();
        }
      }
      result = cacheValue.getPublicKey();
    } catch (Exception e) {
      throw new Exception("Failed to get public key \"" + kid + "\" from issuer \"" + issuer + "\"", e);
    } finally {
      releaseReadLock();
    }
    return result;
  }

  //
  // Helper classes
  //

  private class CacheKey {

    private final String issuer;
    private final String kid;

    public CacheKey(String issuer, String kid) {
      this.issuer = issuer;
      this.kid = kid;
    }

    private AuthnPublicKeyCache getOuterType() {
      return AuthnPublicKeyCache.this;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      CacheKey other = (CacheKey) obj;
      if (!getOuterType().equals(other.getOuterType()))
        return false;
      if (issuer == null) {
        if (other.issuer != null)
          return false;
      } else if (!issuer.equals(other.issuer))
        return false;
      if (kid == null) {
        if (other.kid != null)
          return false;
      } else if (!kid.equals(other.kid))
        return false;
      return true;
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + getOuterType().hashCode();
      result = prime * result + ((issuer == null) ? 0 : issuer.hashCode());
      result = prime * result + ((kid == null) ? 0 : kid.hashCode());
      return result;
    }

    @Override
    public String toString() {
      return "CacheKey [issuer=" + issuer + ", kid=" + kid + "]";
    }

  }

  private class CacheValue {

    private final java.util.Date modified;
    private final java.security.interfaces.RSAPublicKey publicKey;

    public CacheValue(java.security.interfaces.RSAPublicKey publicKey) {
      modified = new java.util.Date();
      this.publicKey = publicKey;
    }

    public java.security.interfaces.RSAPublicKey getPublicKey() { return publicKey; }

    public boolean hasExpired(int minutes) {
      boolean result = false;
      long sinceLastModified = new java.util.Date().getTime() - modified.getTime();
      if (sinceLastModified >= (minutes * 60 * 1000)) { result = true; }
      return result;
    }

  }

  private class Cache extends java.util.LinkedHashMap<CacheKey, CacheValue> {

    private static final long serialVersionUID = 1L;

    public Cache(int capacity) {
      super(capacity);
      // Ensure to create using insertion-ordered as opposed to access-ordered
      // linked hash map.  Otherwise, every query would be a structural
      // modification that would require synchronization even when the map is
      // merely queried.
    }

    @Override
    protected boolean removeEldestEntry(java.util.Map.Entry<CacheKey, CacheValue> eldest) {
      return size() > capacity;
    }

  }

  //
  // Helper methods
  //

  private java.security.interfaces.RSAPublicKey fetchValue(String issuer, String kid) throws Exception {
    java.security.interfaces.RSAPublicKey result = null;
    try {
      String pkcs8Key = downloadContent(issuers.get(issuer) + "/o2b/key/public/" + kid, "application/pkcs8");
      // Convert PKCS#8 formatted key to binary DER
      //  - Strip header, footer and whitespace formatting
      //  - Base64 decode
      pkcs8Key = pkcs8Key.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "").replaceAll("\\s", "");
      byte[] derKey = java.util.Base64.getDecoder().decode(pkcs8Key);
      java.security.KeyFactory keyFactory = java.security.KeyFactory.getInstance("RSA");
      result = (java.security.interfaces.RSAPublicKey) keyFactory.generatePublic(new java.security.spec.X509EncodedKeySpec(derKey));
    } catch (Exception e) {
      throw new Exception ("Failed to fetch value", e);
    }
    return result;
  }

  private String downloadContent(String url, String accept) throws Exception {
    String result = null;
    java.net.HttpURLConnection connection = null;
    java.io.InputStreamReader streamReader = null;
    java.io.BufferedReader bufferedReader = null;
    try {
      connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", accept);
      connection.setConnectTimeout(5000); //  5 seconds to connect
      connection.setReadTimeout(10000);   // 10 seconds to wait for response
      int responseCode = connection.getResponseCode();
      if (responseCode == 200) {
        streamReader = new java.io.InputStreamReader(connection.getInputStream());
        bufferedReader = new java.io.BufferedReader(streamReader);
        String line;
        StringBuilder content = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null) {
          content.append(line);
        }
        result = content.toString();
      } else if (responseCode == 204) {
        // Intentionally does nothing!
      } else {
        throw new Exception("Unexpected HTTP response code: " + responseCode + ": " + connection.getResponseMessage());
      }
    } catch (Exception e) {
      throw new Exception("Failed to download content", e);
    } finally {
      if (bufferedReader != null) { try { bufferedReader.close(); } catch (Exception e) {} }
      if (streamReader != null) { try { streamReader.close(); } catch (Exception e) {} }
      if (connection != null) { try { connection.disconnect(); } catch (Exception e) {} }
    }
    return result;
  }

}
