package com.fedex.cis.audit.service.rs;

/**
 * RESTful web services (RS) application resource configuration.
 * @author Michael Cronk
 */

@javax.ws.rs.ApplicationPath("rs")
public class RsApplication extends org.glassfish.jersey.server.ResourceConfig {

  public RsApplication(@javax.ws.rs.core.Context javax.servlet.ServletConfig servletConfig) {
    packages(this.getClass().getPackage().getName());
    register(org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature.class);

    // Swagger 1.5.x (/audit/rs/swagger.json or /audit/rs/swagger.yaml)
    java.util.Set<Class<?>> swaggerClasses = new java.util.HashSet<Class<?>>();
    swaggerClasses.add(io.swagger.jaxrs.listing.ApiListingResource.class);
    swaggerClasses.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);
    registerClasses(swaggerClasses);
    io.swagger.jaxrs.config.BeanConfig beanConfig = new io.swagger.jaxrs.config.BeanConfig();
    beanConfig.setTitle("Crew Information Systems Audit Service");
    //beanConfig.setVersion("1.1"); Needs to be injected from build environment!
    beanConfig.setSchemes(new String[]{"http"});
    beanConfig.setBasePath("/audit/rs");
    beanConfig.setResourcePackage("com.fedex.cis.audit.service.rs");
    beanConfig.setScan(true);
    beanConfig.setPrettyPrint(true);
    // Set Swagger security definitions
    io.swagger.models.Swagger swagger = new io.swagger.models.Swagger();
    swagger.securityDefinition("jwt_token", new io.swagger.models.auth.ApiKeyAuthDefinition("Authorization", io.swagger.models.auth.In.HEADER));
    new io.swagger.jaxrs.config.SwaggerContextService().updateSwagger(swagger);

    // Swagger 2.x (/audit/rs/openapi.json or /audit/rs/openapi.yaml)
    //  - Currently can't get to work in WebLogic 12.1.3!
    //packages("io.swagger.v3.jaxrs2.integration.resources", this.getClass().getPackage().getName()); 
    //io.swagger.v3.oas.models.info.Info info = new io.swagger.v3.oas.models.info.Info()
    //.title("Crew Information Systems Audit Service");
    //io.swagger.v3.oas.models.security.SecurityScheme securityScheme = new io.swagger.v3.oas.models.security.SecurityScheme()
    //.name("Authorization")
    //.type(io.swagger.v3.oas.models.security.SecurityScheme.Type.APIKEY)
    //.in(io.swagger.v3.oas.models.security.SecurityScheme.In.HEADER)
    //.bearerFormat("JWT");
    //io.swagger.v3.oas.models.OpenAPI oas = new io.swagger.v3.oas.models.OpenAPI()
    //.info(info)
    //.schemaRequirement("jwt-token", securityScheme);
    //io.swagger.v3.oas.integration.SwaggerConfiguration oasConfig = new io.swagger.v3.oas.integration.SwaggerConfiguration()
    //.openAPI(oas)
    //.prettyPrint(true)
    //.resourcePackages(java.util.stream.Stream.of("com.fedex.cis.audit.service.rs").collect(java.util.stream.Collectors.toSet()));
    //try {
    //  new io.swagger.v3.jaxrs2.integration.JaxrsOpenApiContextBuilder()
    //  .servletConfig(servletConfig)
    //  .application(this)
    //  .openApiConfiguration(oasConfig)
    //  .buildContext(true);
    //} catch (io.swagger.v3.oas.integration.OpenApiConfigurationException e) {
    //  throw new RuntimeException(e.getMessage(), e);
    //}

    // Uncomment to view web service requests/responses on STDOUT
    //register(new org.glassfish.jersey.logging.LoggingFeature(java.util.logging.Logger.getLogger(
    //    org.glassfish.jersey.logging.LoggingFeature.DEFAULT_LOGGER_NAME),
    //    java.util.logging.Level.INFO,
    //    org.glassfish.jersey.logging.LoggingFeature.Verbosity.PAYLOAD_ANY,
    //    10000));
  }

}
