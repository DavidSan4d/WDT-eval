package com.fedex.cis.audit.service.session;

/**
 * This cache gets permissions from the authorization service, with the intent
 * to be leveraged by the security context as roles.  In order to improve
 * efficiency, the roles are cached for each domain principal until they are
 * considered expired.  For robustness, the last known state (if known) is
 * utilized in the event the authorization service is unavailable; hence, a
 * delay equivalent to the expiration minutes is applied before attempting
 * another refresh with the service for that principal.
 * 
 * This helper is considered thread-safe and is intended to be integrated as a
 * singleton class.
 * 
 * -- Backups --
 * 
 * To further enhance robustness, an asynchronous mechanism can periodically
 * invoke the backup() method to persist roles.  When the helper is
 * instantiated, it can optionally preload the roles.  Consequently, if the
 * authorization service is unavailable, any principal with backed up roles can
 * still access the protected service.  Both the preload() and backup() methods
 * do nothing by default, left to the protected service to optionally implement.
 * 
 * -- Dependencies --
 * 
 * JRE 8 or higher.
 *
 *  -- Testing --
 * 
 * In this example, a test token is simply downloaded from the CisAuthn service.
 * Normally, the token itself would have already been verified earlier in the
 * request filter phase, with the session principal and authorization domain
 * being extracted.
 * 
 * @author Michael Cronk
 */

public class AuthzRoleCache {

  public static void main(String[] args) {
    try {

      // Configure properties
      java.util.Properties properties = new java.util.Properties();
      //properties.put("url", "http://127.0.0.1:2001/authz/rs");
      properties.put("url", "http://cis-services-l1.ute.fedex.com:7001/authz/rs");
      //properties.put("url", "http://cis-services-l2.ute.fedex.com:7001/authz/rs");
      properties.put("capacity", "5000");
      properties.put("expire", "15"); // 15 minutes
      properties.put("preload", true);

      // Get cache
      AuthzRoleCache cache = new AuthzRoleCache(properties);

      // Download test access token from CisAuthn service and blindly parse JWT from token
      String token = cache.downloadContent("http://cis-services-l1.ute.fedex.com:7001/authn/rs/o2b/token/access/test", "application/jwt", null);
      com.nimbusds.jwt.JWT jwt = com.nimbusds.jwt.JWTParser.parse(token);
      String principal = jwt.getJWTClaimsSet().getSubject();

      // Get roles
      String domain = "CISAUTHZC2B";
      java.util.Set<String> roles = cache.getRoles(principal, domain, token);
      cache.backup();

      //
      // Now the roles can be used to authorize session principal
      //

      System.out.println(roles);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // Private attributes
  private final java.util.concurrent.locks.ReentrantReadWriteLock readWriteLock;
  private final java.util.concurrent.locks.Lock readLock;
  private final java.util.concurrent.locks.Lock writeLock;

  private final String url;
  private final int capacity;
  private final int expire;
  private final boolean preload;
  private final Cache cache;
  private final javax.xml.bind.JAXBContext jaxbContext;

  private void getReadLock() { readLock.lock(); }
  private void releaseReadLock() { readLock.unlock(); }
  private void upgradeReadToWriteLock() { readLock.unlock(); writeLock.lock(); }
  private void downgradeWriteToReadLock() { readLock.lock(); writeLock.unlock(); }

  /**
   * Construct cache.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public AuthzRoleCache(java.util.Properties properties) {
    readWriteLock = new java.util.concurrent.locks.ReentrantReadWriteLock(true);
    readLock = readWriteLock.readLock();
    writeLock = readWriteLock.writeLock();
    url = properties.getProperty("url");
    capacity = Integer.valueOf(properties.getProperty("capacity"));
    expire = Integer.valueOf(properties.getProperty("expire")); // Minutes
    preload = Boolean.valueOf(properties.getProperty("preload"));
    cache = new Cache(capacity);
    if (preload) { try { preload(); } catch (Exception e) { throw new RuntimeException(e); } }
    try { jaxbContext = javax.xml.bind.JAXBContext.newInstance(Authorization.class); } catch (Exception e) { throw new RuntimeException(e); }
  }

  /**
   * Preload from backup.
   * 
   * NOTE: Should only be invoked from constructor!
   * 
   * @throws Exception
   * @author Michael Cronk
   */
  private void preload() throws Exception {

    // Fetch backup
    java.util.Map<CacheKey, java.util.Set<String>> backup = new java.util.HashMap<CacheKey, java.util.Set<String>>();
    try {

      //
      // INSERT CODE TO FETCH FROM BACKUP
      //

    } catch (Exception e) {
      throw new Exception("Failed to preload from backup", e);
    }

    // Preload
    if (backup.size() > 0) {
      for (CacheKey cacheKey : backup.keySet()) {
        cache.put(cacheKey, new CacheValue(backup.get(cacheKey)));
      }
    }

  }

  /**
   * Backup.
   * 
   * NOTE: Should only be invoked through an asynchronous mechanism!
   * 
   * @throws Exception
   * @author Michael Cronk
   */
  public void backup() throws Exception {

    // Extract backup quickly in order to minimize cache performance impact
    java.util.Map<CacheKey, java.util.Set<String>> backup = new java.util.HashMap<CacheKey, java.util.Set<String>>();
    getReadLock();
    try {
      for (CacheKey cacheKey : cache.keySet()) {
        backup.put(cacheKey, cache.get(cacheKey).getRoles());
      }
    } finally {
      releaseReadLock();
    }

    // Backup
    if (backup.size() > 0) {
      try {

        //
        // INSERT CODE TO BACKUP
        //

      } catch (Exception e) {
        throw new Exception("Failed to backup", e);
      }
    }

  }

  /**
   * Get roles.
   * @param principal String
   * @param domain String
   * @param token String
   * @return java.util.Set<String>
   * @throws Exception
   * @author Michael Cronk
   */
  public java.util.Set<String> getRoles(String principal, String domain, String token) throws Exception {
    java.util.Set<String> result = null;
    getReadLock();
    try {
      CacheKey cacheKey = new CacheKey(principal, domain);
      CacheValue cacheValue = cache.get(cacheKey);
      if ((cacheValue == null) || cacheValue.hasExpired(expire)) {
        // Fetch but do not block, capturing any exceptions
        java.util.Set<String> fetchedValue = null;
        Exception caughtException = null;
        try {
          fetchedValue = fetchValue(principal, domain, token);
        } catch (Exception e) {
          caughtException = e;
        }
        // Update cache
        upgradeReadToWriteLock();
        try {
          CacheValue postCacheValue = cache.get(cacheKey);
          if ((postCacheValue == null) || postCacheValue.hasExpired(expire)) {
            if (caughtException == null) {
              // Update
              cacheValue = new CacheValue(fetchedValue);
              cache.put(cacheKey, cacheValue);
            } else if (cacheValue != null) {
              // Use last known state
              cacheValue = new CacheValue(cacheValue.getRoles());
              cache.remove(cacheKey); // Otherwise insertion order is not affected!
              cache.put(cacheKey, cacheValue);
            } else {
              // Out of options
              throw caughtException;
            }
          } else {
            // Another thread already refreshed the cache
            cacheValue = postCacheValue;
          }
        } finally {
          downgradeWriteToReadLock();
        }
      }
      result = cacheValue.getRoles();
    } catch (Exception e) {
      throw new Exception("Failed to get roles for principal in domain: " + principal + "/" + domain, e);
    } finally {
      releaseReadLock();
    }
    return result;
  }

  //
  // Helper classes
  //

  private class CacheKey {

    private final String principal;
    private final String domain;

    public CacheKey(String principal, String domain) {
      this.principal = principal;
      this.domain = domain;
    }

    private AuthzRoleCache getOuterType() {
      return AuthzRoleCache.this;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      CacheKey other = (CacheKey) obj;
      if (!getOuterType().equals(other.getOuterType()))
        return false;
      if (principal == null) {
        if (other.principal != null)
          return false;
      } else if (!principal.equals(other.principal))
        return false;
      if (domain == null) {
        if (other.domain != null)
          return false;
      } else if (!domain.equals(other.domain))
        return false;
      return true;
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + getOuterType().hashCode();
      result = prime * result + ((principal == null) ? 0 : principal.hashCode());
      result = prime * result + ((domain == null) ? 0 : domain.hashCode());
      return result;
    }

    @Override
    public String toString() {
      return "CacheKey [principal=" + principal + ", domain=" + domain + "]";
    }

  }

  private class CacheValue {

    private final java.util.Date modified;
    private final java.util.Set<String> roles;

    public CacheValue(java.util.Set<String> roles) {
      modified = new java.util.Date();
      this.roles = roles;
    }

    public java.util.Set<String> getRoles() { return roles; }

    public boolean hasExpired(int minutes) {
      boolean result = false;
      long sinceLastModified = new java.util.Date().getTime() - modified.getTime();
      if (sinceLastModified >= (minutes * 60 * 1000)) { result = true; }
      return result;
    }

  }

  private class Cache extends java.util.LinkedHashMap<CacheKey, CacheValue> {

    private static final long serialVersionUID = 1L;

    public Cache(int capacity) {
      super(capacity);
      // Ensure to create using insertion-ordered as opposed to access-ordered
      // linked hash map.  Otherwise, every query would be a structural
      // modification that would require synchronization even when the map is
      // merely queried.
    }

    @Override
    protected boolean removeEldestEntry(java.util.Map.Entry<CacheKey, CacheValue> eldest) {
      return size() > capacity;
    }

  }

  //
  // Helper methods
  //

  protected java.util.Set<String> fetchValue(String principal, String domain, String token) throws Exception {
    java.util.Set<String> result = null;
    java.io.StringReader reader = null;
    try {
      String xml = downloadContent(url+"/a2b/authorization/"+domain, "application/xml", token);
      if (xml != null) {
        reader = new java.io.StringReader(xml);
        javax.xml.bind.Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
        Authorization authorization = (Authorization) jaxbUnmarshaller.unmarshal(reader);
        if ((authorization != null) && (authorization.getPermissions() != null)) {
          result = new java.util.HashSet<String>(authorization.getPermissions());
        }
      }
    } catch (Exception e) {
      throw new Exception("Failed to fetch value", e);
    } finally {
      if (reader != null) { reader.close(); }
    }
    return result;
  }

  private String downloadContent(String url, String accept, String token) throws Exception {
    String result = null;
    java.net.HttpURLConnection connection = null;
    java.io.InputStreamReader streamReader = null;
    java.io.BufferedReader bufferedReader = null;
    try {
      connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", accept);
      if (token != null) { connection.setRequestProperty("Authorization", "Bearer " + token); }
      connection.setConnectTimeout(5000); //  5 seconds to connect
      connection.setReadTimeout(10000);   // 10 seconds to wait for response
      int responseCode = connection.getResponseCode();
      if (responseCode == 200) {
        streamReader = new java.io.InputStreamReader(connection.getInputStream());
        bufferedReader = new java.io.BufferedReader(streamReader);
        String line;
        StringBuilder content = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null) {
          content.append(line);
        }
        result = content.toString();
      } else if (responseCode == 204) {
        // Intentionally does nothing!
      } else {
        throw new Exception("Unexpected HTTP response code: " + responseCode + ": " + connection.getResponseMessage());
      }
    } catch (Exception e) {
      throw new Exception("Failed to download content", e);
    } finally {
      if (bufferedReader != null) { try { bufferedReader.close(); } catch (Exception e) {} }
      if (streamReader != null) { try { streamReader.close(); } catch (Exception e) {} }
      if (connection != null) { try { connection.disconnect(); } catch (Exception e) {} }
    }
    return result;
  }

}
