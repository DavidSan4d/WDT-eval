package com.fedex.cis.audit.service.session;

/**
 * Session manager.
 * @author Michael Cronk
 */

import fedex.cis.common.exception.CisException;
import fedex.cis.common.util.PropertiesUtility;

public class SessionManager {

  // Public constants
  public static final String DOMAIN = "CISAUDIT";

  // Private attributes
  private final AuthnHelper authnHelper;
  private final AuthzHelper authzHelper;

  /**
   * Construct session manager.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public SessionManager(java.util.Properties properties) {
    authnHelper = new AuthnHelper(PropertiesUtility.extractProperties(properties, "authn."));
    authzHelper = new AuthzHelper(PropertiesUtility.extractProperties(properties, "authz."));
  }

  /**
   * Get session principal.
   * @param token String
   * @param audience String
   * @param domainName String
   * @return SessionPrincipal
   * @throws Exception
   */
  public SessionPrincipal getPrincipal(
      String token,
      String audience,
      String domainName)
          throws Exception {
    SessionPrincipal result = null;
    try {
      com.nimbusds.jwt.SignedJWT jwt = authnHelper.verify(token, java.util.Arrays.asList(audience.toUpperCase()));
      String subject = jwt.getJWTClaimsSet().getSubject();
      java.util.Set<String> roles = (domainName != null) ? authzHelper.getRoles(subject, domainName, token) : null;
      boolean trusted = jwt.getJWTClaimsSet().getBooleanClaim("tru");
      result = new SessionPrincipal(subject, domainName, roles, trusted);
    } catch (AuthnException e) {
      throw e;
    } catch (AuthzException e) {
      throw e;
    } catch (Exception e) {
      throw new CisException("Failed to get principal", e);
    }
    return result;
  }

}
