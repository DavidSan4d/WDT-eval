package com.fedex.cis.audit.service.rs;

/**
 * RESTful web services (RS) security context.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.service.session.SessionPrincipal;

public class RsSecurityContext implements javax.ws.rs.core.SecurityContext {

  // Private attributes
  private final SessionPrincipal principal;
  private final String scheme;
  private final boolean secure;

  /**
   * Construct security context.
   * @param principal SessionPrincipal
   * @param scheme String
   * @param secure boolean
   * @author Michael Cronk
   */
  public RsSecurityContext(SessionPrincipal principal, String scheme, boolean secure) {
    this.principal = principal;
    this.scheme = scheme;
    this.secure = secure;
  }

  /**
   * Returns a java.security.Principal object containing the name of the current authenticated user.
   * @return java.security.Principal
   * @author Michael Cronk
   */
  @Override
  public java.security.Principal getUserPrincipal() {
    return principal;
  }

  /**
   * Returns the string value of the authentication scheme used to protect the resource.
   * @return String
   * @author Michael Cronk
   */
  @Override
  public String getAuthenticationScheme() {
    return scheme;
  }

  /**
   * Returns a boolean indicating whether this request was made using a secure channel, such as HTTPS.
   * @return boolean
   * @author Michael Cronk
   */
  @Override
  public boolean isSecure() {
    return secure;
  }

  /**
   * Returns a boolean indicating whether the authenticated user is included in the specified logical "role".
   * @param role String
   * @return boolean
   * @author Michael Cronk
   */
  @Override
  public boolean isUserInRole(String role) {
    boolean result = false;
    if (principal.getRoles() != null) { result = principal.getRoles().contains(role); }
    return result;
  }

}
