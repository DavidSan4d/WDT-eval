package com.fedex.cis.audit.service.rs;

/**
 * Any-to-Business (A2B) RESTful web service (RS) application resource.
 * 
 * NOTE: Requires authentication without authorization!
 * 
 * @author Michael Cronk
 */


//@javax.ws.rs.Path("a2b")
public class A2bRsResource {
}
