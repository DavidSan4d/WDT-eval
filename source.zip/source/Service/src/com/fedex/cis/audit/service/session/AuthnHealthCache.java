package com.fedex.cis.audit.service.session;

/**
 * This cache stores the health status of each trusted access token issuer, with
 * the intent to be leveraged by a request filter for token verification prior
 * to processing the request.  In order to improve efficiency, the health status
 * of each issuer is cached until they are considered expired.  Any issues when
 * acquiring the status will render the issuer unhealthy.  It is recommended
 * that a minimum value of 30 and 300 seconds be configured for retesting
 * healthy and unhealthy issuers respectively.
 * 
 * This helper is considered thread-safe and is intended to be integrated as a
 * singleton class.
 * 
 * -- Dependencies --
 * 
 * JRE 8 or higher.
 *
 * @author Michael Cronk
 */

public class AuthnHealthCache {

  public static void main(String[] args) {
    try {

      // Configure properties
      java.util.Properties properties = new java.util.Properties();
      properties.put("issuer.cis-authn-ll", "http://127.0.0.1:2001/authn/rs");
      properties.put("issuer.cis-authn-474768", "http://199.81.168.132:2001/authn/rs");
      properties.put("issuer.cis-authn-l1", "http://cis-services-l1.ute.fedex.com:7001/authn/rs");
      properties.put("issuer.cis-authn-l2", "http://cis-services-l2.ute.fedex.com:7001/authn/rs");
      properties.put("capacity", "10");
      properties.put("healthy", "30");    // 30 seconds
      properties.put("unhealthy", "300"); // 300 seconds or 5 minutes

      // Get cache
      AuthnHealthCache cache = new AuthnHealthCache(properties);

      // Is issuer healthy?
      String issuer = "cis-authn-l1";
      boolean healthy = cache.isHealthy(issuer);

      //
      // The health can now be used to help verify the token
      //

      System.out.println(healthy);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // Private attributes
  private final java.util.concurrent.locks.ReentrantReadWriteLock readWriteLock;
  private final java.util.concurrent.locks.Lock readLock;
  private final java.util.concurrent.locks.Lock writeLock;

  private final java.util.Map<String, String> issuers;
  private final int capacity;
  private final int healthy;
  private final int unhealthy;
  private final Cache cache;

  private void getReadLock() { readLock.lock(); }
  private void releaseReadLock() { readLock.unlock(); }
  private void upgradeReadToWriteLock() { readLock.unlock(); writeLock.lock(); }
  private void downgradeWriteToReadLock() { readLock.lock(); writeLock.unlock(); }

  /**
   * Construct cache.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public AuthnHealthCache(java.util.Properties properties) {
    readWriteLock = new java.util.concurrent.locks.ReentrantReadWriteLock(true);
    readLock = readWriteLock.readLock();
    writeLock = readWriteLock.writeLock();
    // Set issuers formatted as "issuer.<ISSUER>=<URL>"
    issuers = new java.util.HashMap<String, String>();
    for (String propertyName : properties.stringPropertyNames()) {
      if (propertyName.startsWith("issuer.")) {
        issuers.put(propertyName.substring("issuer.".length()), properties.getProperty(propertyName));
      }
    }
    capacity = Integer.valueOf(properties.getProperty("capacity"));
    healthy = Integer.valueOf(properties.getProperty("healthy"));     // Seconds
    unhealthy = Integer.valueOf(properties.getProperty("unhealthy")); // Seconds
    cache = new Cache(capacity);
  }

  /**
   * Get issuer health.
   * @param issuer String
   * @return boolean
   * @throws Exception
   * @author Michael Cronk
   */
  public boolean isHealthy(String issuer) throws Exception {
    boolean result = false;
    getReadLock();
    try {
      CacheKey cacheKey = new CacheKey(issuer);
      CacheValue cacheValue = cache.get(cacheKey);
      int expire = ((cacheValue != null) && cacheValue.isHealthy()) ? healthy : unhealthy;
      if ((cacheValue == null) || cacheValue.hasExpired(expire)) {
        // Fetch but do not block, capturing any exceptions
        boolean fetchedValue = false;
        Exception caughtException = null;
        try {
          fetchedValue = fetchValue(issuer);
        } catch (Exception e) {
          caughtException = e;
        }
        // Update cache
        upgradeReadToWriteLock();
        try {
          CacheValue postCacheValue = cache.get(cacheKey);
          if ((postCacheValue == null) || postCacheValue.hasExpired(expire)) {
            if (caughtException == null) {
              // Update
              cacheValue = new CacheValue(fetchedValue);
              cache.put(cacheKey, cacheValue);
            } else {
              // Unhealthy
              cacheValue = new CacheValue(false);
              cache.remove(cacheKey); // Otherwise insertion order is not affected!
              cache.put(cacheKey, cacheValue);
            }
          } else {
            // Another thread already refreshed the cache
            cacheValue = postCacheValue;
          }
        } finally {
          downgradeWriteToReadLock();
        }
      }
      result = cacheValue.isHealthy();
    } catch (Exception e) {
      throw new Exception("Failed to determine if issuer is healthy: " + issuer, e);
    } finally {
      releaseReadLock();
    }
    return result;
  }

  //
  // Helper classes
  //

  private class CacheKey {

    private final String issuer;

    public CacheKey(String issuer) {
      this.issuer = issuer;
    }

    private AuthnHealthCache getOuterType() {
      return AuthnHealthCache.this;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      CacheKey other = (CacheKey) obj;
      if (!getOuterType().equals(other.getOuterType()))
        return false;
      if (issuer == null) {
        if (other.issuer != null)
          return false;
      } else if (!issuer.equals(other.issuer))
        return false;
      return true;
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + getOuterType().hashCode();
      result = prime * result + ((issuer == null) ? 0 : issuer.hashCode());
      return result;
    }

    @Override
    public String toString() {
      return "CacheKey [issuer=" + issuer + "]";
    }

  }

  private class CacheValue {

    private final java.util.Date modified;
    private final boolean healthy;

    public CacheValue(boolean healthy) {
      modified = new java.util.Date();
      this.healthy = healthy;
    }

    public boolean isHealthy() { return healthy; }

    public boolean hasExpired(int seconds) {
      boolean result = false;
      long sinceLastModified = new java.util.Date().getTime() - modified.getTime();
      if (sinceLastModified >= (seconds * 1000)) { result = true; }
      return result;
    }

  }

  private class Cache extends java.util.LinkedHashMap<CacheKey, CacheValue> {

    private static final long serialVersionUID = 1L;

    public Cache(int capacity) {
      super(capacity);
      // Ensure to create using insertion-ordered as opposed to access-ordered
      // linked hash map.  Otherwise, every query would be a structural
      // modification that would require synchronization even when the map is
      // merely queried.
    }

    @Override
    protected boolean removeEldestEntry(java.util.Map.Entry<CacheKey, CacheValue> eldest) {
      return size() > capacity;
    }

  }

  //
  // Helper methods
  //

  private boolean fetchValue(String issuer) throws Exception {
    boolean result = false;
    try {
      String xml = downloadContent(issuers.get(issuer) + "/o2b/ping", "application/xml");
      if ((xml == null) || xml.isEmpty()) { throw new Exception("Value not defined"); }
      result = true;
    } catch (Exception e) {
      throw new Exception ("Failed to fetch value", e);
    }
    return result;
  }

  private String downloadContent(String url, String accept) throws Exception {
    String result = null;
    java.net.HttpURLConnection connection = null;
    java.io.InputStreamReader streamReader = null;
    java.io.BufferedReader bufferedReader = null;
    try {
      connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", accept);
      connection.setConnectTimeout(5000); //  5 seconds to connect
      connection.setReadTimeout(10000);   // 10 seconds to wait for response
      int responseCode = connection.getResponseCode();
      if (responseCode == 200) {
        streamReader = new java.io.InputStreamReader(connection.getInputStream());
        bufferedReader = new java.io.BufferedReader(streamReader);
        String line;
        StringBuilder content = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null) {
          content.append(line);
        }
        result = content.toString();
      } else if (responseCode == 204) {
        // Intentionally does nothing!
      } else {
        throw new Exception("Unexpected HTTP response code: " + responseCode + ": " + connection.getResponseMessage());
      }
    } catch (Exception e) {
      throw new Exception("Failed to download content", e);
    } finally {
      if (bufferedReader != null) { try { bufferedReader.close(); } catch (Exception e) {} }
      if (streamReader != null) { try { streamReader.close(); } catch (Exception e) {} }
      if (connection != null) { try { connection.disconnect(); } catch (Exception e) {} }
    }
    return result;
  }

}
