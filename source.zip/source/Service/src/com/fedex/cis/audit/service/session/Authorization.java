package com.fedex.cis.audit.service.session;

@javax.xml.bind.annotation.XmlRootElement
public class Authorization {

  private String principal;
  public String getPrincipal() { return principal; }
  public void setPrincipal(String value) { principal = value; }

  private String domain;
  public String getDomain() { return domain; }
  public void setDomain(String value) { domain = value; }

  private java.util.Collection<String> permissions = null;
  public java.util.Collection<String> getPermissions() { return permissions; }
  public void setPermissions(java.util.Collection<String> value) { permissions = value; }

}
