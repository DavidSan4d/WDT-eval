package com.fedex.cis.audit.service.session;

public class AuthnException extends Exception {

  private static final long serialVersionUID = 1L;

  public AuthnException(String message) { super(message); }

  public AuthnException(String message, Throwable cause) { super(message, cause); }

}
