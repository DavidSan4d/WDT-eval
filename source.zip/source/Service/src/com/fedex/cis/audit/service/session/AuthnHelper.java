package com.fedex.cis.audit.service.session;

/**
 * This standalone example application authenticates that a JSON Web Token (JWT)
 * token with a RSA signature was issued by a trusted service.  The access token
 * is typically sent to a protected web service in the Authorization HTTP
 * request header using the Bearer schema.  For example:
 * 
 * Authorization: Bearer <token>
 * 
 * In the event authentication fails, the service should return a proper HTTP 401
 * Unauthorized response; hence, this should also include the WWW-Authenticate
 * response header.  For example:
 * 
 * WWW-Authenticate: Bearer realm="cis-authn"
 * 
 * The authentication process requires 6 steps:
 * 
 * 1. Parse token string as a signed JWT
 * 2. Verify algorithm used to sign token - RSA only!
 * 3. Verify issuer is trusted
 * 4. Verify signature
 * 5. Verify expiration (see below for leeway and offline support)
 * 6. Verify any other claims such as subject, audience and trusted
 * 
 * -- Notes --
 * 
 * 1. In the event the token has recently expired, a leeway of several minutes is
 *    supported.
 * 
 * 2. If the token has expired beyond the leeway and the helper detects that the
 *    authentication service is unhealthy, it will honor the token up to
 *    "offline" minutes beyond the expiration (usually a couple of hours);
 *    hence, clients have been instructed to resend their last known access
 *    token in the event they can't refresh it.
 * 
 * 3. If trusted authentications are only supported, the token "tru" claim must
 *    be true; hence, in unsecure environments where proper credentials are not
 *    required, such as Pilot.Fedex.Com L1/2/3 environments where the username
 *    and password are simply the employee number, the token is flagged as
 *    untrusted.  It is expected that any environment above L2 require trusted
 *    authentications only.
 * 
 * -- Dependencies --
 * 
 *  + JRE 8 or higher
 *  
 *  + JWT
 *     - nimbus-jose-jwt-5.14  To manipulate JWT access tokens
 *     - json-smart-2.3        Required by nimbus-jose-jwt
 *     - asm-1.0.2             Required by json-smart
 *
 * @author Michael Cronk
 */

public class AuthnHelper {

  public static void main(String[] args) {
    try {

      // Configure properties
      java.util.Properties properties = new java.util.Properties();
      properties.put("issuer.cis-authn-ll", "http://127.0.0.1:2001/authn/rs");
      properties.put("issuer.cis-authn-474768", "http://199.81.168.132:2001/authn/rs");
      properties.put("issuer.cis-authn-l1", "http://cis-services-l1.ute.fedex.com:7001/authn/rs");
      properties.put("issuer.cis-authn-l2", "http://cis-services-l2.ute.fedex.com:7001/authn/rs");
      properties.put("leeway", "180");    // 180 seconds or 3 minutes
      properties.put("offline", "120");   // 120 minutes or 2 hours
      properties.put("trusted", "false");
      // Public key cache
      properties.put("capacity", "10");
      properties.put("expire", "720");    // 720 minutes or 12 hours
      properties.put("preload", true);
      // Health cache
      properties.put("healthy", "30");    // 30 seconds
      properties.put("unhealthy", "300"); // 300 seconds or 5 minutes

      // Get helper
      AuthnHelper helper = new AuthnHelper(properties);

      // Download test access token from CisAuthn service
      String token = helper.downloadContent("http://cis-services-l1.ute.fedex.com:7001/authn/rs/o2b/token/access/test", "application/jwt");

      // Verify token
      com.nimbusds.jwt.SignedJWT jwt = helper.verify(token, java.util.Arrays.asList("O2B", "A2B", "B2B", "C2B"));
      helper.backup();

      //
      // The token has been authenticated
      //

      System.out.println("Issuer: " + jwt.getJWTClaimsSet().getIssuer());
      System.out.println("Subject: " + jwt.getJWTClaimsSet().getSubject());
      System.out.println("Audience: " + jwt.getJWTClaimsSet().getAudience());
      System.out.println("Expiration: " + jwt.getJWTClaimsSet().getExpirationTime());
      System.out.println("Issued: " + jwt.getJWTClaimsSet().getIssueTime());
      System.out.println("jwtID: " + jwt.getJWTClaimsSet().getJWTID());
      System.out.println("Trusted: " + jwt.getJWTClaimsSet().getBooleanClaim("tru"));
      System.out.println("keyID: " + jwt.getJWTClaimsSet().getStringClaim("kid"));

      //
      // Now the subject claimed by the token can be authorized
      //

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // Private attributes
  private final java.util.Set<String> issuers;
  private final int leeway;
  private final int offline;
  private final boolean trusted;
  private final AuthnPublicKeyCache publicKeyCache;
  private final AuthnHealthCache healthCache;

  /**
   * Construct helper.
   * @param properties java.util.Properties
   * @author Michael Cronk
   */
  public AuthnHelper(java.util.Properties properties) {
    // Set issuers formatted as "issuer.<ISSUER>=<URL>"
    issuers = new java.util.HashSet<String>();
    for (String propertyName : properties.stringPropertyNames()) {
      if (propertyName.startsWith("issuer.")) {
        issuers.add(propertyName.substring("issuer.".length()));
      }
    }
    leeway = Integer.valueOf(properties.getProperty("leeway"));   // Seconds
    offline = Integer.valueOf(properties.getProperty("offline")); // Minutes
    trusted = Boolean.valueOf(properties.getProperty("trusted"));
    // Set caches
    publicKeyCache = new AuthnPublicKeyCache(properties);
    healthCache = new AuthnHealthCache(properties);
  }

  /**
   * Backup.
   * 
   * NOTE: Should only be invoked through an asynchronous mechanism!
   * 
   * @throws Exception
   * @author Michael Cronk
   */
  public void backup() throws Exception {
    try {
      publicKeyCache.backup();
    } catch (Exception e) {
      throw new Exception("Failed to backup", e);
    }
  }

  /**
   * Verify access token. 
   * @param token String
   * @param audience java.util.List<String>
   * @return com.nimbusds.jwt.SignedJWT
   * @throws AuthnException
   * @author Michael Cronk
   */
  public com.nimbusds.jwt.SignedJWT verify(String token, java.util.List<String> audience) throws AuthnException {
    com.nimbusds.jwt.SignedJWT result = null;
    try {

      //
      // STEP 1: Parse token string as a signed JWT
      //

      try {
        com.nimbusds.jwt.JWT jwt = com.nimbusds.jwt.JWTParser.parse(token);
        if (jwt instanceof com.nimbusds.jwt.SignedJWT) { result = (com.nimbusds.jwt.SignedJWT) jwt; }
        else { throw new AuthnException("Expected signed JWT: " + jwt.getClass().getName()); }
      } catch (Exception e) {
        throw new AuthnException("Failed to parse JWT token", e);
      }

      //
      // STEP 2: Verify algorithm used to sign token - RSA only!
      //

      try {
        boolean trustedAlgorithm = false;
        com.nimbusds.jose.JWSAlgorithm jwtAlgorithm = result.getHeader().getAlgorithm();
        if (jwtAlgorithm == null) { throw new AuthnException("Not defined"); }
        else if (jwtAlgorithm.equals(com.nimbusds.jose.JWSAlgorithm.RS256)) { trustedAlgorithm = true; }
        if (trustedAlgorithm == false) { throw new AuthnException("Not supported: " + jwtAlgorithm); }
      } catch (Exception e) {
        throw new AuthnException("Failed to verify algorithm used to sign token", e);
      }

      //
      // STEP 3: Verify issuer is trusted
      //

      String jwtIssuer = result.getJWTClaimsSet().getIssuer();
      try {
        if (jwtIssuer == null) { throw new AuthnException("Not defined"); }
        if (issuers.contains(jwtIssuer) == false) { throw new AuthnException("Not supported: " + jwtIssuer); }
      } catch (Exception e) {
        throw new AuthnException("Failed to verify issuer is trusted", e);
      }

      //
      // STEP 4: Verify signature
      //

      try {
        String jwtKid = result.getJWTClaimsSet().getStringClaim("kid");
        if (jwtKid == null) { throw new AuthnException("Public key identifier not defined"); }
        java.security.interfaces.RSAPublicKey publicKey = publicKeyCache.getPublicKey(jwtIssuer, jwtKid);
        com.nimbusds.jose.JWSVerifier verifier = new com.nimbusds.jose.crypto.RSASSAVerifier(publicKey);
        if (result.verify(verifier) == false) { throw new AuthnException("Incorrect token signature: " + jwtKid); }
      } catch (Exception e) {
        throw new AuthnException("Failed to verify signature", e);
      }

      //
      // STEP 5: Verify expiration
      //

      try {
        java.util.Date now = new java.util.Date();
        java.util.Date jwtExpiration = result.getJWTClaimsSet().getExpirationTime();
        if (jwtExpiration == null) { throw new AuthnException("Not defined"); }
        if ((jwtExpiration.getTime() + (leeway * 1000)) < now.getTime()) {
          boolean expired = true;
          if (healthCache.isHealthy(jwtIssuer) == false) {
            // If issuer is unhealthy, the principal may have submitted their last known access token.
            // As long as the token is not grossly expired, expiration verification is bypassed.
            long sinceExpired = new java.util.Date().getTime() - jwtExpiration.getTime();
            if (sinceExpired >= (offline * 60 * 1000)) { expired = false; }
          }
          if (expired) {
            throw new AuthnException("Expired: " + jwtExpiration);
          }
        }
      } catch (Exception e) {
        throw new AuthnException("Failed to verify expiration", e);
      }

      //
      // STEP 6: (Optional) Verify any other claims such as subject, audience and trusted
      //

      // Subject
      try {
        String jwtSubject = result.getJWTClaimsSet().getSubject();
        if ((jwtSubject == null) || jwtSubject.trim().isEmpty()) { throw new AuthnException("Not defined"); }
      } catch (Exception e) {
        throw new AuthnException("Failed to verify subject", e);
      }

      // Audience
      if ((audience != null) && (audience.isEmpty() == false)) {
        try {
          java.util.List<String> jwtAudience = result.getJWTClaimsSet().getAudience();
          if (jwtAudience == null) { throw new AuthnException("Not defined"); }
          boolean found = false;
          for (String aud : audience) { if (jwtAudience.contains(aud)) { found = true; break; } }
          if (found == false) { throw new AuthnException("Not supported: " + String.join(",", jwtAudience)); }
        } catch (Exception e) {
          throw new AuthnException("Failed to verify audience", e);
        }
      }

      // Trusted
      if (trusted) {
        try {
          boolean jwtTrusted = result.getJWTClaimsSet().getBooleanClaim("tru");
          if (jwtTrusted == false) { throw new AuthnException("Trusted only expected"); }
        } catch (Exception e) {
          throw new AuthnException("Failed to verify trusted", e);
        }
      }

    } catch (Exception e) {
      throw new AuthnException("Failed to verify token", e);
    }
    return result;
  }

  //
  // Helper methods
  //

  private String downloadContent(String url, String accept) throws Exception {
    String result = null;
    java.net.HttpURLConnection connection = null;
    java.io.InputStreamReader streamReader = null;
    java.io.BufferedReader bufferedReader = null;
    try {
      connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", accept);
      connection.setConnectTimeout(5000); //  5 seconds to connect
      connection.setReadTimeout(10000);   // 10 seconds to wait for response
      int responseCode = connection.getResponseCode();
      if (responseCode == 200) {
        streamReader = new java.io.InputStreamReader(connection.getInputStream());
        bufferedReader = new java.io.BufferedReader(streamReader);
        String line;
        StringBuilder content = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null) {
          content.append(line);
        }
        result = content.toString();
      } else if (responseCode == 204) {
        // Intentionally does nothing!
      } else {
        throw new Exception("Unexpected HTTP response code: " + responseCode + ": " + connection.getResponseMessage());
      };
    } catch (Exception e) {
      throw new Exception("Failed to download content", e);
    } finally {
      if (bufferedReader != null) { try { bufferedReader.close(); } catch (Exception e) {} }
      if (streamReader != null) { try { streamReader.close(); } catch (Exception e) {} }
      if (connection != null) { try { connection.disconnect(); } catch (Exception e) {} }
    }
    return result;
  }

}
