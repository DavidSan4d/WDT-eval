package com.fedex.cis.audit.service.rs;

/**
 * Consumer-to-Business (C2B) RESTful web service (RS) application resource.
 * 
 * NOTE: Requires authentication (with C2B audience) and authorization!
 * 
 * @author Michael Cronk
 */

import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.server.business.RecordService;
import com.fedex.cis.audit.service.session.*;

import fedex.cis.common.exception.CisException;
import fedex.cis.common.util.ObjectUtility;

@javax.ws.rs.Path("c2b")
@io.swagger.annotations.Api(authorizations={ @io.swagger.annotations.Authorization(value="jwt_token") })
//@io.swagger.v3.oas.annotations.OpenAPIDefinition(security = { @io.swagger.v3.oas.annotations.security.SecurityRequirement(name="jwt-token") })
public class C2bRsResource {

  @org.springframework.beans.factory.annotation.Autowired
  private RecordService recordService;

  /**
   * Get authorization (v1).
   * @return Authorization
   * @throws CisException
   * @author Michael Cronk
   */
  @javax.ws.rs.GET
  @javax.ws.rs.Path("authorization")
  @javax.ws.rs.Produces({javax.ws.rs.core.MediaType.APPLICATION_JSON,javax.ws.rs.core.MediaType.APPLICATION_XML})
  @javax.annotation.security.RolesAllowed({"ANY"})
  public Authorization authorization_v1(
      @javax.ws.rs.core.Context javax.ws.rs.core.SecurityContext sc)
          throws CisException {
    Authorization result = new Authorization();
    try {
      SessionPrincipal principal = (SessionPrincipal) sc.getUserPrincipal();
      result.setPrincipal(principal.getName());
      result.setDomain(principal.getDomain());
      result.setPermissions(principal.getRoles());
    } catch (Exception e) {
      throw new CisException("Failed to get authorization (v1)", e);
    }
    return result;
  }

  /**
   * Query audit (v1).
   * @param query Query
   * @return com.fedex.cis.audit.common.tbd.AuditListDto
   * @throws CisException
   * @author Michael Cronk
   */
  @javax.ws.rs.POST
  @javax.ws.rs.Path("query")
  @javax.ws.rs.Consumes({javax.ws.rs.core.MediaType.APPLICATION_JSON,javax.ws.rs.core.MediaType.APPLICATION_XML})
  @javax.ws.rs.Produces({javax.ws.rs.core.MediaType.APPLICATION_JSON,javax.ws.rs.core.MediaType.APPLICATION_XML})
  @javax.annotation.security.RolesAllowed({"READ"})
  @Deprecated
  public com.fedex.cis.audit.common.tbd.v1.AuditListDto query_v1(
      Query query)
          throws CisException {
    com.fedex.cis.audit.common.tbd.v1.AuditListDto result = null;
    try {
      QueryResult queryResult = recordService.query(query, false);
      if (queryResult.isSuccess()) {
        java.util.Collection<Record> records = queryResult.getRecords();
        result = com.fedex.cis.audit.common.tbd.v1.AuditListDto.getInstance(records);
      } else { // Treat as business exception
        throw new CisException(queryResult.getMessages().toString(), true);
      }
    } catch (Exception e) {
      throw new CisException("Failed to query audit (v1)", e);
    }
    return result;
  }

  /**
   * Query audit (v2).
   * @param query Query
   * @return QueryResult
   * @throws AuthzException
   * @throws CisException
   * @author Michael Cronk
   */
  @javax.ws.rs.POST
  @javax.ws.rs.Path("/v2/query")
  @javax.ws.rs.Consumes({javax.ws.rs.core.MediaType.APPLICATION_JSON,javax.ws.rs.core.MediaType.APPLICATION_XML})
  @javax.ws.rs.Produces({javax.ws.rs.core.MediaType.APPLICATION_JSON,javax.ws.rs.core.MediaType.APPLICATION_XML})
  @javax.annotation.security.RolesAllowed({"ANY"})
  public QueryResult query_v2(
      @javax.ws.rs.core.Context javax.ws.rs.core.SecurityContext sc,
      Query query)
          throws AuthzException, CisException {
    QueryResult result = null;
    try {
      java.util.Set<String> businessReadPermissions = _parseBusinessReadPermissions(sc);
      boolean readAll = businessReadPermissions.contains("ALL");
      result = recordService.query(query, true);
      if ((readAll == false) && ObjectUtility.isValue(result.getRecords())) {
        int total = result.getRecords().size();
        int count = 0;
        java.util.Collection<Record> filteredRecords = new java.util.LinkedList<Record>();
        for (Record record : result.getRecords()) {
          if (businessReadPermissions.contains(record.getBusiness())) { filteredRecords.add(record); }
          else { count += 1; }
        }
        result.setRecords(filteredRecords);
        if (count > 1) { result.getMessages().add("Filtered one or more records according to privileges (total/filtered): " + total + "/" + count); }
      }
    } catch (AuthzException e) {
      throw e;
    } catch (Exception e) {
      throw new CisException("Failed to query audit (v2)", e);
    }
    return result;
  }

  private java.util.Set<String> _parseBusinessReadPermissions(javax.ws.rs.core.SecurityContext sc) throws AuthzException {
    java.util.Set<String> result = new java.util.HashSet<String>();
    SessionPrincipal principal = (SessionPrincipal) sc.getUserPrincipal();
    java.util.Set<String> permissions = principal.getRoles();
    if (permissions != null) {
      for (String permission : permissions) {
        if (permission.startsWith("R_") && (permission.length() > 2)) { result.add(permission.substring(2)); }
      }
    }
    if (result.isEmpty()) {
      throw new AuthzException("No business read permissions found for principal: " + principal.getName());
    }
    return result;
  }

}
