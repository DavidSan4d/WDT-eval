package com.fedex.cis.audit.service;

@org.springframework.core.annotation.Order(org.springframework.core.Ordered.HIGHEST_PRECEDENCE)
public class ServiceInitializer implements org.springframework.web.WebApplicationInitializer {

  @Override
  public void onStartup(javax.servlet.ServletContext servletContext) throws javax.servlet.ServletException {
    org.springframework.web.context.support.AnnotationConfigWebApplicationContext serviceContext = new org.springframework.web.context.support.AnnotationConfigWebApplicationContext();
    servletContext.addListener(new org.springframework.web.context.ContextLoaderListener(serviceContext));
    servletContext.setInitParameter("contextConfigLocation", "com.fedex.cis");
  }

}
