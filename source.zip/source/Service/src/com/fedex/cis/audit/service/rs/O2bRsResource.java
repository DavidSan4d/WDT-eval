package com.fedex.cis.audit.service.rs;

/**
 * Open-to-Business (O2B) RESTful web service (RS) application resource.
 * 
 * NOTE: Requires no authentication nor authorization!
 * 
 * @author Michael Cronk
 */

import com.fedex.cis.audit.common.bean.Ping;
import com.fedex.cis.audit.server.business.general.GeneralBusiness;

import fedex.cis.common.exception.CisException;

@javax.ws.rs.Path("o2b")
@io.swagger.annotations.Api
public class O2bRsResource {

  @org.springframework.beans.factory.annotation.Autowired
  private GeneralBusiness generalBusiness;

  /**
   * Ping.
   * @return Ping
   * @throws CisException
   * @author Michael Cronk
   */
  @javax.ws.rs.GET
  @javax.ws.rs.Path("ping")
  @javax.ws.rs.Produces({javax.ws.rs.core.MediaType.APPLICATION_JSON,javax.ws.rs.core.MediaType.APPLICATION_XML})
  public Ping ping()
      throws CisException {
    Ping result = null;
    try {
      result = generalBusiness.ping();
    } catch (Exception e) {
      throw new CisException("Failed to ping", e);
    }
    return result;
  }

}
