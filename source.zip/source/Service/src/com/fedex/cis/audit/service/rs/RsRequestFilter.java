package com.fedex.cis.audit.service.rs;

/**
 * RESTful web services (RS) request filter.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.service.ServiceManager;
import com.fedex.cis.audit.service.session.*;

import fedex.cis.common.util.*;

@javax.ws.rs.ext.Provider
@javax.ws.rs.container.PreMatching
public class RsRequestFilter implements javax.ws.rs.container.ContainerRequestFilter {

  // Private constants
  private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RsRequestFilter.class);
  private static final String AUTHORIZATION_HEADER = "Authorization";
  private static final String AUTHORIZATION_SCHEME = "Bearer";
  private static final String AUTHENTICATE_HEADER = "WWW-Authenticate";
  private static final String AUTHENTICATE_REALM = "cis-authn";

  /**
   * Filter method called before a request has been dispatched to a resource.
   * @param requestContext javax.ws.rs.container.ContainerRequestContext
   * @throws java.io.IOException
   * @author Michael Cronk
   */
  @Override
  public void filter(
      javax.ws.rs.container.ContainerRequestContext requestContext)
          throws java.io.IOException {

    // Get audience.  For example, a URI of "/o2b/ping" has an audience of "o2b"
    String audience = null;
    java.util.List<String> uri = StringUtility.toList(requestContext.getUriInfo().getPath(), "/");
    if ((uri != null) && (uri.size() > 0)) { audience = uri.get(0); }
    if (audience == null) { requestContext.abortWith(getBadRequest()); }

    // No access controls implemented for O2B or Swagger interfaces
    if (audience.equals("o2b") || audience.startsWith("swagger") || audience.startsWith("openapi")) { return; }

    // Get token
    String token = null;
    java.util.List<String> authorization = StringUtility.toList(requestContext.getHeaderString(AUTHORIZATION_HEADER), " ");
    if (ObjectUtility.isValue(authorization) && (authorization.size() == 2) && authorization.get(0).equals(AUTHORIZATION_SCHEME)) {
      token = authorization.get(1);
    } else {
      requestContext.abortWith(getBadRequest());
    }

    // Get authorization domain
    String domainName = null;
    if (audience.equals("b2b") || audience.equals("c2b")) {
      domainName = SessionManager.DOMAIN + audience.toUpperCase();
    }

    // Get session principal
    SessionPrincipal principal = null;
    try {
      principal = ServiceManager.getSession().getPrincipal(token, audience, domainName);
      if (principal == null) { requestContext.abortWith(getUnauthorizedResponse()); }
    } catch (AuthnException e) {
      if (logger.isInfoEnabled()) { logger.info("AUTHN", e); }
      requestContext.abortWith(getUnauthorizedResponse());
    } catch (AuthzException e) {
      if (logger.isInfoEnabled()) { logger.info("AUTHZ", e); }
      requestContext.abortWith(getForbiddenResponse());
    } catch (Exception e) {
      if (logger.isErrorEnabled()) { logger.error("OTHER", e); }
      requestContext.abortWith(getInternalServerErrorResponse());
    }

    // Set security context
    requestContext.setSecurityContext(new RsSecurityContext(principal, AUTHORIZATION_SCHEME, false));

  }

  private javax.ws.rs.core.Response getBadRequest() {
    return javax.ws.rs.core.Response.
        status(javax.ws.rs.core.Response.Status.BAD_REQUEST).
        build();
  }

  private javax.ws.rs.core.Response getUnauthorizedResponse() {
    return javax.ws.rs.core.Response.
        status(javax.ws.rs.core.Response.Status.UNAUTHORIZED).
        header(AUTHENTICATE_HEADER, AUTHORIZATION_SCHEME + " realm=\"" + AUTHENTICATE_REALM + "\"").
        build();
  }

  private javax.ws.rs.core.Response getForbiddenResponse() {
    return javax.ws.rs.core.Response.
        status(javax.ws.rs.core.Response.Status.FORBIDDEN).
        build();
  }

  private javax.ws.rs.core.Response getInternalServerErrorResponse() {
    return javax.ws.rs.core.Response.
        status(javax.ws.rs.core.Response.Status.INTERNAL_SERVER_ERROR).
        build();
  }

}
