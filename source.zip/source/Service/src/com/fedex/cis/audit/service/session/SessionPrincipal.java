package com.fedex.cis.audit.service.session;

public class SessionPrincipal implements java.security.Principal {

  public SessionPrincipal(String name, String domain, java.util.Set<String> roles, boolean trusted) {
    this.name = name;
    this.domain = domain;
    this.roles = roles;
    this.trusted = trusted;
  }

  private final String name;
  @Override
  public String getName() { return name; }

  private final String domain;
  public String getDomain() { return domain; }

  private final java.util.Set<String> roles;
  public java.util.Set<String> getRoles() { return roles; }

  private final boolean trusted;
  public boolean isTrusted() { return trusted; }

}
