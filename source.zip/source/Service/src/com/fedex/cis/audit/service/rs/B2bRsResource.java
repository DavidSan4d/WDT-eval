package com.fedex.cis.audit.service.rs;

/**
 * Business-to-Business (C2B) RESTful web service (RS) application resource.
 * 
 * NOTE: Requires authentication (with B2B audience) and authorization!
 * 
 * @author Michael Cronk
 */

import com.fedex.cis.audit.common.bean.*;
import com.fedex.cis.audit.server.business.RecordService;
import com.fedex.cis.audit.service.session.*;

import fedex.cis.common.exception.CisException;
import fedex.cis.common.util.ObjectUtility;

@javax.ws.rs.Path("b2b")
@io.swagger.annotations.Api(authorizations={ @io.swagger.annotations.Authorization(value="jwt_token") })
//@io.swagger.v3.oas.annotations.OpenAPIDefinition(security = { @io.swagger.v3.oas.annotations.security.SecurityRequirement(name="jwt-token") })
public class B2bRsResource {

  @org.springframework.beans.factory.annotation.Autowired
  private RecordService recordService;

  /**
   * Record audit (v1).
   * @param tbdAudit com.fedex.cis.audit.common.tbd.Audit
   * @return boolean
   * @throws CisException
   * @author Michael Cronk
   */
  @javax.ws.rs.POST
  @javax.ws.rs.Path("record")
  @javax.ws.rs.Consumes(javax.ws.rs.core.MediaType.APPLICATION_XML)
  @javax.ws.rs.Produces(javax.ws.rs.core.MediaType.TEXT_PLAIN)
  @javax.annotation.security.RolesAllowed({"RECORD"})
  @Deprecated
  public boolean record_v1(
      @javax.ws.rs.core.Context javax.ws.rs.core.SecurityContext sc,
      com.fedex.cis.audit.common.tbd.v1.Audit tbdAudit)
          throws CisException {
    boolean result = false;
    try {
      Audit audit = com.fedex.cis.audit.common.tbd.v1.Audit.toAudit(tbdAudit);
      RecordResult recordResult = recordService.record(audit, false, sc.getUserPrincipal().getName());
      if (recordResult.isSuccess()) {
        result = ObjectUtility.isValue(recordResult.getReference());
      } else { // Treat as business exception
        throw new CisException(recordResult.getMessages().toString(), true);
      }
    } catch (Exception e) {
      throw new CisException("Failed to record audit (v1)", e);
    }
    return result;
  }

  /**
   * Record audit (v2).
   * @param audit Audit
   * @return RecordResult
   * @throws AuthzException
   * @throws CisException
   * @author Michael Cronk
   */
  @javax.ws.rs.POST
  @javax.ws.rs.Path("/v2/record")
  @javax.ws.rs.Consumes({javax.ws.rs.core.MediaType.APPLICATION_JSON,javax.ws.rs.core.MediaType.APPLICATION_XML})
  @javax.ws.rs.Produces({javax.ws.rs.core.MediaType.APPLICATION_JSON,javax.ws.rs.core.MediaType.APPLICATION_XML})
  @javax.annotation.security.RolesAllowed({"ANY"})
  public RecordResult record_v2(
      @javax.ws.rs.core.Context javax.ws.rs.core.SecurityContext sc,
      Audit audit)
          throws AuthzException, CisException {
    RecordResult result = null;
    try {
      _verifyBusinessWritePermission(sc, audit);
      result = recordService.record(audit, true, sc.getUserPrincipal().getName());
    } catch (AuthzException e) {
      throw e;
    } catch (Exception e) {
      throw new CisException("Failed to record audit (v2)", e);
    }
    return result;
  }

  private void _verifyBusinessWritePermission(javax.ws.rs.core.SecurityContext sc, Audit audit) throws AuthzException {
    SessionPrincipal principal = (SessionPrincipal) sc.getUserPrincipal();
    java.util.Set<String> permissions = principal.getRoles();
    String business = ((audit != null) && (audit.getBusiness() != null)) ? audit.getBusiness().toUpperCase() : null;
    if (ObjectUtility.isValue(business) == false) { throw new AuthzException("Audit business not defined"); }
    else if (ObjectUtility.equals("ALL", business)) { throw new AuthzException("Audit business not allowed: " + business); }
    boolean found = false;
    if (ObjectUtility.isValue(permissions)) {
      found = permissions.contains("W_ALL") || permissions.contains("W_" + business);
    }
    if (found == false) {
      throw new AuthzException("No business write permission found for principal (principal/business): " + principal.getName() + "/" + business);
    }
  }

}
