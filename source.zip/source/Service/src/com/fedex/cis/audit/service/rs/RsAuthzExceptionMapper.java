package com.fedex.cis.audit.service.rs;

/**
 * Exception to Response mapper for all authorization exceptions.
 * @author Michael Cronk
 */

import com.fedex.cis.audit.service.session.AuthzException;

@javax.ws.rs.ext.Provider
public class RsAuthzExceptionMapper implements javax.ws.rs.ext.ExceptionMapper<AuthzException> {

  // Private constants
  private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RsAuthzExceptionMapper.class);

  /**
   * Map an exception to a Response.
   * @param e AuthzException
   * @return javax.ws.rs.core.Response
   * @author Michael Cronk
   */
  @Override
  public javax.ws.rs.core.Response toResponse(AuthzException e) {
    if (logger.isInfoEnabled()) { logger.info("AUTHZ", e); }
    return javax.ws.rs.core.Response.
        status(javax.ws.rs.core.Response.Status.FORBIDDEN).
        build();
  }

}
